#!/usr/bin/env python3
"""Convert ComfyUI web format workflow to API format."""
import argparse
import json
import urllib.request

# control_after_generate 标记值，这些值出现在 widgets_values 中但不是真正的输入参数
_CONTROL_AFTER_GENERATE_VALUES = {"fixed", "increment", "randomize", "disable"}


def _filter_control_values(widgets_values):
    """过滤 widgets_values 中的 control_after_generate 标记。

    ComfyUI UI 格式中，带 seed 输入的节点会在 widgets_values 数组中
    插入一个 control_after_generate 标记（如 "fixed"/"randomize"），
    但该标记不是真正的输入参数，需要过滤掉以避免 widget 值错位。
    """
    out = []
    i = 0
    while i < len(widgets_values):
        value = widgets_values[i]
        # 如果当前值是 control 标记，跳过
        if isinstance(value, str) and value in _CONTROL_AFTER_GENERATE_VALUES:
            i += 1
            continue
        # 如果下一个值是 control 标记，当前值是 widget 值，跳过下一个
        if i + 1 < len(widgets_values) and isinstance(widgets_values[i + 1], str) and widgets_values[i + 1] in _CONTROL_AFTER_GENERATE_VALUES:
            out.append(value)
            i += 2
            continue
        out.append(value)
        i += 1
    return out


def get_object_info(host="127.0.0.1", port="3198"):  # comfyui-cli项目标准端口
    """从 ComfyUI 服务器获取 object_info 字典"""
    try:
        req = urllib.request.Request(f"http://{host}:{port}/object_info", method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print(f"Warning: 无法从服务器获取 object_info: {e}")
        return {}


def _get_widget_names_from_object_info(node_type, object_info):
    """从 object_info schema 获取有序的 widget 输入名列表。

    UI 格式的 nodes[].inputs 只包含连接输入，widget 定义需要从 object_info 获取。
    widget 类型包括：列表（combo 选择）、INT、FLOAT、STRING。
    """
    if not object_info or node_type not in object_info:
        return []

    node_schema = object_info[node_type]
    inputs_def = node_schema.get("input", {})

    widget_names = []
    for section in ("required", "optional"):
        section_inputs = inputs_def.get(section, {})
        if isinstance(section_inputs, dict):
            for name, type_info in section_inputs.items():
                if isinstance(type_info, list) and len(type_info) > 0:
                    input_type = type_info[0]
                    # widget 类型：列表(combo)、INT、FLOAT、STRING
                    if isinstance(input_type, list) or input_type in ("INT", "FLOAT", "STRING"):
                        widget_names.append(name)

    return widget_names


def _get_widget_types_from_object_info(node_type, object_info):
    """从 object_info schema 获取有序的 widget 输入类型列表，用于类型转换"""
    if not object_info or node_type not in object_info:
        return []

    node_schema = object_info[node_type]
    inputs_def = node_schema.get("input", {})

    widget_types = []
    for section in ("required", "optional"):
        section_inputs = inputs_def.get(section, {})
        if isinstance(section_inputs, dict):
            for name, type_info in section_inputs.items():
                if isinstance(type_info, list) and len(type_info) > 0:
                    input_type = type_info[0]
                    if isinstance(input_type, list) or input_type in ("INT", "FLOAT", "STRING"):
                        widget_types.append(input_type)

    return widget_types


def convert_web_to_api(web_workflow, object_info=None):
    """Convert web UI format to API format.

    Args:
        web_workflow: UI 格式工作流（含 nodes/links 数组）
        object_info: 从 /object_info 获取的节点 schema 字典。
                     如果为 None，widget 值将无法正确映射。
    """
    if "nodes" not in web_workflow:
        # Already in API format
        return web_workflow

    if object_info is None:
        object_info = {}

    api_workflow = {}
    nodes = web_workflow.get("nodes", [])
    links = web_workflow.get("links", [])

    # Build link lookup: link_id -> (source_node, source_slot, target_node, target_slot)
    # ComfyUI UI 格式的 link 至少需要 5 个元素：[link_id, source_node, source_slot, target_node, target_slot]
    # 标准格式有 6 个元素，第 6 个是类型
    link_map = {}
    for link in links:
        if isinstance(link, list) and len(link) >= 5:
            link_id = link[0]
            source_node = link[1]
            source_slot = link[2]
            target_node = link[3]
            target_slot = link[4]
            link_map[link_id] = (source_node, source_slot, target_node, target_slot)

    # Build node input connections
    node_inputs = {}
    for node in nodes:
        node_id = str(node.get("id"))
        node_inputs[node_id] = {}
        inputs = node.get("inputs", [])
        for inp in inputs:
            link_id = inp.get("link")
            if link_id is not None and link_id in link_map:
                source_node, source_slot, _, _ = link_map[link_id]
                node_inputs[node_id][inp.get("name")] = [str(source_node), source_slot]

    # Build API nodes
    for node in nodes:
        node_id = str(node.get("id"))
        node_type = node.get("type", "")

        api_node = {
            "class_type": node_type,
            "inputs": {}
        }

        # Get widget values - these are stored in widgets_values array
        widgets_values = node.get("widgets_values", [])
        if not isinstance(widgets_values, list):
            widgets_values = []

        # 过滤 control_after_generate 标记，避免 widget 值错位
        filtered_values = _filter_control_values(widgets_values)

        # 使用 object_info 获取 widget 名称和类型列表
        # UI 格式的 node["inputs"] 只包含连接输入，不能用于 widget 映射
        widget_names = _get_widget_names_from_object_info(node_type, object_info)
        widget_types = _get_widget_types_from_object_info(node_type, object_info)

        # 检查哪些 widget 已被连接占用（有 link 的连接输入会覆盖 widget 值）
        connected_input_names = set(node_inputs.get(node_id, {}).keys())

        # 映射 widget 值到参数名
        for idx, param_name in enumerate(widget_names):
            if param_name in connected_input_names:
                # 该参数已被连接占用，跳过 widget 值
                continue
            if idx >= len(filtered_values):
                break
            value = filtered_values[idx]

            # 类型转换
            if idx < len(widget_types):
                inp_type = widget_types[idx]
                if inp_type == "INT" and isinstance(value, str):
                    try:
                        value = int(value)
                    except ValueError:
                        pass
                elif inp_type == "FLOAT" and isinstance(value, str):
                    try:
                        value = float(value)
                    except ValueError:
                        pass

            api_node["inputs"][param_name] = value

        # Add connections (these override widget values if there's a link)
        for input_name, connection in node_inputs.get(node_id, {}).items():
            api_node["inputs"][input_name] = connection

        api_workflow[node_id] = api_node

    return api_workflow


def main():
    ap = argparse.ArgumentParser(description="Convert ComfyUI workflow format")
    ap.add_argument("--input", required=True, help="Input workflow JSON")
    ap.add_argument("--output", required=True, help="Output workflow JSON")
    ap.add_argument("--host", default="127.0.0.1", help="ComfyUI server host")
    ap.add_argument("--port", default="3198", help="ComfyUI server port")  # comfyui-cli项目标准端口
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        workflow = json.load(f)

    # 从服务器获取 object_info 用于 widget 映射
    object_info = get_object_info(args.host, args.port)
    if not object_info:
        print("Warning: 无法获取 object_info，widget 值可能无法正确映射")

    api_workflow = convert_web_to_api(workflow, object_info)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(api_workflow, f, indent=2, ensure_ascii=False)

    print(json.dumps({"ok": True, "output": args.output, "nodes": list(api_workflow.keys())}))


if __name__ == "__main__":
    main()
