#!/usr/bin/env python3
"""监控工作流执行过程"""
import json
import urllib.request
import time
import os

BASE_URL = 'http://127.0.0.1:3198'
PROMPT_ID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'

def get_queue():
    """获取队列状态"""
    try:
        with urllib.request.urlopen(f'{BASE_URL}/queue', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_history(prompt_id):
    """获取执行历史"""
    try:
        with urllib.request.urlopen(f'{BASE_URL}/history/{prompt_id}', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_system_stats():
    """获取系统状态"""
    try:
        with urllib.request.urlopen(f'{BASE_URL}/system_stats', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

print(f'=== 监控工作流执行 ===')
print(f'prompt_id: {PROMPT_ID}')
print(f'开始时间: {time.strftime("%H:%M:%S")}')
print()

start_time = time.time()
last_status = None
check_count = 0

while True:
    check_count += 1
    elapsed = time.time() - start_time

    # 检查队列
    queue = get_queue()
    queue_running = queue.get('queue_running', [])
    queue_pending = queue.get('queue_pending', [])

    # 检查历史
    history = get_history(PROMPT_ID)

    # 获取系统状态
    stats = get_system_stats()
    vram_free = 0
    vram_total = 0
    if stats and 'devices' in stats and stats['devices']:
        vram_free = stats['devices'][0].get('vram_free', 0)
        vram_total = stats['devices'][0].get('vram_total', 0)

    # 判断状态
    if history and PROMPT_ID in history:
        # 已完成
        hist = history[PROMPT_ID]
        status = hist.get('status', {})
        status_str = status.get('status_str', 'unknown')

        if status_str == 'success':
            # 成功完成
            outputs = hist.get('outputs', {})
            print(f'\n=== 执行成功 ===')
            print(f'耗时: {elapsed:.1f}秒 ({elapsed/60:.1f}分钟)')

            # 检查输出
            for nid, out in outputs.items():
                if 'gifs' in out or 'images' in out or 'videos' in out:
                    for key in ['gifs', 'images', 'videos']:
                        if key in out:
                            for item in out[key]:
                                filename = item.get('filename', '?')
                                subfolder = item.get('subfolder', '')
                                print(f'  输出 NID={nid}: {subfolder}/{filename}')

            # 检查VRAM
            print(f'\n最终VRAM: {vram_free/1024/1024:.0f}MB free / {vram_total/1024/1024:.0f}MB total')
            break

        elif status_str == 'error':
            # 执行错误
            print(f'\n=== 执行失败 ===')
            print(f'耗时: {elapsed:.1f}秒')
            print(f'状态: {status_str}')

            # 打印错误信息
            messages = status.get('messages', [])
            for msg in messages:
                print(f'  消息: {msg}')

            # 检查节点错误
            if 'node_errors' in hist:
                for nid, errs in hist['node_errors'].items():
                    print(f'  NID={nid}:')
                    for e in errs.get('errors', []):
                        print(f'    - {e.get("type")}: {e.get("details","")}')

            break

    # 仍在执行中
    running_info = ''
    if queue_running:
        running_info = f'运行中({len(queue_running)}个任务)'

    # 每10秒打印一次状态
    if check_count % 2 == 0 or check_count == 1:  # 每10秒或第一次
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)
        print(f'[{mins:02d}:{secs:02d}] {running_info} VRAM: {vram_free/1024/1024:.0f}MB/{vram_total/1024/1024:.0f}MB')

    # 超时检查 (2小时)
    if elapsed > 7200:
        print(f'\n=== 超时 (>2小时) ===')
        break

    time.sleep(5)

print(f'\n监控结束: {time.strftime("%H:%M:%S")}')
