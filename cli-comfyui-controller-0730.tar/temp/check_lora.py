#!/usr/bin/env python3
"""检查API中LoRA节点的完整inputs"""
import json

API_PATH = r'e:\comfyui-cli\temp\long_video_api_v2.json'
with open(API_PATH, 'r', encoding='utf-8') as f:
    api = json.load(f)

print('=== LoraLoaderModelOnly nodes ===')
for nid, node in api.items():
    if node.get('class_type') == 'LoraLoaderModelOnly':
        inputs = node.get('inputs', {})
        print(f'NID={nid}:')
        for k, v in inputs.items():
            print(f'  {k}: {v}')

# 检查 object_info 中 LoraLoaderModelOnly 的定义
import urllib.request
print('\n=== LoraLoaderModelOnly object_info ===')
try:
    with urllib.request.urlopen('http://127.0.0.1:3198/object_info/LoraLoaderModelOnly', timeout=10) as resp:
        data = json.loads(resp.read())
    if 'LoraLoaderModelOnly' in data:
        node_info = data['LoraLoaderModelOnly']
        required = node_info.get('input', {}).get('required', {})
        print('Required inputs:')
        for name, type_info in required.items():
            print(f'  {name}: {type_info}')
except Exception as e:
    print(f'Error: {e}')
