#!/usr/bin/env python3
"""提交v7工作流（ColorMatch色调锚定）"""
import json
import sys
import urllib.request

BASE = 'http://127.0.0.1:3198'
INPUT_WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUTPUT_API = r'e:\comfyui-cli\temp\long_video_api_v7.json'

sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import convert_web_to_api, get_object_info

# 1. Free memory
print('=== 1. Freeing memory ===')
try:
    req = urllib.request.Request(f'{BASE}/free', data=json.dumps({'unload_models': True, 'free_memory': True}).encode(), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=30) as resp:
        print(f'Free memory: {resp.status}')
except Exception as e:
    print(f'Free memory error: {e}')

# 2. Read workflow
print('\n=== 2. Reading workflow ===')
with open(INPUT_WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)
print(f'Nodes: {len(wf.get("nodes", []))}')

# 3. Get object_info
print('\n=== 3. Getting object_info ===')
object_info = get_object_info('127.0.0.1', '3198')
print(f'object_info nodes: {len(object_info)}')

# 4. Convert
print('\n=== 4. Converting ===')
try:
    api = convert_web_to_api(wf, object_info)
    print(f'API nodes: {len(api)}')
except Exception as e:
    print(f'Convert error: {e}')
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 5. Verify ColorMatch
print('\n=== 5. Verifying ColorMatch ===')
cm_count = 0
for nid, node in api.items():
    if node.get('class_type') == 'ColorMatch':
        cm_count += 1
        inputs = node.get('inputs', {})
        method = inputs.get('method', '?')
        strength = inputs.get('strength', '?')
        ref = inputs.get('image_ref', '?')
        target = inputs.get('image_target', '?')
        print(f'  NID={nid}: method={method} strength={strength} ref={ref} target={target}')
print(f'Total ColorMatch: {cm_count} (target=9)')

# 6. Add enable_fp16_accumulation
print('\n=== 6. Adding enable_fp16_accumulation ===')
torch_fixes = 0
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_fixes += 1
print(f'Fixed {torch_fixes} ModelPatchTorchSettings nodes')

# 7. Save
print('\n=== 7. Saving ===')
with open(OUTPUT_API, 'w', encoding='utf-8') as f:
    json.dump(api, f, indent=2, ensure_ascii=False)
print(f'Saved to: {OUTPUT_API}')

# 8. Submit
print('\n=== 8. Submitting ===')
payload = {
    'prompt': api,
    'client_id': 'comfyui-cli-monitor-v7'
}
req = urllib.request.Request(
    f'{BASE}/prompt',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    print(f'Result: {json.dumps(result, ensure_ascii=False)}')
    prompt_id = result.get('prompt_id')
    if prompt_id:
        print(f'\nPrompt ID: {prompt_id}')
        with open(r'e:\comfyui-cli\temp\last_prompt_id_v9.txt', 'w') as f:
            f.write(prompt_id)
except urllib.error.HTTPError as e:
    print(f'HTTP Error: {e.code}')
    err_body = e.read().decode('utf-8')
    print(err_body[:3000])
except Exception as e:
    print(f'Error: {e}')
