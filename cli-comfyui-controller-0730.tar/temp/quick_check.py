#!/usr/bin/env python3
"""快速检查工作流状态"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = '11141f20-d06d-4421-8a35-a18b973057e9'

# 队列
q = json.loads(urllib.request.urlopen(BASE+'/queue', timeout=5).read())
running = q.get('queue_running', [])
pending = q.get('queue_pending', [])
print(f'Queue: running={len(running)} pending={len(pending)}')
if running:
    for r in running:
        print(f'  running: {r[1] if len(r)>1 else "?"} prompt_id={r[3] if len(r)>3 else "?"}')

# 历史
h = json.loads(urllib.request.urlopen(BASE+'/history/'+PID, timeout=5).read())
if PID in h:
    status = h[PID].get('status', {})
    print(f'Status: {status.get("status_str")}')
    print(f'Completed: {status.get("completed")}')

    # 消息
    for msg_type, msg_data in status.get('messages', []):
        if msg_type == 'execution_start':
            print(f'Start: {msg_data.get("timestamp")}')
        elif msg_type == 'execution_success':
            print(f'Success: {msg_data.get("timestamp")}')
        elif msg_type == 'execution_error':
            print(f'Error: {json.dumps(msg_data, ensure_ascii=False)[:500]}')
        elif msg_type == 'execution_cached':
            print(f'Cached nodes: {len(msg_data.get("nodes", []))}')

    # 输出
    outputs = h[PID].get('outputs', {})
    print(f'Outputs: {len(outputs)}')
    for nid, out in outputs.items():
        print(f'  NID={nid}: {list(out.keys())}')
else:
    print('Status: running (not in history yet)')

# 系统统计
s = json.loads(urllib.request.urlopen(BASE+'/system_stats', timeout=5).read())
for dev in s.get('devices', []):
    if dev.get('type') == 'cuda':
        free = dev.get('vram_free', 0) / 1024/1024
        total = dev.get('vram_total', 0) / 1024/1024
        used = total - free
        print(f'VRAM: {used:.0f}MB / {total:.0f}MB ({used/total*100:.1f}%)')
