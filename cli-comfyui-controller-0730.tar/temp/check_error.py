#!/usr/bin/env python3
"""获取完整的执行错误信息"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = 'bc4c1ef5-8dd0-4b61-be90-64f7d8df8f2e'

with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

data = h[PID]
status = data.get('status', {})

print(f'Status: {status.get("status_str")}')
print(f'Completed: {status.get("completed")}')

# 完整消息
print('\n=== All messages ===')
for msg_type, msg_data in status.get('messages', []):
    print(f'\n{msg_type}:')
    print(json.dumps(msg_data, ensure_ascii=False, indent=2))

# 特别查看 execution_error
for msg_type, msg_data in status.get('messages', []):
    if msg_type == 'execution_error':
        print('\n=== Execution Error Details ===')
        print(json.dumps(msg_data, ensure_ascii=False, indent=2))
        print(f'\nnode_id: {msg_data.get("node_id")}')
        print(f'node_type: {msg_data.get("node_type")}')
        print(f'exception_message: {msg_data.get("exception_message")}')
        print(f'exception_type: {msg_data.get("exception_type")}')
        print(f'traceback: {msg_data.get("traceback", "")[:2000]}')
