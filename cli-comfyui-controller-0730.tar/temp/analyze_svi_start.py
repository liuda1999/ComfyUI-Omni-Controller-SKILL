#!/usr/bin/env python3
"""检查SVI Pro的start_image配置和Flux2换皮链路"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

def trace_back(nid, depth=0, visited=None):
    if visited is None:
        visited = set()
    if nid in visited or depth > 8:
        return
    visited.add(nid)
    indent = '  ' * depth
    node = nodes_by_id.get(nid, {})
    ct = node.get('type', '?')
    title = node.get('title', '')
    print(f'{indent}NID={nid} type={ct} title={title}')
    for inp in node.get('inputs', []):
        name = inp.get('name')
        link_id = inp.get('link')
        if link_id is not None and link_id in link_map:
            src_node = link_map[link_id][1]
            print(f'{indent}  IN {name} <- NID={src_node}')
            trace_back(src_node, depth+1, visited)

# 1. 检查所有SVI Pro节点的start_image输入
print('='*70)
print('=== SVI Pro节点的start_image输入来源 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'WanImageToVideoSVIPro':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'\n--- NID={nid} title={title} ---')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            if name in ('start_image', 'start_image_in', 'image'):
                link_id = inp.get('link')
                if link_id is not None and link_id in link_map:
                    src_node = link_map[link_id][1]
                    src_obj = nodes_by_id.get(src_node, {})
                    print(f'  {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')
                    # 追溯
                    trace_back(src_node, 1)

# 2. 检查Flux2当前配置（denoise和A图来源）
print('\n' + '='*70)
print('=== Flux2 SplitSigmasDenoise配置 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} denoise={wv[0] if wv else "?"}')

# 3. 检查当前ImageBlend节点（需要撤销的）
print('\n' + '='*70)
print('=== 当前ImageBlend节点（需撤销） ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'ImageBlend':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node = link_map[link_id][1]
                src_obj = nodes_by_id.get(src_node, {})
                print(f'  {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')

# 4. 检查A图缩放节点(NID=93,100,107,114)当前输入
print('\n' + '='*70)
print('=== Flux2 A图缩放节点输入来源 ===')
print('='*70)
for nid in [93, 100, 107, 114]:
    node = nodes_by_id.get(nid, {})
    title = node.get('title', '')
    for inp in node.get('inputs', []):
        name = inp.get('name')
        link_id = inp.get('link')
        if link_id is not None and link_id in link_map:
            src_node = link_map[link_id][1]
            src_obj = nodes_by_id.get(src_node, {})
            print(f'NID={nid} ({title}) {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')
