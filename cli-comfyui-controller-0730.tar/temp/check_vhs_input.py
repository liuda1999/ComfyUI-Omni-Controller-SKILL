#!/usr/bin/env python3
"""检查 VHS_VideoCombine 节点的输入连接"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

# 构建 link_id -> (源节点, 源slot, 目标节点, 目标slot)
link_map = {}
for link in links:
    if isinstance(link, list) and len(link) >= 5:
        link_id = link[0]
        link_map[link_id] = (link[1], link[2], link[3], link[4])

# 检查 NID=355 的输入连接
target_nid = 355
print(f'=== NID={target_nid} (VHS_VideoCombine) 输入连接 ===')
for n in nodes:
    if n.get('id') == target_nid:
        ntype = n.get('type')
        print(f'type: {ntype}')
        print(f'inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                # 查找源节点
                src_ntype = '?'
                for sn in nodes:
                    if sn.get('id') == src_node:
                        src_ntype = sn.get('type')
                        break
                print(f'  {name} <- NID={src_node} (type={src_ntype}, slot={src_slot})')
            else:
                print(f'  {name} <- (unconnected, link_id={link_id})')

# 检查所有图像批处理节点和它们的输出
print('\n=== Image batch/stack nodes ===')
for n in nodes:
    ntype = n.get('type', '')
    if 'ImageBatch' in ntype or 'ImageStack' in ntype or 'ImageConcat' in ntype:
        nid = n.get('id')
        print(f'NID={nid} type={ntype}')
        # 输入
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_ntype = '?'
                for sn in nodes:
                    if sn.get('id') == src_node:
                        src_ntype = sn.get('type')
                        break
                print(f'  IN {name} <- NID={src_node} (type={src_ntype}, slot={src_slot})')
        # 输出
        for idx, out in enumerate(n.get('outputs', [])):
            name = out.get('name', f'slot{idx}')
            # 查找连接到这个输出的目标节点
            targets = []
            for link in links:
                if isinstance(link, list) and len(link) >= 5:
                    if link[1] == nid and link[2] == idx:
                        tgt_node = link[3]
                        tgt_ntype = '?'
                        for sn in nodes:
                            if sn.get('id') == tgt_node:
                                tgt_ntype = sn.get('type')
                                break
                        targets.append(f'NID={tgt_node}(type={tgt_ntype})')
            print(f'  OUT {name} -> {targets if targets else "(no target)"}')

# 找出 NID=355 的输出节点是否连接到任何源
print('\n=== Nodes feeding into NID=355 ===')
# 反向查找
for link in links:
    if isinstance(link, list) and len(link) >= 5:
        if link[3] == target_nid:
            src_nid = link[1]
            src_slot = link[2]
            src_ntype = '?'
            for sn in nodes:
                if sn.get('id') == src_nid:
                    src_ntype = sn.get('type')
                    break
            print(f'  link_id={link[0]} src=NID={src_nid}(type={src_ntype}, slot={src_slot})')
