#!/usr/bin/env python3
"""检查提交的 API 工作流中的 VHS_VideoCombine 节点"""
import json

# 检查所有可能的 API 文件
for path in [r'e:\comfyui-cli\temp\long_video_api.json',
             r'e:\comfyui-cli\temp\long_video_submit.json']:
    print(f'\n=== {path} ===')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            api = json.load(f)
        print(f'Total nodes: {len(api)}')

        # 查找 VHS_VideoCombine
        vhs_found = False
        for nid, node in api.items():
            if node.get('class_type') == 'VHS_VideoCombine':
                vhs_found = True
                print(f'NID={nid} VHS_VideoCombine:')
                print(f'  inputs: {json.dumps(node.get("inputs", {}), ensure_ascii=False, indent=2)}')

        if not vhs_found:
            print('VHS_VideoCombine NOT FOUND in API workflow!')

        # 检查 NID=348 是否存在并输出连接
        for nid in ['348', '355', '345', '346', '347']:
            if nid in api:
                node = api[nid]
                print(f'NID={nid} type={node.get("class_type")} inputs={list(node.get("inputs",{}).keys())}')
                # 检查 images/extended_images 字段
                inputs = node.get('inputs', {})
                for k in ['images', 'extended_images', 'new_images', 'source_images']:
                    if k in inputs:
                        print(f'  {k} -> {inputs[k]}')
    except Exception as e:
        print(f'Error: {e}')
