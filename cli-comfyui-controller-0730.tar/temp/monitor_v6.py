#!/usr/bin/env python3
"""监控v6任务执行进度（修复后验证）"""
import json
import time
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = '3e14f59b-9ecc-47c9-bb3a-51f36d7482ea'

def check():
    # 队列状态
    try:
        q = json.loads(urllib.request.urlopen(BASE+'/queue', timeout=5).read())
        running = q.get('queue_running', [])
        pending = q.get('queue_pending', [])
    except Exception as e:
        print(f'Queue error: {e}')
        return False

    # 历史
    try:
        h = json.loads(urllib.request.urlopen(BASE+'/history/'+PID, timeout=5).read())
    except Exception as e:
        print(f'History error: {e}')
        return False

    if PID in h:
        status = h[PID].get('status', {})
        status_str = status.get('status_str', '?')
        print(f'[{time.strftime("%H:%M:%S")}] Status: {status_str}')

        # 消息提取关键信息
        for msg_type, msg_data in status.get('messages', []):
            if msg_type == 'execution_error':
                print(f'  ERROR: {json.dumps(msg_data, ensure_ascii=False)[:500]}')
                return True
            elif msg_type == 'execution_success':
                print(f'  SUCCESS!')
                outputs = h[PID].get('outputs', {})
                print(f'  Outputs: {len(outputs)}')
                for nid, out in outputs.items():
                    print(f'    NID={nid}: {list(out.keys())}')
                return True

        # 系统统计
        try:
            s = json.loads(urllib.request.urlopen(BASE+'/system_stats', timeout=5).read())
            for dev in s.get('devices', []):
                if dev.get('type') == 'cuda':
                    free = dev.get('vram_free', 0) / 1024/1024
                    total = dev.get('vram_total', 0) / 1024/1024
                    used = total - free
                    print(f'  VRAM: {used:.0f}MB / {total:.0f}MB ({used/total*100:.1f}%)')
        except:
            pass
        return False if status_str == 'executing' else True
    else:
        print(f'[{time.strftime("%H:%M:%S")}] Running... (queue: running={len(running)} pending={len(pending)})')
        try:
            s = json.loads(urllib.request.urlopen(BASE+'/system_stats', timeout=5).read())
            for dev in s.get('devices', []):
                if dev.get('type') == 'cuda':
                    free = dev.get('vram_free', 0) / 1024/1024
                    total = dev.get('vram_total', 0) / 1024/1024
                    used = total - free
                    print(f'  VRAM: {used:.0f}MB / {total:.0f}MB ({used/total*100:.1f}%)')
        except:
            pass
        return False

print(f'Monitoring PID={PID}')
print('Press Ctrl+C to stop\n')

done = False
while not done:
    try:
        done = check()
        if not done:
            time.sleep(30)
    except KeyboardInterrupt:
        print('\nStopped by user')
        break
    except Exception as e:
        print(f'Error: {e}')
        time.sleep(10)
