#!/usr/bin/env python3
"""查看v6任务输出文件详情"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = '3e14f59b-9ecc-47c9-bb3a-51f36d7482ea'

h = json.loads(urllib.request.urlopen(BASE+'/history/'+PID, timeout=10).read())
if PID in h:
    outputs = h[PID].get('outputs', {})
    print(f'Outputs: {len(outputs)}')
    for nid, out in outputs.items():
        print(f'\nNID={nid}:')
        for fmt, items in out.items():
            print(f'  format: {fmt}')
            for item in items:
                fname = item.get('filename', '?')
                subfolder = item.get('subfolder', '')
                ftype = item.get('type', '?')
                print(f'    - {fname} (subfolder={subfolder}, type={ftype})')
                # 构建URL
                url = f'{BASE}/view?filename={fname}&subfolder={subfolder}&type={ftype}'
                print(f'      URL: {url}')

# 状态详情
status = h[PID].get('status', {})
print(f'\nStatus: {status.get("status_str")}')
for msg_type, msg_data in status.get('messages', []):
    if msg_type == 'execution_start':
        ts = msg_data.get('timestamp')
        print(f'Start: {ts}')
    elif msg_type == 'execution_success':
        ts = msg_data.get('timestamp')
        print(f'Success: {ts}')
