#!/usr/bin/env python3
"""检查 ImageBatchExtendWithOverlap 的 overlap_side 参数问题"""
import json

# 检查 UI 格式工作流中的 overlap_side widget 值
WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])

print('=== ImageBatchExtendWithOverlap nodes in UI workflow ===')
for n in nodes:
    if n.get('type') == 'ImageBatchExtendWithOverlap':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} widgets_values: {wv}')
        print(f'  types: {[type(v).__name__ for v in wv]}')

# 检查 API 格式中的 overlap_side 值
API_PATH = r'e:\comfyui-cli\temp\long_video_api.json'
with open(API_PATH, 'r', encoding='utf-8') as f:
    api = json.load(f)

print('\n=== ImageBatchExtendWithOverlap nodes in API workflow ===')
for nid, node in api.items():
    if node.get('class_type') == 'ImageBatchExtendWithOverlap':
        inputs = node.get('inputs', {})
        os_val = inputs.get('overlap_side', 'NOT SET')
        print(f'NID={nid} overlap_side: {os_val} (type={type(os_val).__name__})')
        print(f'  all inputs: {json.dumps(inputs, ensure_ascii=False)}')

# 检查 object_info 中 overlap_side 的 COMBO 选项
import urllib.request
print('\n=== overlap_side COMBO options ===')
try:
    with urllib.request.urlopen('http://127.0.0.1:3198/object_info/ImageBatchExtendWithOverlap', timeout=10) as resp:
        data = json.loads(resp.read())
    if 'ImageBatchExtendWithOverlap' in data:
        required = data['ImageBatchExtendWithOverlap'].get('input', {}).get('required', {})
        os_def = required.get('overlap_side', [])
        print(f'overlap_side definition: {os_def}')
        if isinstance(os_def, list) and len(os_def) > 0:
            options = os_def[0]
            print(f'Options: {options}')
            print(f'Valid values: source (index 0), new_images (index 1)')
except Exception as e:
    print(f'Error: {e}')

# 检查实际执行的 prompt 中的 overlap_side 值
PID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'
try:
    with urllib.request.urlopen(f'http://127.0.0.1:3198/history/{PID}', timeout=10) as resp:
        h = json.loads(resp.read())
    prompt = h[PID].get('prompt', [])
    workflow = prompt[2] if isinstance(prompt, list) and len(prompt) >= 3 else {}

    print('\n=== overlap_side in executed prompt ===')
    for nid in ['345', '346', '347', '348']:
        if nid in workflow:
            node = workflow[nid]
            inputs = node.get('inputs', {})
            os_val = inputs.get('overlap_side', 'NOT SET')
            print(f'NID={nid} overlap_side: {os_val} (type={type(os_val).__name__})')
except Exception as e:
    print(f'Error: {e}')
