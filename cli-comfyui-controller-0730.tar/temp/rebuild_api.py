#!/usr/bin/env python3
"""重新转换API格式, 确保ModelPatchTorchSettings的enable_fp16_accumulation作为显式输入"""
import json
import subprocess
import sys

# 1. 重新转换
print('=== 重新转换为API格式 ===')
result = subprocess.run([
    sys.executable,
    r'e:\comfyui-cli\comfyui-controller\scripts\workflow_converter.py',
    '--input', r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json',
    '--output', r'e:\comfyui-cli\temp\long_video_api.json',
    '--host', '127.0.0.1',
    '--port', '3198'
], capture_output=True, text=True)
print(result.stdout[:200] if result.stdout else '无输出')

# 2. 修改API JSON: 为ModelPatchTorchSettings添加enable_fp16_accumulation输入
api_path = r'e:\comfyui-cli\temp\long_video_api.json'
with open(api_path, 'r', encoding='utf-8') as f:
    api = json.load(f)

print(f'\nAPI节点数: {len(api)}')

# 查找所有ModelPatchTorchSettings节点
torch_nids = []
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_nids.append(nid)
            print(f'  NID={nid}: 添加 enable_fp16_accumulation=True')
        else:
            print(f'  NID={nid}: 已有 enable_fp16_accumulation={inputs["enable_fp16_accumulation"]}')

# 同时修改LoadImage节点指向2.png
for nid, node in api.items():
    if node.get('class_type') == 'LoadImage':
        old_img = node.get('inputs', {}).get('image', '?')
        node['inputs']['image'] = '2.png'
        print(f'  NID={nid} (LoadImage): {old_img} → 2.png')

with open(api_path, 'w', encoding='utf-8') as f:
    json.dump(api, f, ensure_ascii=False)

print(f'\n共修复 {len(torch_nids)} 个TorchSettings节点')
print('✓ API JSON已更新')

# 3. 提交
print('\n=== 提交工作流 ===')
import urllib.request
import urllib.error

prompt_url = 'http://127.0.0.1:3198/prompt'
prompt_data = json.dumps({'prompt': api}).encode('utf-8')
req = urllib.request.Request(prompt_url, data=prompt_data, headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    prompt_id = result.get('prompt_id')
    print(f'✓ 提交成功')
    print(f'prompt_id: {prompt_id}')

    with open(r'e:\comfyui-cli\temp\current_prompt_id.txt', 'w') as f:
        f.write(prompt_id)
except urllib.error.HTTPError as e:
    print(f'❌ 提交失败: HTTP {e.code}')
    err_body = e.read().decode('utf-8')
    print(f'错误: {err_body[:2000]}')
    sys.exit(1)
