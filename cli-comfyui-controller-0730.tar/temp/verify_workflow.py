#!/usr/bin/env python3
"""完整验证工作流结构"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']
links = wf['links']

link_ids = {L[0] for L in links}
node_ids = {n['id'] for n in nodes}

print(f'总节点: {len(nodes)}, 总链接: {len(links)}')

# 1. 检查悬空link引用（节点引用了不存在的link）
print('\n=== 1. 悬空link检查 ===')
dangling = 0
for n in nodes:
    for inp in n.get('inputs', []):
        lid = inp.get('link')
        if lid is not None and lid not in link_ids:
            print(f'  NID={n["id"]} input {inp.get("name")} link={lid} 不存在')
            dangling += 1
    for out in n.get('outputs', []):
        for lid in out.get('links', []) or []:
            if lid not in link_ids:
                print(f'  NID={n["id"]} output links 包含不存在的 link={lid}')
                dangling += 1
print(f'悬空link: {dangling}')

# 2. 检查link的src/dst节点是否存在
print('\n=== 2. Link端点检查 ===')
broken_endpoints = 0
for L in links:
    lid, src, src_slot, dst, dst_slot = L[0], L[1], L[2], L[3], L[4]
    if src not in node_ids:
        print(f'  link {lid}: src NID={src} 不存在')
        broken_endpoints += 1
    if dst not in node_ids:
        print(f'  link {lid}: dst NID={dst} 不存在')
        broken_endpoints += 1
print(f'端点损坏: {broken_endpoints}')

# 3. 验证SVI VAEDecode输出只连到ColorMatch
print('\n=== 3. SVI VAEDecode输出验证 ===')
svi_decodes = [232, 254, 276, 298, 320]
for nid in svi_decodes:
    n = next((x for x in nodes if x['id'] == nid), None)
    out_links = n['outputs'][0].get('links', [])
    print(f'  NID={nid} output links: {out_links}')
    for lid in out_links:
        L = next((l for l in links if l[0] == lid), None)
        if L:
            print(f'    -> link {lid}: dst=NID={L[3]}')

# 4. 验证Flux2输出只连到ColorMatch
print('\n=== 4. Flux2 ImageResize输出验证 ===')
flux2_outs = [98, 105, 112, 119]
for nid in flux2_outs:
    n = next((x for x in nodes if x['id'] == nid), None)
    out_links = n['outputs'][0].get('links', [])
    print(f'  NID={nid} output links: {out_links}')
    for lid in out_links:
        L = next((l for l in links if l[0] == lid), None)
        if L:
            print(f'    -> link {lid}: dst=NID={L[3]}')

# 5. 验证ColorMatch节点
print('\n=== 5. ColorMatch节点验证 ===')
for n in nodes:
    if n.get('type') == 'ColorMatch':
        nid = n['id']
        title = n.get('title', '')
        inputs = n.get('inputs', [])
        ref_link = inputs[0].get('link')
        target_link = inputs[1].get('link')
        out_links = n['outputs'][0].get('links', [])
        print(f'  NID={nid} {title}')
        print(f'    ref_link={ref_link}, target_link={target_link}, out_links={out_links}')
        # 验证ref来源
        if ref_link:
            L = next((l for l in links if l[0] == ref_link), None)
            if L:
                print(f'    ref <- NID={L[1]}')
        # 验证target来源
        if target_link:
            L = next((l for l in links if l[0] == target_link), None)
            if L:
                print(f'    target <- NID={L[1]}')
        # 验证输出去向
        for lid in out_links:
            L = next((l for l in links if l[0] == lid), None)
            if L:
                dst_node = next((x for x in nodes if x['id'] == L[3]), None)
                dst_title = dst_node.get('title', '') if dst_node else ''
                print(f'    out link {lid} -> NID={L[3]} ({dst_title})')

# 6. 检查悬空的link 534, 537, 540
print('\n=== 6. 检查可能的悬空link ===')
for lid in [534, 537, 540]:
    exists = lid in link_ids
    print(f'  link {lid} 存在: {exists}')
    if not exists:
        # 查找哪些节点引用了它
        for n in nodes:
            for out in n.get('outputs', []):
                if lid in (out.get('links', []) or []):
                    print(f'    被NID={n["id"]} output引用 (悬空)')
