#!/usr/bin/env python3
"""修复工作流验证错误:
1. SageAttention: sdpa → disabled (sdpa不是有效选项, disabled会回退到PyTorch原生sdpa)
2. ModelPatchTorchSettings: 添加enable_fp16_accumulation作为显式输入
"""
import json

DST = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(DST, 'r', encoding='utf-8') as f:
    data = json.load(f)

nodes = data.get('nodes', [])
fixed_count = 0

# 1. 修复 SageAttention: sdpa → disabled
for n in nodes:
    if 'Sage' in n.get('type', ''):
        wv = n.get('widgets_values', [])
        if wv and wv[0] == 'sdpa':
            wv[0] = 'disabled'
            fixed_count += 1
            print(f'  NID={n["id"]} ({n["type"]}): sage_attention sdpa → disabled')

# 2. 修复 ModelPatchTorchSettings: 添加enable_fp16_accumulation作为widget输入
# 错误显示required_input_missing: enable_fp16_accumulation
# 需要确保widgets_values包含该值
for n in nodes:
    if 'TorchSettings' in n.get('type', ''):
        # 检查当前widgets_values
        wv = n.get('widgets_values', [])
        if not wv or len(wv) == 0:
            # 添加enable_fp16_accumulation=True
            n['widgets_values'] = [True]
            fixed_count += 1
            print(f'  NID={n["id"]} ({n["type"]}): 添加 enable_fp16_accumulation=True')
        elif len(wv) == 1 and wv[0] is True:
            # 已经是[True], 但可能需要确保是enable_fp16_accumulation
            # 检查是否需要转换为dict格式
            pass
        elif isinstance(wv, dict):
            if 'enable_fp16_accumulation' not in wv:
                wv['enable_fp16_accumulation'] = True
                fixed_count += 1
                print(f'  NID={n["id"]} ({n["type"]}): dict添加 enable_fp16_accumulation=True')

# 3. 检查VHS video_formats路径问题 (这只是警告, 不影响执行)
# 错误: WinError 3 系统找不到指定的路径 video_formats
# 这是VHS节点的问题, 可能需要检查VHS安装
print(f'\n共修复 {fixed_count} 个节点')

with open(DST, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=1)

print('✓ 修复已保存')

# 验证
with open(DST, 'r', encoding='utf-8') as f:
    data = json.load(f)

for n in data['nodes']:
    if 'Sage' in n.get('type', ''):
        wv = n.get('widgets_values', [])
        print(f'  验证 NID={n["id"]}: sage_attention={wv[0] if wv else "?"}')
    if 'TorchSettings' in n.get('type', ''):
        wv = n.get('widgets_values', [])
        print(f'  验证 NID={n["id"]}: widgets_values={wv}')
