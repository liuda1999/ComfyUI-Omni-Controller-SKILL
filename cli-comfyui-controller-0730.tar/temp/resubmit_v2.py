#!/usr/bin/env python3
"""重新转换工作流并提交执行
   - 清除ComfyUI缓存
   - 使用修复后的工作流
   - 提交并返回prompt_id
"""
import json
import sys
import urllib.request

BASE = 'http://127.0.0.1:3198'
INPUT_WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUTPUT_API = r'e:\comfyui-cli\temp\long_video_api_v2.json'

# 导入转换器
sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import convert_web_to_api, get_object_info

# 1. 清除缓存（FreeMemory）
print('=== 1. Freeing memory ===')
try:
    req = urllib.request.Request(f'{BASE}/free', data=json.dumps({'unload_models': True, 'free_memory': True}).encode(), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=30) as resp:
        print(f'Free memory: {resp.status}')
except Exception as e:
    print(f'Free memory error: {e}')

# 2. 读取 UI 工作流
print('\n=== 2. Reading UI workflow ===')
with open(INPUT_WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)
print(f'Nodes: {len(wf.get("nodes", []))}')

# 3. 获取 object_info
print('\n=== 3. Getting object_info ===')
object_info = get_object_info('127.0.0.1', '3198')
print(f'object_info nodes: {len(object_info)}')

# 4. 转换为 API 格式
print('\n=== 4. Converting to API format ===')
api = convert_web_to_api(wf, object_info)
print(f'API nodes: {len(api)}')

# 5. 验证关键参数
print('\n=== 5. Verifying key parameters ===')

# LoadImage
for nid, node in api.items():
    if node.get('class_type') == 'LoadImage':
        img = node.get('inputs', {}).get('image')
        print(f'NID={nid} LoadImage: {img}')

# KSamplerAdvanced
for nid, node in api.items():
    if node.get('class_type') == 'KSamplerAdvanced':
        inputs = node.get('inputs', {})
        steps = inputs.get('steps')
        start = inputs.get('start_at_step')
        end = inputs.get('end_at_step')
        cfg = inputs.get('cfg')
        print(f'NID={nid} KSampler: steps={steps}, cfg={cfg}, start={start}, end={end}')

# Flux2Scheduler
for nid, node in api.items():
    if node.get('class_type') == 'Flux2Scheduler':
        inputs = node.get('inputs', {})
        print(f'NID={nid} Flux2Scheduler: {inputs}')

# LoRA
for nid, node in api.items():
    if node.get('class_type') == 'LoraLoaderModelOnly':
        inputs = node.get('inputs', {})
        lora_name = inputs.get('lora_name', '')
        strength = inputs.get('strength')
        if 'F2K' in lora_name or 'flux' in lora_name.lower():
            print(f'NID={nid} LoRA: {lora_name} strength={strength}')

# overlap_side
for nid in ['345', '346', '347', '348']:
    if nid in api:
        os_val = api[nid].get('inputs', {}).get('overlap_side')
        print(f'NID={nid} overlap_side: {os_val}')

# motion_latent_count
for nid in ['229', '251', '273', '295', '317']:
    if nid in api:
        mlc = api[nid].get('inputs', {}).get('motion_latent_count')
        print(f'NID={nid} motion_latent_count: {mlc}')

# VHS_VideoCombine
for nid, node in api.items():
    if node.get('class_type') == 'VHS_VideoCombine':
        images = node.get('inputs', {}).get('images')
        print(f'NID={nid} VHS_VideoCombine images: {images}')

# 6. 添加 ModelPatchTorchSettings 的 enable_fp16_accumulation
print('\n=== 6. Adding enable_fp16_accumulation ===')
torch_fixes = 0
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_fixes += 1
print(f'Fixed {torch_fixes} ModelPatchTorchSettings nodes')

# 7. 保存 API 工作流
print('\n=== 7. Saving API workflow ===')
with open(OUTPUT_API, 'w', encoding='utf-8') as f:
    json.dump(api, f, indent=2, ensure_ascii=False)
print(f'Saved to: {OUTPUT_API}')

# 8. 提交到 ComfyUI
print('\n=== 8. Submitting to ComfyUI ===')
payload = {
    'prompt': api,
    'client_id': 'comfyui-cli-monitor'
}
req = urllib.request.Request(
    f'{BASE}/prompt',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    print(f'Result: {json.dumps(result, ensure_ascii=False)}')
    prompt_id = result.get('prompt_id')
    if prompt_id:
        print(f'\nPrompt ID: {prompt_id}')
except urllib.error.HTTPError as e:
    print(f'HTTP Error: {e.code}')
    err_body = e.read().decode('utf-8')
    print(err_body[:2000])
except Exception as e:
    print(f'Error: {e}')
