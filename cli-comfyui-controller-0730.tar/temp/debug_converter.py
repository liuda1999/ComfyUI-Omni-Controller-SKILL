#!/usr/bin/env python3
"""调试workflow_converter的widget映射问题"""
import json
import urllib.request
import sys
sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import _filter_control_values, _get_widget_names_from_object_info, _get_widget_types_from_object_info

BASE_URL = 'http://127.0.0.1:3198'

# 获取object_info
with urllib.request.urlopen(f'{BASE_URL}/object_info', timeout=15) as resp:
    object_info = json.loads(resp.read())

# 加载UI工作流
ui_path = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
with open(ui_path, 'r', encoding='utf-8') as f:
    ui = json.load(f)

# 检查KSamplerAdvanced节点 NID=230
nid = 230
node = next(n for n in ui['nodes'] if n['id'] == nid)
wv = node.get('widgets_values', [])
print(f'NID={nid} ({node["type"]})')
print(f'  widgets_values (原始): {wv}')

# 过滤control值
filtered = _filter_control_values(wv)
print(f'  widgets_values (过滤后): {filtered}')

# 获取widget名称
widget_names = _get_widget_names_from_object_info('KSamplerAdvanced', object_info)
print(f'  widget_names (from object_info): {widget_names}')

widget_types = _get_widget_types_from_object_info('KSamplerAdvanced', object_info)
print(f'  widget_types (from object_info): {widget_types}')

# 手动映射
print(f'\n  映射结果:')
for idx, name in enumerate(widget_names):
    if idx < len(filtered):
        print(f'    {name} = {filtered[idx]}')
    else:
        print(f'    {name} = <缺失>')

# 检查KSamplerAdvanced的完整object_info
print(f'\nKSamplerAdvanced object_info:')
info = object_info['KSamplerAdvanced']
for section in ('required', 'optional'):
    print(f'  {section}:')
    for name, type_info in info['input'].get(section, {}).items():
        print(f'    {name}: {type_info}')

# 检查ImageScaleToTotalPixels
print(f'\n\n=== ImageScaleToTotalPixels NID=76 ===')
nid = 76
node = next(n for n in ui['nodes'] if n['id'] == nid)
wv = node.get('widgets_values', [])
print(f'  widgets_values: {wv}')
widget_names = _get_widget_names_from_object_info('ImageScaleToTotalPixels', object_info)
print(f'  widget_names: {widget_names}')
filtered = _filter_control_values(wv)
print(f'  filtered: {filtered}')
for idx, name in enumerate(widget_names):
    if idx < len(filtered):
        print(f'    {name} = {filtered[idx]}')

# 检查VHS_VideoCombine
print(f'\n\n=== VHS_VideoCombine NID=355 ===')
nid = 355
node = next(n for n in ui['nodes'] if n['id'] == nid)
wv = node.get('widgets_values', [])
print(f'  widgets_values type: {type(wv).__name__}')
print(f'  widgets_values: {wv}')
if isinstance(wv, dict):
    print(f'  keys: {list(wv.keys())}')
widget_names = _get_widget_names_from_object_info('VHS_VideoCombine', object_info)
print(f'  widget_names: {widget_names}')

# 检查KSamplerSelect
print(f'\n\n=== KSamplerSelect NID=89 ===')
nid = 89
node = next(n for n in ui['nodes'] if n['id'] == nid)
wv = node.get('widgets_values', [])
print(f'  widgets_values: {wv}')
widget_names = _get_widget_names_from_object_info('KSamplerSelect', object_info)
print(f'  widget_names: {widget_names}')
filtered = _filter_control_values(wv)
print(f'  filtered: {filtered}')
