#!/usr/bin/env python3
"""检查object_info中哪些字段有control_after_generate标记"""
import json
import urllib.request

BASE_URL = 'http://127.0.0.1:3198'
with urllib.request.urlopen(f'{BASE_URL}/object_info', timeout=15) as resp:
    object_info = json.loads(resp.read())

# 检查KSamplerAdvanced
info = object_info['KSamplerAdvanced']
print('KSamplerAdvanced required fields:')
for name, type_info in info['input']['required'].items():
    if isinstance(type_info, list) and len(type_info) > 1:
        opts = type_info[1]
        if isinstance(opts, dict) and opts.get('control_after_generate'):
            print(f'  {name}: control_after_generate=True, type={type_info[0]}')
        else:
            print(f'  {name}: type={type_info[0]}, opts={opts}')

# 修改_filter_control_values: 只有control_after_generate=True的INT字段才需要过滤
