#!/usr/bin/env python3
"""全程监控工作流执行 - 修复后版本
   prompt_id: bc4c1ef5-8dd0-4b61-be90-64f7d8df8f2e
"""
import json
import urllib.request
import time
import os
from datetime import datetime

BASE = 'http://127.0.0.1:3198'
PID = '11141f20-d06d-4421-8a35-a18b973057e9'
OUTPUT_DIR = r'D:\2026-ComfyUI-V8.3\output'

def get_queue():
    try:
        with urllib.request.urlopen(f'{BASE}/queue', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_history(pid):
    try:
        with urllib.request.urlopen(f'{BASE}/history/{pid}', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_system_stats():
    try:
        with urllib.request.urlopen(f'{BASE}/system_stats', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def check_output_files():
    files = []
    if os.path.isdir(OUTPUT_DIR):
        for f in os.listdir(OUTPUT_DIR):
            fp = os.path.join(OUTPUT_DIR, f)
            if os.path.isfile(fp):
                mtime = os.path.getmtime(fp)
                if mtime > time.time() - 3600:
                    files.append((f, os.path.getsize(fp), mtime))
    files.sort(key=lambda x: -x[2])
    return files

print(f'=== Monitoring Workflow {PID} ===')
print(f'Started at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
print(f'Parameters: 6-step dual sampler (HIGH 2+LOW 4) + Flux2 6-step correction')
print(f'Expected: 20-30 minutes')
print()

start_time = time.time()
check_interval = 30
last_output_count = 0
last_vram = 0

while True:
    elapsed = time.time() - start_time
    elapsed_min = elapsed / 60

    # 检查历史记录
    history = get_history(PID)
    if PID in history:
        data = history[PID]
        status = data.get('status', {}).get('status_str', 'unknown')

        if status in ('success', 'error'):
            print(f'\n{"="*60}')
            print(f'EXECUTION FINISHED: {status.upper()}')
            print(f'Total monitor time: {elapsed_min:.2f} minutes')

            # 计算执行时间
            messages = data.get('status', {}).get('messages', [])
            start_ts = None
            for msg_type, msg_data in messages:
                if msg_type == 'execution_start':
                    start_ts = msg_data.get('timestamp')
                    print(f'Execution start: {datetime.fromtimestamp(start_ts/1000).strftime("%H:%M:%S")}')
                elif msg_type == 'execution_success':
                    end_ts = msg_data.get('timestamp')
                    print(f'Execution end: {datetime.fromtimestamp(end_ts/1000).strftime("%H:%M:%S")}')
                    if start_ts:
                        dur = (end_ts - start_ts) / 1000
                        print(f'Duration: {dur:.1f}s = {dur/60:.2f} min')
                elif msg_type == 'execution_error':
                    print(f'Error: {json.dumps(msg_data, ensure_ascii=False)[:500]}')
                elif msg_type == 'execution_cached':
                    cached = msg_data.get('nodes', [])
                    print(f'Cached nodes: {len(cached)}')

            # 检查输出
            outputs = data.get('outputs', {})
            print(f'\nOutput nodes: {len(outputs)}')
            video_found = False
            image_count = 0
            for nid, out in outputs.items():
                out_keys = list(out.keys())
                if 'gifs' in out or 'videos' in out:
                    video_found = True
                    print(f'  NID={nid} VIDEO: {out_keys}')
                    for k in ('gifs', 'videos'):
                        if k in out:
                            for item in out[k]:
                                print(f'    {k}: {item.get("filename")} subfolder={item.get("subfolder","")}')
                elif 'images' in out:
                    image_count += 1
                    print(f'  NID={nid} IMAGE: {out.get("images",[{}])[0].get("filename","?")}')

            print(f'\nSummary: {image_count} images, {"1 video" if video_found else "NO video"}')

            # 检查输出文件
            print('\n=== Recent output files (last 24h) ===')
            recent = check_output_files()
            for f, size, mtime in recent[:20]:
                dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
                size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
                print(f'  {dt} {size_str:>10} {f}')

            print(f'\n{"="*60}')
            break

    # 检查队列状态
    queue = get_queue()
    running = len(queue.get('queue_running', []))
    pending = len(queue.get('queue_pending', []))

    # 检查系统统计
    stats = get_system_stats()
    vram_info = ''
    for dev in stats.get('devices', []):
        if dev.get('type') == 'cuda':
            vram_free = dev.get('vram_free', 0)
            vram_total = dev.get('vram_total', 0)
            used_mb = (vram_total - vram_free) / (1024*1024)
            total_mb = vram_total / (1024*1024)
            pct = used_mb / total_mb * 100 if total_mb > 0 else 0
            vram_info = f'{used_mb:.0f}MB/{total_mb:.0f}MB({pct:.0f}%)'

    # 检查输出文件
    recent = check_output_files()
    new_files = len(recent)

    ts = datetime.now().strftime('%H:%M:%S')
    status_str = 'running' if running > 0 else 'idle'
    print(f'[{ts}] {elapsed_min:.1f}min | {status_str} | VRAM:{vram_info} | files:{new_files}')

    # 显示新输出
    if new_files > last_output_count:
        for f, size, mtime in recent[:new_files - last_output_count]:
            dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
            size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
            print(f'  NEW: {dt} {size_str:>10} {f}')
        last_output_count = new_files

    # 超时检查
    if elapsed_min > 60:
        print(f'\nWARNING: Exceeded 60 minutes, still running...')
        if elapsed_min > 90:
            print('ERROR: Exceeded 90 minutes, aborting monitor')
            break

    time.sleep(check_interval)

print(f'\nMonitor ended: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
