#!/usr/bin/env python3
"""详细调试_get_widget_names_from_object_info"""
import json
import urllib.request
import sys
sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import _get_widget_names_from_object_info, _get_widget_types_from_object_info

BASE_URL = 'http://127.0.0.1:3198'
with urllib.request.urlopen(f'{BASE_URL}/object_info', timeout=15) as resp:
    object_info = json.loads(resp.read())

for nt in ['ImageScaleToTotalPixels', 'KSamplerSelect', 'VHS_VideoCombine']:
    print(f'\n=== {nt} ===')
    info = object_info.get(nt, {})
    print(f'  存在: {nt in object_info}')
    print(f'  input: {list(info.get("input", {}).keys()) if info else "N/A"}')

    if not info:
        continue

    # 手动检查每个字段
    for section in ('required', 'optional'):
        si = info.get('input', {}).get(section, {})
        if not si:
            continue
        print(f'  {section}:')
        for name, type_info in si.items():
            print(f'    {name}: type_info={type_info}, is_list={isinstance(type_info, list)}, len={len(type_info) if isinstance(type_info, list) else "N/A"}')
            if isinstance(type_info, list) and len(type_info) > 0:
                input_type = type_info[0]
                print(f'      input_type={input_type}, is_list={isinstance(input_type, list)}, is_str={isinstance(input_type, str)}')
                is_widget = isinstance(input_type, list) or input_type in ('INT', 'FLOAT', 'STRING')
                print(f'      is_widget={is_widget}')

    # 调用函数
    widget_names = _get_widget_names_from_object_info(nt, object_info)
    widget_types = _get_widget_types_from_object_info(nt, object_info)
    print(f'  widget_names: {widget_names}')
    print(f'  widget_types: {widget_types}')
