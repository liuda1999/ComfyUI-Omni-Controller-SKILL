#!/usr/bin/env python3
"""检查 ffmpeg 可用性和 VHS 节点配置"""
import json
import urllib.request
import os
import subprocess

BASE = 'http://127.0.0.1:3198'

# 1. 检查 object_info 中 VHS_VideoCombine 的定义
print('=== VHS_VideoCombine object_info ===')
try:
    with urllib.request.urlopen(f'{BASE}/object_info/VHS_VideoCombine', timeout=10) as resp:
        data = json.loads(resp.read())
    if 'VHS_VideoCombine' in data:
        node_info = data['VHS_VideoCombine']
        print(f'Input required: {list(node_info.get("input", {}).get("required", {}).keys())}')
        print(f'Input optional: {list(node_info.get("input", {}).get("optional", {}).keys())}')
        print(f'Output: {node_info.get("output")}')
        print(f'Output name: {node_info.get("output_name")}')
except Exception as e:
    print(f'Error: {e}')

# 2. 检查 WanImageToVideoSVIPro 的定义
print('\n=== WanImageToVideoSVIPro object_info ===')
try:
    with urllib.request.urlopen(f'{BASE}/object_info/WanImageToVideoSVIPro', timeout=10) as resp:
        data = json.loads(resp.read())
    if 'WanImageToVideoSVIPro' in data:
        node_info = data['WanImageToVideoSVIPro']
        print(f'Input required: {json.dumps(node_info.get("input", {}).get("required", {}), ensure_ascii=False, indent=2)[:1000]}')
        print(f'Input optional: {json.dumps(node_info.get("input", {}).get("optional", {}), ensure_ascii=False, indent=2)[:500]}')
except Exception as e:
    print(f'Error: {e}')

# 3. 检查 ImageBatchExtendWithOverlap 的定义
print('\n=== ImageBatchExtendWithOverlap object_info ===')
try:
    with urllib.request.urlopen(f'{BASE}/object_info/ImageBatchExtendWithOverlap', timeout=10) as resp:
        data = json.loads(resp.read())
    if 'ImageBatchExtendWithOverlap' in data:
        node_info = data['ImageBatchExtendWithOverlap']
        print(f'Input required: {json.dumps(node_info.get("input", {}).get("required", {}), ensure_ascii=False, indent=2)[:1000]}')
        print(f'Output: {node_info.get("output")}')
        print(f'Output name: {node_info.get("output_name")}')
except Exception as e:
    print(f'Error: {e}')

# 4. 检查 ffmpeg
print('\n=== ffmpeg check ===')
comfy_path = os.environ.get('COMFYUI_PATH', '')
print(f'COMFYUI_PATH: {comfy_path}')

# 检查系统 PATH 中的 ffmpeg
try:
    result = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True, timeout=5)
    print(f'system ffmpeg: returncode={result.returncode}')
    print(result.stdout[:200])
except Exception as e:
    print(f'system ffmpeg: NOT FOUND - {e}')

# 检查 ComfyUI 目录中的 ffmpeg
if comfy_path:
    ffmpeg_paths = [
        os.path.join(comfy_path, 'ffmpeg.exe'),
        os.path.join(comfy_path, 'python', 'Scripts', 'ffmpeg.exe'),
        os.path.join(comfy_path, 'python', 'Lib', 'site-packages', 'imageio_ffmpeg', 'binaries', 'ffmpeg.exe'),
    ]
    for p in ffmpeg_paths:
        if os.path.isfile(p):
            print(f'Found: {p}')
        else:
            print(f'Not found: {p}')

# 检查 imageio_ffmpeg
try:
    import importlib
    spec = importlib.util.find_spec('imageio_ffmpeg')
    print(f'imageio_ffmpeg package: {"installed" if spec else "NOT installed"}')
except Exception as e:
    print(f'imageio_ffmpeg check error: {e}')
