#!/usr/bin/env python3
"""修复：添加缺失的9个ColorMatch节点到nodes数组"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']
links = wf['links']

# 建立link索引
link_by_id = {L[0]: L for L in links}
node_by_id = {n['id']: n for n in nodes}

# 检查哪些ColorMatch节点应该存在但缺失
# 从links中找出类型为ColorMatch输入的link
# ref links: 543, 545, 547, 549, 551, 553, 555, 557, 559 (NID=75 -> CM)
# target links: 544, 546, 548, 550, 552, 554, 556, 558, 560 (src -> CM)

# 根据之前脚本：SVI CM NIDs = 365-369, Flux2 CM NIDs = 370-373
expected_cms = [
    (365, 'SVI1', 232),
    (366, 'SVI2', 254),
    (367, 'SVI3', 276),
    (368, 'SVI4', 298),
    (369, 'SVI5', 320),
    (370, 'Flux2_1to2', 98),
    (371, 'Flux2_2to3', 105),
    (372, 'Flux2_3to4', 112),
    (373, 'Flux2_4to5', 119),
]

# 检查每个CM节点是否存在
existing_cm_nids = {n['id'] for n in nodes if n.get('type') == 'ColorMatch'}
print(f'现有ColorMatch节点: {existing_cm_nids}')

# 找出每个缺失CM节点的位置（参考源节点位置）
for cm_nid, label, src_nid in expected_cms:
    if cm_nid in existing_cm_nids:
        print(f'  NID={cm_nid} ({label}) 已存在，跳过')
        continue

    src_node = node_by_id[src_nid]
    pos_x = src_node['pos'][0] + 350
    pos_y = src_node['pos'][1]

    # 找到该CM的ref link和target link
    ref_link = None
    target_link = None
    out_links = []

    for L in links:
        lid = L[0]
        # ref link: src=75, dst=cm_nid
        if L[1] == 75 and L[3] == cm_nid:
            ref_link = lid
        # target link: src=src_nid, dst=cm_nid
        if L[1] == src_nid and L[3] == cm_nid:
            target_link = lid
        # output link: src=cm_nid
        if L[1] == cm_nid:
            out_links.append(lid)

    print(f'  NID={cm_nid} ({label}): ref_link={ref_link}, target_link={target_link}, out_links={out_links}')

    # 创建ColorMatch节点
    cm_node = {
        "id": cm_nid,
        "type": "ColorMatch",
        "pos": [pos_x, pos_y],
        "size": [280, 150],
        "flags": {},
        "order": 0,
        "mode": 0,
        "inputs": [
            {
                "label": "image_ref",
                "name": "image_ref",
                "type": "IMAGE",
                "link": ref_link
            },
            {
                "label": "image_target",
                "name": "image_target",
                "type": "IMAGE",
                "link": target_link
            },
            {
                "label": "method",
                "name": "method",
                "type": "COMBO",
                "widget": {"name": "method"},
                "link": None
            },
            {
                "label": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {"name": "strength"},
                "link": None
            }
        ],
        "outputs": [
            {
                "label": "image",
                "name": "image",
                "type": "IMAGE",
                "links": out_links
            }
        ],
        "title": f"ColorMatch {label}",
        "properties": {
            "Node name for S&R": "ColorMatch"
        },
        "widgets_values": ["reinhard", 0.85]
    }
    nodes.append(cm_node)
    print(f'  已添加 NID={cm_nid}')

# 保存
with open(WF, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

# 验证
cm_count = sum(1 for n in nodes if n.get('type') == 'ColorMatch')
print(f'\nColorMatch节点总数: {cm_count}')
print(f'已保存到: {WF}')
