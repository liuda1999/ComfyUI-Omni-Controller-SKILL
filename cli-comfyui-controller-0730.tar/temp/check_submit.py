#!/usr/bin/env python3
"""检查实际提交的工作流"""
import json

path = r'e:\comfyui-cli\temp\long_video_submit.json'
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f'Type: {type(data).__name__}')
if isinstance(data, dict):
    print(f'Top-level keys: {list(data.keys())[:20]}')
    # 如果是 {prompt_id: {number, prompt, ...}} 格式
    for k, v in list(data.items())[:5]:
        print(f'\nKey: {k}')
        if isinstance(v, dict):
            print(f'  Sub-keys: {list(v.keys())}')
            if 'prompt' in v:
                prompt = v['prompt']
                print(f'  Prompt nodes: {len(prompt)}')
                # 查找 VHS
                for nid, node in prompt.items():
                    ct = node.get('class_type', '')
                    if 'VHS' in ct or 'VideoCombine' in ct:
                        print(f'  NID={nid} {ct}')
                        print(f'    inputs: {json.dumps(node.get("inputs", {}), ensure_ascii=False)[:300]}')
                # 检查 SaveImage 节点
                save_nids = []
                for nid, node in prompt.items():
                    if node.get('class_type') == 'SaveImage':
                        save_nids.append(nid)
                print(f'  SaveImage nodes: {save_nids}')
            elif isinstance(v, list) and len(v) > 0:
                print(f'  Value type: list of {len(v)} items')
                if isinstance(v[0], dict):
                    print(f'  First item keys: {list(v[0].keys())}')
