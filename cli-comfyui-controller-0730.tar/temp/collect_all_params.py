#!/usr/bin/env python3
"""收集工作流所有输入参数，用于生成完整报告"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']
node_by_id = {n['id']: n for n in nodes}

print('=' * 80)
print('工作流输入参数完整盘点')
print('=' * 80)

# 1. 模型加载相关
print('\n【1. 模型加载】')
model_types = ['UNETLoader', 'CheckpointLoaderSimple', 'VAELoader', 'CLIPLoader', 'LoraLoaderModelOnly', 'LoraLoader']
for n in nodes:
    if n.get('type') in model_types:
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 2. SVI Pro 节点参数
print('\n【2. SVI Pro 生成节点】')
for n in nodes:
    if 'SVI' in n.get('type', ''):
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 3. 采样器/调度器/Guider
print('\n【3. 采样器/调度器/Guider】')
sampler_types = ['KSamplerSelect', 'Flux2Scheduler', 'CFGGuider', 'SplitSigmasDenoise',
                 'WanVideoScheduler', 'WanVideoLinearCFGGuidance', 'WanVideoBlockSwap']
for n in nodes:
    if n.get('type') in sampler_types:
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 4. 提示词（正向+负向）
print('\n【4. 提示词节点】')
for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        text = wv[0] if wv else ''
        # 截断显示
        if len(text) > 200:
            text = text[:200] + '...'
        print(f'  NID={nid} ({title})')
        print(f'    text: {text}')

# 5. 图像处理节点
print('\n【5. 图像处理节点】')
img_types = ['LoadImage', 'ImageScaleToTotalPixels', 'ImageResizeKJv2', 'GetImageSize',
             'ImageFromBatch', 'ImageBatchExtendWithOverlap', 'ImageConcatMulti',
             'ImageUpscaleWithModel', 'ColorMatch']
for n in nodes:
    if n.get('type') in img_types:
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 6. ReferenceLatent
print('\n【6. ReferenceLatent 节点】')
for n in nodes:
    if 'ReferenceLatent' in n.get('type', ''):
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 7. ModelPatchTorchSettings
print('\n【7. ModelPatchTorchSettings 节点】')
for n in nodes:
    if n.get('type') == 'ModelPatchTorchSettings':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 8. 视频输出节点
print('\n【8. 视频输出节点】')
for n in nodes:
    if 'VHS_VideoCombine' in n.get('type', '') or 'SaveImage' in n.get('type', ''):
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {n["type"]} ({title})')
        print(f'    widgets: {wv}')

# 9. 统计
print('\n【9. 统计】')
print(f'  总节点数: {len(nodes)}')
print(f'  总链接数: {len(wf.get("links", []))}')
print(f'  分段数: 5段SVI + 4段Flux2换皮')
print(f'  ColorMatch节点: {sum(1 for n in nodes if n.get("type")=="ColorMatch")}')

# 10. 资源路径
print('\n【10. 资源路径】')
for n in nodes:
    if n.get('type') == 'LoadImage':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'  NID={nid} {title}: {wv}')
