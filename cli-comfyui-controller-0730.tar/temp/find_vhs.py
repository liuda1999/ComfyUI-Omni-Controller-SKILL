#!/usr/bin/env python3
"""查找 ComfyUI-VideoHelperSuite 和 video_formats 目录"""
import os

# 检查 VHS 目录
vhs_paths = [
    r'D:\2026-ComfyUI-V8.3\custom_nodes\ComfyUI-VideoHelperSuite',
    r'D:\2026-ComfyUI-V8.3\custom_nodes\ComfyUI-VideoHelperSuite\videohelpersuite',
    r'D:\2026-ComfyUI-V8.3\custom_nodes\ComfyUI-VideoHelperSuite\video_formats',
]

for p in vhs_paths:
    exists = os.path.isdir(p)
    print(f'{p}: {"EXISTS" if exists else "NOT FOUND"}')
    if exists and p.endswith('ComfyUI-VideoHelperSuite'):
        print(f'  Contents: {os.listdir(p)[:20]}')

# 搜索 custom_nodes 目录
cn_dir = r'D:\2026-ComfyUI-V8.3\custom_nodes'
if os.path.isdir(cn_dir):
    print(f'\n=== custom_nodes contents ===')
    for item in sorted(os.listdir(cn_dir)):
        item_path = os.path.join(cn_dir, item)
        if os.path.isdir(item_path):
            # 检查是否包含 videohelpersuite
            sub_items = []
            try:
                sub_items = os.listdir(item_path)[:10]
            except:
                pass
            vhs_related = any('video' in s.lower() or 'vhs' in s.lower() for s in sub_items)
            marker = ' <== VHS related' if vhs_related else ''
            print(f'  {item}/{marker}')
            if vhs_related:
                print(f'    sub: {sub_items}')

# 搜索 video_formats 目录
print('\n=== Searching for video_formats ===')
for root, dirs, files in os.walk(cn_dir):
    for d in dirs:
        if d == 'video_formats':
            print(f'  Found: {os.path.join(root, d)}')
            # 列出内容
            vf_path = os.path.join(root, d)
            try:
                print(f'    Contents: {os.listdir(vf_path)[:20]}')
            except:
                pass
    # 只搜索2层深度
    if root.count(os.sep) > cn_dir.count(os.sep) + 2:
        dirs.clear()
