#!/usr/bin/env python3
"""持续监控工作流执行
   - 每30秒查询一次队列状态、历史记录和系统统计
   - 跟踪VRAM使用情况
   - 检测执行完成或错误
   - 验证最终输出
"""
import json
import urllib.request
import time
import os
from datetime import datetime

BASE = 'http://127.0.0.1:3198'
PID = 'e9f9b1b1-c488-4b50-9f10-303ef46cd3e5'
OUTPUT_DIR = r'D:\2026-ComfyUI-V8.3\output'

def get_queue():
    try:
        with urllib.request.urlopen(f'{BASE}/queue', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_history(pid):
    try:
        with urllib.request.urlopen(f'{BASE}/history/{pid}', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def get_system_stats():
    try:
        with urllib.request.urlopen(f'{BASE}/system_stats', timeout=5) as resp:
            return json.loads(resp.read())
    except:
        return {}

def format_vram(vram_free, vram_total):
    free_mb = vram_free / (1024*1024)
    total_mb = vram_total / (1024*1024)
    used_mb = total_mb - free_mb
    pct = (used_mb / total_mb * 100) if total_mb > 0 else 0
    return f'{used_mb:.0f}MB / {total_mb:.0f}MB ({pct:.1f}%)'

def check_output_files():
    """检查输出目录中新生成的文件"""
    files = []
    if os.path.isdir(OUTPUT_DIR):
        for f in os.listdir(OUTPUT_DIR):
            fp = os.path.join(OUTPUT_DIR, f)
            if os.path.isfile(fp):
                mtime = os.path.getmtime(fp)
                # 只返回最近1小时内的文件
                if mtime > time.time() - 3600:
                    files.append((f, os.path.getsize(fp), mtime))
    files.sort(key=lambda x: -x[2])  # 按修改时间降序
    return files

print(f'=== Monitoring Workflow {PID} ===')
print(f'Started at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
print(f'Expected duration: 30-40 minutes')
print()

start_time = time.time()
check_interval = 30  # 30秒
last_output_count = 0

while True:
    elapsed = time.time() - start_time
    elapsed_min = elapsed / 60

    # 检查历史记录（是否已完成）
    history = get_history(PID)
    if PID in history:
        data = history[PID]
        status = data.get('status', {}).get('status_str', 'unknown')
        completed = data.get('status', {}).get('completed', False)

        if status in ('success', 'error'):
            print(f'\n{"="*60}')
            print(f'EXECUTION FINISHED: {status.upper()}')
            print(f'Total time: {elapsed_min:.2f} minutes')

            # 计算执行时间
            messages = data.get('status', {}).get('messages', [])
            for msg_type, msg_data in messages:
                if msg_type == 'execution_start':
                    start_ts = msg_data.get('timestamp')
                    print(f'Execution start timestamp: {start_ts}')
                elif msg_type == 'execution_success':
                    end_ts = msg_data.get('timestamp')
                    print(f'Execution end timestamp: {end_ts}')
                    if start_ts:
                        dur = (end_ts - start_ts) / 1000
                        print(f'Execution duration: {dur:.1f}s = {dur/60:.2f} min')
                elif msg_type == 'execution_error':
                    print(f'Error details: {json.dumps(msg_data, ensure_ascii=False)[:500]}')

            # 检查输出
            outputs = data.get('outputs', {})
            print(f'\nOutput nodes: {len(outputs)}')
            video_found = False
            for nid, out in outputs.items():
                out_keys = list(out.keys())
                print(f'  NID={nid}: {out_keys}')
                if 'gifs' in out or 'videos' in out:
                    video_found = True
                    for k in ('gifs', 'videos'):
                        if k in out:
                            for item in out[k]:
                                print(f'    {k}: {item.get("filename")} ({item.get("subfolder","")})')

            if not video_found:
                print('\nWARNING: No video output found!')

            # 检查输出文件
            print('\n=== Recent output files ===')
            recent = check_output_files()
            for f, size, mtime in recent[:15]:
                dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
                size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
                print(f'  {dt} {size_str:>10} {f}')

            print(f'\n{"="*60}')
            break

    # 检查队列状态
    queue = get_queue()
    running = len(queue.get('queue_running', []))
    pending = len(queue.get('queue_pending', []))

    # 检查系统统计
    stats = get_system_stats()
    devices = stats.get('devices', [])
    vram_info = ''
    for dev in devices:
        if dev.get('type') == 'cuda':
            vram_free = dev.get('vram_free', 0)
            vram_total = dev.get('vram_total', 0)
            vram_info = format_vram(vram_free, vram_total)

    # 检查输出文件
    recent = check_output_files()
    new_files = len(recent)

    ts = datetime.now().strftime('%H:%M:%S')
    print(f'[{ts}] elapsed={elapsed_min:.1f}min | queue: run={running} pend={pending} | VRAM: {vram_info} | outputs: {new_files}')

    # 如果有新输出文件，显示
    if new_files > last_output_count:
        for f, size, mtime in recent[:new_files - last_output_count]:
            dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
            size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
            print(f'  NEW: {dt} {size_str:>10} {f}')
        last_output_count = new_files

    # 超时检查（60分钟）
    if elapsed_min > 60:
        print(f'\nWARNING: Execution exceeded 60 minutes, still running...')
        if elapsed_min > 90:
            print('ERROR: Execution exceeded 90 minutes, aborting monitor')
            break

    time.sleep(check_interval)

print(f'\nMonitor ended at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
