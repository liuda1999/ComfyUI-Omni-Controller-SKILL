#!/usr/bin/env python3
"""查看v7任务输出文件详情"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = '950a9091-e794-4cb0-82e8-0945a2964aeb'

h = json.loads(urllib.request.urlopen(BASE+'/history/'+PID, timeout=10).read())
if PID in h:
    outputs = h[PID].get('outputs', {})
    print(f'Outputs: {len(outputs)}')
    for nid, out in outputs.items():
        print(f'\nNID={nid}:')
        for fmt, items in out.items():
            print(f'  format: {fmt}')
            for item in items:
                fname = item.get('filename', '?')
                subfolder = item.get('subfolder', '')
                ftype = item.get('type', '?')
                print(f'    - {fname} (subfolder={subfolder}, type={ftype})')

status = h[PID].get('status', {})
print(f'\nStatus: {status.get("status_str")}')
for msg_type, msg_data in status.get('messages', []):
    if msg_type == 'execution_start':
        print(f'Start: {msg_data.get("timestamp")}')
    elif msg_type == 'execution_success':
        print(f'Success: {msg_data.get("timestamp")}')
