#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""混合策略修复后人物外貌一致性客观验证
对比参考图与00003(修复前)/00004(修复后)各段生成结果。
指标：
  - HSV色彩直方图相关性 (0~1, 越高越相似, 评估整体外貌/肤色/服装色彩)
  - 中心人脸区域直方图相关性 (评估五官/肤色)
  - MSE 像素均方误差 (越低越相似)
  - 平均色彩偏差 (RGB各通道均值差)
"""
import cv2
import numpy as np
import os

REF = r'D:\2026-ComfyUI-V8.3\input\2.png'
OUT = r'D:\2026-ComfyUI-V8.3\output'
TARGET_W, TARGET_H = 480, 848  # 生成帧尺寸

def load_gray_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img  # BGR

def resize_to(img, w, h):
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)

def hsv_hist(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1, 2], None, [50, 60, 60],
                        [0, 180, 0, 256, 0, 256])
    cv2.normalize(hist, hist, 0, 1, cv2.NORM_MINMAX)
    return hist

def hist_corr(h1, h2):
    # cv2.HISTCMP_CORREL: -1~1
    return cv2.compareHist(h1, h2, cv2.HISTCMP_CORREL)

def hist_bhatt(h1, h2):
    # Bhattacharyya: 0(同)~1(异)
    return cv2.compareHist(h1, h2, cv2.HISTCMP_BHATTACHARYYA)

def center_crop(img, frac=0.5):
    """中心裁剪, 取人物上半部(人脸区域大致在上方)"""
    h, w = img.shape[:2]
    # 人脸一般在画面上方1/4~3/4区域, 取中心50%宽, 上半60%高
    x0 = int(w * 0.25)
    x1 = int(w * 0.75)
    y0 = int(h * 0.10)
    y1 = int(h * 0.55)
    return img[y0:y1, x0:x1]

def mse(a, b):
    return float(np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2))

def mean_color_diff(a, b):
    a_m = a.reshape(-1, 3).mean(axis=0)
    b_m = b.reshape(-1, 3).mean(axis=0)
    return b_m - a_m  # BGR差值

# 参考图
ref_full = load_gray_rgb(REF)
ref = resize_to(ref_full, TARGET_W, TARGET_H)
ref_hist = hsv_hist(ref)
ref_face = center_crop(ref)
ref_face_hist = hsv_hist(ref_face)
ref_mean = ref.reshape(-1, 3).mean(axis=0)

print('=' * 90)
print('参考图: 2.png (1072x1920 -> 缩放至 480x848 用于对比)')
print(f'参考图平均色(BGR): {ref_mean.round(1)}')
print('=' * 90)

# 定义对比项
def seg_items(ver):
    return [
        (f'段1末帧 SVI      ', f'c8_1to2_last_{ver}_.png'),
        (f'段1 Flux2修正    ', f'c8_flux2_1to2_out_{ver}_.png'),
        (f'段2末帧 SVI(混合) ', f'c8_2to3_last_{ver}_.png'),
        (f'段2 Flux2修正    ', f'c8_flux2_2to3_out_{ver}_.png'),
        (f'段3末帧 SVI(混合) ', f'c8_3to4_last_{ver}_.png'),
        (f'段3 Flux2修正    ', f'c8_flux2_3to4_out_{ver}_.png'),
        (f'段4末帧 SVI(混合) ', f'c8_4to5_last_{ver}_.png'),
        (f'段4 Flux2修正    ', f'c8_flux2_4to5_out_{ver}_.png'),
    ]

def analyze(ver):
    print(f'\n### 版本 {ver} ({"修复后-混合策略" if ver=="00004" else "修复前-基线"}) ###')
    print(f'{"项目":<20}{"HSV相关":>9}{"Bhatt":>8}{"人脸HSV相关":>13}{"MSE":>10}{"BGR偏差":>22}')
    rows = []
    for label, fname in seg_items(ver):
        path = os.path.join(OUT, fname)
        if not os.path.exists(path):
            print(f'{label}  [缺失] {fname}')
            continue
        img = load_gray_rgb(path)
        if img.shape[:2] != (TARGET_H, TARGET_W):
            img = resize_to(img, TARGET_W, TARGET_H)
        h = hsv_hist(img)
        hc = hist_corr(ref_hist, h)
        hb = hist_bhatt(ref_hist, h)
        face = center_crop(img)
        fh = hsv_hist(face)
        fhc = hist_corr(ref_face_hist, fh)
        m = mse(ref, img)
        cd = mean_color_diff(ref, img)
        rows.append((label, hc, hb, fhc, m, cd))
        print(f'{label:<20}{hc:>9.3f}{hb:>8.3f}{fhc:>13.3f}{m:>10.1f}  [{cd[0]:+.0f},{cd[1]:+.0f},{cd[2]:+.0f}]')
    return rows

rows04 = analyze('00004')
rows03 = analyze('00003')

# 漂移分析: 段1->段4 与参考图相似度变化趋势
print('\n' + '=' * 90)
print('### 漂移趋势分析 (SVI末帧 与参考图的HSV相关性, 段1→段4) ###')
print(f'{"版本":<10}{"段1":>8}{"段2":>8}{"段3":>8}{"段4":>8}{"段4-段1差":>12}{"趋势":>10}')
for ver, rows in [('00003', rows03), ('00004', rows04)]:
    svi = [r[1] for r in rows if 'SVI' in r[0]]
    if len(svi) >= 4:
        diff = svi[3] - svi[0]
        trend = '漂移↓' if diff < -0.03 else ('稳定→' if abs(diff) <= 0.03 else '回升↑')
        print(f'{ver:<10}{svi[0]:>8.3f}{svi[1]:>8.3f}{svi[2]:>8.3f}{svi[3]:>8.3f}{diff:>+12.3f}{trend:>10}')

print('\n### Flux2修正效果 (SVI末帧 vs Flux2修正 与参考图相关性) ###')
print(f'{"版本":<10}{"段":<6}{"SVI末帧":>10}{"Flux2修正":>11}{"提升":>9}')
for ver, rows in [('00003', rows03), ('00004', rows04)]:
    svi = [r for r in rows if 'SVI' in r[0]]
    flx = [r for r in rows if 'Flux2' in r[0]]
    for i in range(min(len(svi), len(flx))):
        s = svi[i][1]
        f = flx[i][1]
        print(f'{ver:<10}段{i+1:<5}{s:>10.3f}{f:>11.3f}{f-s:>+9.3f}')

# 视频预览图
print('\n' + '=' * 90)
print('### 视频预览图对比 ###')
vp = os.path.join(OUT, 'WanVideo2_2_I2V_20s_00002.png')
if os.path.exists(vp):
    vimg = load_gray_rgb(vp)
    vimg_r = resize_to(vimg, TARGET_W, TARGET_H)
    vh = hsv_hist(vimg_r)
    vhc = hist_corr(ref_hist, vh)
    vface = center_crop(vimg_r)
    vfhc = hist_corr(ref_face_hist, hsv_hist(vface))
    vm = mse(ref, vimg_r)
    print(f'视频预览 WanVideo2_2_I2V_20s_00002.png (原始 {vimg.shape[1]}x{vimg.shape[0]})')
    print(f'  vs参考图: HSV相关={vhc:.3f}  人脸HSV相关={vfhc:.3f}  MSE={vm:.1f}')

# 版本对比汇总
print('\n' + '=' * 90)
print('### 00004(修复后) vs 00003(修复前) 平均相似度对比 ###')
def avg(rows, idx):
    return np.mean([r[idx] for r in rows]) if rows else 0
print(f'{"指标":<22}{"00003":>10}{"00004":>10}{"变化":>10}')
for idx, name in [(1,'HSV相关(整体)'),(3,'HSV相关(人脸)'),(4,'MSE(越低越好)')]:
    a, b = avg(rows03, idx), avg(rows04, idx)
    better = '改善↑' if (idx != 4 and b > a) or (idx == 4 and b < a) else '下降↓'
    print(f'{name:<22}{a:>10.3f}{b:>10.3f}{(b-a):>+10.3f}  {better}')
print('=' * 90)
