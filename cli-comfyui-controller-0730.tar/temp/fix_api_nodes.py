#!/usr/bin/env python3
"""修复API格式工作流中的节点参数错位问题
KSamplerAdvanced的widgets_values顺序与INPUT_TYPES不匹配
需要根据object_info重新映射参数
"""
import json
import urllib.request

BASE_URL = 'http://127.0.0.1:3198'

# 获取object_info
print('=== 获取object_info ===')
with urllib.request.urlopen(f'{BASE_URL}/object_info', timeout=15) as resp:
    object_info = json.loads(resp.read())

# 加载API工作流
api_path = r'e:\comfyui-cli\temp\long_video_api.json'
with open(api_path, 'r', encoding='utf-8') as f:
    api = json.load(f)

# 1. 修复KSamplerAdvanced节点
print('\n=== 修复KSamplerAdvanced ===')
ks_info = object_info.get('KSamplerAdvanced', {})
ks_required = list(ks_info.get('input', {}).get('required', {}).keys())
print(f'KSamplerAdvanced required字段顺序: {ks_required}')

ks_nids = []
for nid, node in api.items():
    if node.get('class_type') == 'KSamplerAdvanced':
        ks_nids.append(nid)

print(f'找到 {len(ks_nids)} 个KSamplerAdvanced节点')

# KSamplerAdvanced的required字段顺序:
# model, noise, positive, negative, sampler_name, scheduler, start_at_step, end_at_step,
# return_with_leftover_noise, add_noise, steps, cfg, denoise
# (最后三个可能是advanced)
# 实际UI中widget顺序: add_noise, noise_seed, steps, cfg, sampler_name, scheduler, start_at_step, end_at_step, return_with_leftover_noise
# 需要正确映射

for nid in ks_nids:
    node = api[nid]
    inputs = node.get('inputs', {})

    # 检查当前inputs中的值, 找出错误映射
    # 错误现象: cfg='euler', scheduler=1, sampler_name='simple', add_noise=214
    # 这说明widget顺序被错位了

    # 正确的widget值应该来自原始UI工作流
    # 从原始UI工作流读取正确的值
    pass

# 2. 更好的方案: 直接从UI工作流读取KSamplerAdvanced的widgets_values
# 然后手动构建正确的API inputs
ui_path = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
with open(ui_path, 'r', encoding='utf-8') as f:
    ui = json.load(f)

ui_nid_map = {n['id']: n for n in ui['nodes']}

# KSamplerAdvanced widget顺序 (从UI): [add_noise, noise_seed, steps, cfg, sampler_name, scheduler, start_at_step, end_at_step, return_with_leftover_noise]
# 但实际可能不同, 需要根据object_info确认
# object_info中required顺序: model, noise, positive, negative, sampler_name, scheduler, start_at_step, end_at_step, return_with_leftover_noise
# optional: add_noise, noise_seed, steps, cfg, denoise

# 修复每个KSamplerAdvanced
for nid in ks_nids:
    node = api[nid]
    nid_int = int(nid)
    ui_node = ui_nid_map.get(nid_int)

    if not ui_node:
        print(f'  NID={nid}: 找不到UI节点')
        continue

    wv = ui_node.get('widgets_values', [])
    if len(wv) < 9:
        print(f'  NID={nid}: widgets_values长度不足 {len(wv)}')
        continue

    # UI widget顺序: [add_noise, noise_seed, steps, cfg, sampler_name, scheduler, start_at_step, end_at_step, return_with_leftover_noise]
    add_noise = wv[0]      # 'enable' or 'disable'
    noise_seed = wv[1]     # int
    steps = wv[2]          # int
    cfg = wv[3]            # float
    sampler_name = wv[4]   # string
    scheduler = wv[5]      # string
    start_at_step = wv[6]  # int
    end_at_step = wv[7]    # int
    return_with_leftover = wv[8]  # 'enable' or 'disable'

    # 更新API inputs (保留已有的连接引用)
    inputs = node.get('inputs', {})
    inputs['add_noise'] = add_noise
    inputs['noise_seed'] = noise_seed
    inputs['steps'] = steps
    inputs['cfg'] = cfg
    inputs['sampler_name'] = sampler_name
    inputs['scheduler'] = scheduler
    inputs['start_at_step'] = start_at_step
    inputs['end_at_step'] = end_at_step
    inputs['return_with_leftover_noise'] = return_with_leftover

    node['inputs'] = inputs
    print(f'  NID={nid}: steps={steps}, cfg={cfg}, sampler={sampler_name}, scheduler={scheduler}, start={start_at_step}, end={end_at_step}')

# 3. 修复VHS_VideoCombine节点
print('\n=== 修复VHS_VideoCombine ===')
vhs_info = object_info.get('VHS_VideoCombine', {})
vhs_required = list(vhs_info.get('input', {}).get('required', {}).keys())
print(f'VHS_VideoCombine required字段: {vhs_required}')

for nid, node in api.items():
    if node.get('class_type') == 'VHS_VideoCombine':
        nid_int = int(nid)
        ui_node = ui_nid_map.get(nid_int)
        if not ui_node:
            continue

        wv = ui_node.get('widgets_values', [])
        # VHS widget顺序: [frame_rate, loop_count, filename_prefix, format, save_output, pingpong, ...]
        # 但可能是dict格式
        inputs = node.get('inputs', {})

        if isinstance(wv, dict):
            # 直接映射
            for k, v in wv.items():
                if k not in inputs:
                    inputs[k] = v
        elif isinstance(wv, list):
            # 按顺序映射
            # 从object_info确认顺序
            vhs_widgets = []
            for key in vhs_required:
                info_val = vhs_info['input']['required'][key]
                if isinstance(info_val, list) and len(info_val) >= 1 and info_val[0] != 'IMAGE' and info_val[0] != 'AUDIO' and info_val[0] != 'VAE':
                    vhs_widgets.append(key)

            print(f'  VHS widgets顺序: {vhs_widgets}')
            print(f'  VHS widgets_values: {wv}')

            # 手动映射
            if len(wv) >= 6:
                inputs['frame_rate'] = wv[0] if isinstance(wv[0], (int, float)) else 16
                inputs['loop_count'] = wv[1] if isinstance(wv[1], int) else 0
                inputs['filename_prefix'] = wv[2] if isinstance(wv[2], str) else 'WanVideo2_2_I2V_24s'
                inputs['format'] = wv[3] if isinstance(wv[3], str) else 'video/h264-mp4'
                inputs['save_output'] = wv[4] if isinstance(wv[4], bool) else True
                inputs['pingpong'] = wv[5] if isinstance(wv[5], bool) else False

        node['inputs'] = inputs
        print(f'  NID={nid}: frame_rate={inputs.get("frame_rate")}, format={inputs.get("format")}')

# 4. 修复其他可能有问题的节点
# 检查所有节点的required字段是否都有
print('\n=== 检查所有节点的required字段 ===')
missing_count = 0
for nid, node in api.items():
    class_type = node.get('class_type', '')
    if class_type not in object_info:
        continue

    info = object_info[class_type]
    required = info.get('input', {}).get('required', {})

    for field in required:
        if field not in node.get('inputs', {}):
            # 检查是否是连接类型(MODEL, IMAGE等)
            field_type = required[field]
            if isinstance(field_type, list) and len(field_type) > 0:
                type_name = field_type[0]
                # 如果是连接类型, 检查是否在inputs中作为连接引用
                if isinstance(node.get('inputs', {}).get(field), list):
                    continue  # 已有连接引用
                # 如果是widget类型但缺失, 添加默认值
                if type_name in ['BOOLEAN']:
                    node['inputs'][field] = field_type[1].get('default', False) if len(field_type) > 1 else False
                    missing_count += 1
                elif type_name in ['INT']:
                    default = field_type[1].get('default', 0) if len(field_type) > 1 else 0
                    node['inputs'][field] = default
                    missing_count += 1
                elif type_name in ['FLOAT']:
                    default = field_type[1].get('default', 1.0) if len(field_type) > 1 else 1.0
                    node['inputs'][field] = default
                    missing_count += 1
                elif type_name == 'COMBO' or isinstance(type_name, list):
                    options = field_type[0] if isinstance(field_type[0], list) else field_type
                    if isinstance(options, list) and len(options) > 0:
                        node['inputs'][field] = options[0]
                        missing_count += 1

print(f'  补充了 {missing_count} 个缺失字段')

# 保存
with open(api_path, 'w', encoding='utf-8') as f:
    json.dump(api, f, ensure_ascii=False)

print('\n✓ API工作流已修复')

# 5. 验证提交
print('\n=== 验证提交 ===')
import urllib.error
prompt_url = f'{BASE_URL}/prompt'
prompt_data = json.dumps({'prompt': api}).encode('utf-8')
req = urllib.request.Request(prompt_url, data=prompt_data, headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    prompt_id = result.get('prompt_id')
    print(f'✓ 提交成功')
    print(f'prompt_id: {prompt_id}')

    with open(r'e:\comfyui-cli\temp\current_prompt_id.txt', 'w') as f:
        f.write(prompt_id)
except urllib.error.HTTPError as e:
    print(f'❌ 提交失败: HTTP {e.code}')
    err_body = e.read().decode('utf-8')
    # 解析错误
    try:
        err_data = json.loads(err_body)
        node_errors = err_data.get('node_errors', {})
        print(f'错误节点数: {len(node_errors)}')
        for nid, errs in list(node_errors.items())[:5]:
            print(f'  NID={nid} ({api.get(nid,{}).get("class_type","")}):')
            for e in errs.get('errors', []):
                print(f'    - {e.get("type")}: {e.get("details","")}')
    except:
        print(f'错误: {err_body[:1000]}')
    sys.exit(1)
