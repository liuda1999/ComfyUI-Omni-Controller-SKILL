#!/usr/bin/env python3
"""
最终时间压缩: 目标30分钟
策略: 25帧×3步 + 跳过RealESRGAN放大(BYPASS mode=4)
"""
import json

path = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)

nodes = data.get('nodes', [])
nid_map = {n.get('id'): n for n in nodes}

print('=== 最终压缩优化 (目标30分钟) ===\n')

# 1. SVI Pro帧数: 33→25 (进一步降低24%)
print('--- 1. SVI Pro帧数 33→25 ---')
svi_nids = [229, 251, 273, 295, 317]
for nid in svi_nids:
    n = nid_map.get(nid)
    if n and 'SVIPro' in n.get('type', ''):
        wv = n.get('widgets_values', [])
        if len(wv) >= 1:
            old = wv[0]
            wv[0] = 25
            print(f'  NID={nid}: {old}→25')

# 2. 跳过RealESRGAN放大 (ImageUpscaleWithModel mode=4 BYPASS)
print('\n--- 2. 跳过RealESRGAN放大 (BYPASS) ---')
upscale_nids = [363, 360, 358, 356, 343]  # 5个ImageUpscaleWithModel
for nid in upscale_nids:
    n = nid_map.get(nid)
    if n:
        n['mode'] = 4  # BYPASS: 输入image直接传给输出
        print(f'  NID={nid} ({n.get("type")}): mode=4 (BYPASS)')

# UpscaleModelLoader也BYPASS
n362 = nid_map.get(362)
if n362:
    n362['mode'] = 4
    print(f'  NID=362 (UpscaleModelLoader): mode=4 (BYPASS)')

# 3. 更新Note节点
print('\n--- 3. 更