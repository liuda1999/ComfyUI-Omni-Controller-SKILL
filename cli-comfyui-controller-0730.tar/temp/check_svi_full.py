#!/usr/bin/env python3
"""检查SVI Pro节点的完整inputs和widgets_values"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

# 检查所有SVI Pro节点
for n in nodes:
    if n.get('type') == 'WanImageToVideoSVIPro':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'\n{"="*70}')
        print(f'NID={nid} title={title}')
        print(f'{"="*70}')

        print(f'\n--- inputs (连接输入) ---')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None:
                if link_id in link_map:
                    src_node = link_map[link_id][1]
                    src_obj = nodes_by_id.get(src_node, {})
                    print(f'  {name}: link={link_id} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')
                else:
                    print(f'  {name}: link={link_id} (NOT FOUND in link_map)')
            else:
                print(f'  {name}: link=None (未连接)')

        print(f'\n--- widgets_values ---')
        wv = n.get('widgets_values', [])
        for i, v in enumerate(wv):
            vstr = str(v)
            if len(vstr) > 100:
                vstr = vstr[:100] + '...'
            print(f'  [{i}]: {vstr}')

        print(f'\n--- outputs ---')
        for i, out in enumerate(n.get('outputs', [])):
            name = out.get('name')
            links_out = out.get('links', [])
            print(f'  [{i}] {name}: links={links_out}')
