#!/usr/bin/env python3
"""提交API格式工作流到 /prompt 端点"""
import json
import urllib.request
import urllib.error
import sys

API_PATH = r'e:\comfyui-cli\temp\long_video_api.json'
BASE_URL = 'http://127.0.0.1:3198'

with open(API_PATH, 'r', encoding='utf-8') as f:
    api_workflow = json.load(f)

print(f'API工作流节点数: {len(api_workflow)}')

# 提交
prompt_url = f'{BASE_URL}/prompt'
prompt_data = json.dumps({'prompt': api_workflow}).encode('utf-8')
req = urllib.request.Request(prompt_url, data=prompt_data, headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    prompt_id = result.get('prompt_id')
    print(f'✓ 提交成功')
    print(f'prompt_id: {prompt_id}')

    # 保存prompt_id
    with open(r'e:\comfyui-cli\temp\current_prompt_id.txt', 'w') as f:
        f.write(prompt_id)
    print(f'node_count: {len(api_workflow)}')
except urllib.error.HTTPError as e:
    print(f'❌ 提交失败: HTTP {e.code}')
    err_body = e.read().decode('utf-8')
    print(f'错误: {err_body[:2000]}')
    sys.exit(1)
except Exception as e:
    print(f'❌ 异常: {e}')
    sys.exit(1)
