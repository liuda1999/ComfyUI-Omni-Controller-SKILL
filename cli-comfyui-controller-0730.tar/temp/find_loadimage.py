#!/usr/bin/env python3
"""查找工作流中所有LoadImage节点及其当前图片路径"""
import json

path = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
with open(path, 'r', encoding='utf-8') as f:
    data = json.load(f)

nodes = data.get('nodes', [])
print('=== LoadImage 节点列表 ===')
for n in nodes:
    if n.get('type') == 'LoadImage':
        wv = n.get('widgets_values', [])
        print(f'  NID={n["id"]}: image={wv[0] if wv else "?"}, pos={n.get("pos")}, title={n.get("title","")}')

# 检查2.png是否存在
import os
img_path = r'D:\2026-ComfyUI-V8.3\input\2.png'
print(f'\n图片存在: {os.path.exists(img_path)}')
print(f'图片路径: {img_path}')

# 列出input目录中的图片
input_dir = r'D:\2026-ComfyUI-V8.3\input'
if os.path.isdir(input_dir):
    imgs = [f for f in os.listdir(input_dir) if f.lower().endswith(('.png','.jpg','.jpeg'))]
    print(f'\ninput目录图片(前10个): {imgs[:10]}')
