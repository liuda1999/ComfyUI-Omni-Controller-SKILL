#!/usr/bin/env python3
"""分析三个问题：
   1. Flux2动作偏离 - 检查denoise和ReferenceLatent配置
   2. 色调变冷白 - 检查SVI Pro的色调约束和提示词
   3. 拼接渐变 - 检查ImageBatchExtendWithOverlap配置
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

# ============================================================
# 问题1: Flux2动作偏离 - 检查denoise和ReferenceLatent
# ============================================================
print('='*70)
print('=== 问题1: Flux2动作偏离分析 ===')
print('='*70)

# SplitSigmasDenoise
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} SplitSigmasDenoise denoise={wv[0] if wv else "?"}')

# ReferenceLatent - 检查引导强度
for n in nodes:
    if n.get('type') == 'ReferenceLatent':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} ReferenceLatent title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node = link_map[link_id][1]
                src_obj = nodes_by_id.get(src_node, {})
                print(f'    {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')

# CFGGuider - 检查cfg值
for n in nodes:
    if n.get('type') == 'CFGGuider':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} CFGGuider widgets_values: {wv}')

# SamplerCustomAdvanced配置
for n in nodes:
    if n.get('type') == 'SamplerCustomAdvanced':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'\nNID={nid} SamplerCustomAdvanced title={title}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node = link_map[link_id][1]
                src_obj = nodes_by_id.get(src_node, {})
                print(f'  {name} <- NID={src_node} ({src_obj.get("type","?")})')

# ============================================================
# 问题2: 色调变冷白 - 检查SVI Pro提示词
# ============================================================
print('\n' + '='*70)
print('=== 问题2: 色调变冷白分析 ===')
print('='*70)

# SVI Pro正向提示词
for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv and isinstance(wv[0], str):
            text = wv[0]
            if '6.正向' in title or '正向' in title:
                print(f'\nNID={nid} {title}:')
                print(f'  {text}')

# SVI Pro节点参数
for n in nodes:
    if n.get('type') == 'WanImageToVideoSVIPro':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} SVI Pro {title} widgets_values: {wv}')

# ============================================================
# 问题3: 拼接渐变 - 检查ImageBatchExtendWithOverlap
# ============================================================
print('\n' + '='*70)
print('=== 问题3: 拼接渐变分析 ===')
print('='*70)

for n in nodes:
    if n.get('type') == 'ImageBatchExtendWithOverlap':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} ImageBatchExtendWithOverlap title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node = link_map[link_id][1]
                src_obj = nodes_by_id.get(src_node, {})
                print(f'    {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')

# 检查是否有其他拼接相关节点
print('\n=== 所有拼接相关节点 ===')
for n in nodes:
    ntype = n.get('type', '')
    if any(kw in ntype for kw in ['Concat', 'Batch', 'Extend', 'Overlap', 'Merge', 'Combine']):
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} type={ntype} title={title} wv={wv}')

# 检查最终视频合成节点
print('\n=== VHS_VideoCombine节点 ===')
for n in nodes:
    if n.get('type') == 'VHS_VideoCombine':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} title={title}')
        if isinstance(wv, dict):
            for k, v in wv.items():
                print(f'  {k}: {v}')
        else:
            print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node = link_map[link_id][1]
                src_obj = nodes_by_id.get(src_node, {})
                print(f'    {name} <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')
