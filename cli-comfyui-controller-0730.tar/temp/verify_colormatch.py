#!/usr/bin/env python3
"""验证ColorMatch节点是否正确插入"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']
links = wf['links']

# 检查ColorMatch节点
cm_nodes = [n for n in nodes if n.get('type') == 'ColorMatch']
print(f'ColorMatch节点数: {len(cm_nodes)}')
for n in cm_nodes:
    nid = n['id']
    title = n.get('title', '')
    wv = n.get('widgets_values', [])
    inputs = n.get('inputs', [])
    in_links = {}
    for inp in inputs:
        name = inp.get('name')
        link = inp.get('link')
        in_links[name] = link
    out_links = n.get('outputs', [{}])[0].get('links', [])
    print(f'  NID={nid} {title}')
    print(f'    widgets: method={wv[0] if len(wv)>0 else "?"}, strength={wv[1] if len(wv)>1 else "?"}')
    print(f'    inputs: image_ref={in_links.get("image_ref")}, image_target={in_links.get("image_target")}')
    print(f'    output links: {out_links}')

# 验证link完整性
link_ids_in_links = {L[0] for L in links}
# 检查所有节点input引用的link是否存在
broken = []
for n in nodes:
    for inp in n.get('inputs', []):
        lid = inp.get('link')
        if lid is not None and lid not in link_ids_in_links:
            broken.append((n['id'], inp.get('name'), lid))
# 检查所有节点output引用的link是否存在
for n in nodes:
    for out in n.get('outputs', []):
        for lid in out.get('links', []) or []:
            if lid not in link_ids_in_links:
                broken.append((n['id'], 'output', lid))

print(f'\n断链数量: {len(broken)}')
for b in broken[:10]:
    print(f'  NID={b[0]} {b[1]} link={b[2]}')

# 验证参考图B (NID=75) 的输出连接数
ref_node = next((n for n in nodes if n['id'] == 75), None)
if ref_node:
    ref_out_links = ref_node['outputs'][0].get('links', [])
    print(f'\n参考图B (NID=75) 输出links: {ref_out_links}')
    print(f'连接数: {len(ref_out_links)}')
