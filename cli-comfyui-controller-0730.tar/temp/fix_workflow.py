#!/usr/bin/env python3
"""修复工作流中的两个关键问题：
1. ImageBatchExtendWithOverlap 的 overlap_side: 2 -> "new_images"
2. NID=229 SVI Pro 的 motion_latent_count: 0 -> 1
"""
import json
import os

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

# 读取工作流
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
fixes = []

for n in nodes:
    nid = n.get('id')
    ntype = n.get('type', '')

    # 修复1: ImageBatchExtendWithOverlap overlap_side
    if ntype == 'ImageBatchExtendWithOverlap':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and len(wv) >= 2:
            # widgets_values: [overlap, overlap_side, overlap_mode]
            # overlap_side 是第二个元素，应该是字符串 "source" 或 "new_images"
            if wv[1] == 2 or (isinstance(wv[1], int) and wv[1] not in (0, 1)):
                old_val = wv[1]
                wv[1] = "new_images"
                fixes.append(f'NID={nid} ImageBatchExtendWithOverlap overlap_side: {old_val} -> "new_images"')

    # 修复2: NID=229 SVI Pro motion_latent_count
    if nid == 229 and ntype == 'WanImageToVideoSVIPro':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and len(wv) >= 2:
            # widgets_values: [length, motion_latent_count]
            if wv[1] == 0:
                old_val = wv[1]
                wv[1] = 1
                fixes.append(f'NID={nid} WanImageToVideoSVIPro motion_latent_count: {old_val} -> 1')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

print(f'Applied {len(fixes)} fixes:')
for fix in fixes:
    print(f'  {fix}')

# 验证修复
print('\n=== Verification ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)
for n in wf.get('nodes', []):
    nid = n.get('id')
    ntype = n.get('type', '')
    if ntype == 'ImageBatchExtendWithOverlap':
        wv = n.get('widgets_values', [])
        print(f'NID={nid} ImageBatchExtendWithOverlap widgets_values: {wv}')
    if nid == 229 and ntype == 'WanImageToVideoSVIPro':
        wv = n.get('widgets_values', [])
        print(f'NID={nid} SVI Pro widgets_values: {wv}')
