#!/usr/bin/env python3
"""针对三大问题优化提示词：
   1. 手部变形 - 强化手部结构约束
   2. 背景发红 - 禁止红色/暖色偏移
   3. 多余肢体 - 明确禁止多臂/多肢

   同时适当提高画面质量：
   - SVI Pro采样步数 6→8 (HIGH 3+LOW 5)
   - Flux2修正步数 6→8
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])

# ============================================================
# 1. 优化 SVI Pro 负向提示词（NID=221,243,265,287,309）
# ============================================================
# 原: 静态，静止不动，画面模糊，多余的手指，手指融合，畸形肢体
# 新: 增加多臂、手部变形、背景发红、色偏等禁止项
old_svi_neg = "静态，静止不动，画面模糊，多余的手指，手指融合，畸形肢体"
new_svi_neg = (
    "静态，静止不动，画面模糊，多余的手指，手指融合，多臂，多余手臂，"
    "三头六臂，肢体残缺，手部变形，手指扭曲，关节反向，手掌融合，"
    "背景发红，红色色偏，暖色溢色，色彩失真，色温偏移，"
    "人物变形，五官扭曲，服装穿模，肢体穿模"
)

print('=== 1. 优化SVI Pro负向提示词 ===')
svi_neg_fixes = 0
for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv and isinstance(wv[0], str):
            if wv[0] == old_svi_neg:
                wv[0] = new_svi_neg
                svi_neg_fixes += 1
                print(f'  NID={nid} {title}: 已优化 ({len(new_svi_neg)}字符)')
print(f'  共修复 {svi_neg_fixes} 个SVI Pro负向提示词节点')

# ============================================================
# 2. 优化 SVI Pro 正向提示词（NID=240,262,284,306,328）
# ============================================================
# 在动作描述后加入人物完整性和背景色调约束
print('\n=== 2. 优化SVI Pro正向提示词 ===')

# 段1正向 NID=240
seg1_old = "0-5s：双脚轻踮，双臂向上完全舒展张开，仰头闭眼，身体缓慢左右轻晃，发丝随风飘动，面部放松浅笑"
seg1_new = (
    "0-5s：双脚轻踮，双臂向上完全舒展张开，仰头闭眼，身体缓慢左右轻晃，"
    "发丝随风飘动，面部放松浅笑。"
    "人物双手结构完整，十指分明，两臂两腿，肢体自然协调，"
    "背景色调与参考图一致，无红色色偏"
)

# 段2正向 NID=262
seg2_old = "侧身屈膝弯腰，单手指尖轻触花草，脑袋歪向一侧，单眼弯起微笑，另一只手自然背于身后"
seg2_new = (
    "侧身屈膝弯腰，单手指尖轻触花草，脑袋歪向一侧，单眼弯起微笑，另一只手自然背于身后。"
    "人物双手结构完整，十指分明，两臂两腿，肢体自然协调，"
    "背景色调与参考图一致，无红色色偏"
)

# 段3正向 NID=284
seg3_old = "原地小碎步轻快转圈，转圈结束抬手举至脸颊旁，对着镜头比双耶手势，头部微微歪向一边"
seg3_new = (
    "原地小碎步轻快转圈，转圈结束抬手举至脸颊旁，对着镜头比耶手势，头部微微歪向一边。"
    "人物双手结构完整，十指分明，两臂两腿，肢体自然协调，"
    "背景色调与参考图一致，无红色色偏"
)

# 段4正向 NID=306
seg4_old = "15-20s：停下脚步，双手拢住耳边长发，身体微微前倾，直视镜头露出灿烂大笑，轻轻左右晃动脑袋"
seg4_new = (
    "15-20s：停下脚步，双手拢住耳边长发，身体微微前倾，直视镜头露出灿烂大笑，轻轻左右晃动脑袋。"
    "人物双手结构完整，十指分明，两臂两腿，肢体自然协调，"
    "背景色调与参考图一致，无红色色偏"
)

# 段5正向 NID=328
seg5_old = "20-25s：自然摇摆身体，然后优雅的抬起左腿，动作优美流畅，表情自信"
seg5_new = (
    "20-25s：自然摇摆身体，然后优雅的抬起左腿，动作优美流畅，表情自信。"
    "人物双手结构完整，十指分明，两臂两腿，肢体自然协调，"
    "背景色调与参考图一致，无红色色偏"
)

seg_fixes = [
    (240, seg1_old, seg1_new, '段1正向'),
    (262, seg2_old, seg2_new, '段2正向'),
    (284, seg3_old, seg3_new, '段3正向'),
    (306, seg4_old, seg4_new, '段4正向'),
    (328, seg5_old, seg5_new, '段5正向'),
]

svi_pos_fixes = 0
for nid, old_text, new_text, name in seg_fixes:
    for n in nodes:
        if n.get('id') == nid and n.get('type') == 'CLIPTextEncode':
            wv = n.get('widgets_values', [])
            if isinstance(wv, list) and wv and isinstance(wv[0], str):
                if wv[0] == old_text:
                    wv[0] = new_text
                    svi_pos_fixes += 1
                    print(f'  NID={nid} {name}: 已优化 ({len(new_text)}字符)')
                    break
print(f'  共修复 {svi_pos_fixes} 个SVI Pro正向提示词节点')

# ============================================================
# 3. 优化 Flux2 正向提示词（NID=83）
# ============================================================
print('\n=== 3. 优化Flux2正向提示词 ===')
old_flux2_pos = (
    "保留输入帧中人物的姿态、动作、手势、眼睛、面部表情、肢体位置、画面构图与人物位置，绝不改动；"
    "以参考图B为唯一细节基准，1:1还原以下元素：人物肤色、皮肤肌理、毛孔纹理、肤质质感；"
    "面部五官细节、眉毛；头发发丝质感、光泽、层次纹理；服装材质光泽、服饰配件、配饰细节；"
    "背景元素、环境陈设、完整还原B图的场景细节；整体色调、色温、光影明暗、色彩饱和度完全参照B图统一；"
    "仅修复模糊、残缺、丢失的细节，不改变构图、动作、表情，极致细节，锐度自然"
)

new_flux2_pos = (
    "保留输入帧中人物的姿态、动作、手势、眼睛、面部表情、肢体位置、画面构图与人物位置，绝不改动；"
    "以参考图B为唯一细节基准，1:1还原以下元素：人物肤色、皮肤肌理、毛孔纹理、肤质质感；"
    "面部五官细节、眉毛；头发发丝质感、光泽、层次纹理；服装材质光泽、服饰配件、配饰细节；"
    "背景元素、环境陈设、完整还原B图的场景细节；"
    "整体色调、色温、光影明暗、色彩饱和度严格参照B图统一，消除红色色偏，禁止背景发红；"
    "修复手部结构，确保十指完整分明，关节自然；确保肢体数量正确，仅有两臂两腿，无多余肢体；"
    "仅修复模糊、残缺、丢失的细节，不改变构图、动作、表情，极致细节，锐度自然"
)

flux2_pos_fixed = False
for n in nodes:
    if n.get('id') == 83 and n.get('type') == 'CLIPTextEncode':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv and isinstance(wv[0], str):
            if wv[0] == old_flux2_pos:
                wv[0] = new_flux2_pos
                flux2_pos_fixed = True
                print(f'  NID=83 Flux2正向: 已优化 ({len(new_flux2_pos)}字符)')
                break
if not flux2_pos_fixed:
    print(f'  NID=83 Flux2正向: 未找到匹配（可能已被修改）')

# ============================================================
# 4. 优化 Flux2 负向提示词（NID=84）
# ============================================================
print('\n=== 4. 优化Flux2负向提示词 ===')
old_flux2_neg = (
    "改动人物动作，改变面部表情，修改肢体姿态，构图变形；"
    "肤色偏差，皮肤质感丢失，磨皮过度，五官变形，五官错位，脸部扭曲，满脸麻子，密集雀斑，痤疮红疹，皮肤斑驳溃烂，"
    "多手指，六指，肢体穿模，四肢扭曲，服装纹理模糊，面料材质错误，褶皱崩坏，衣物穿模，"
    "发丝缺失，头发扁平无质感，发丝结块糊化，"
    "色调跑偏，色彩偏移，皮肤泛红发紫，荧光溢色，光影混乱，多光源冲突，风格冲突，"
    "整体模糊，大量噪点，低分辨率，像素马赛克，细节崩坏，画面扁平，液化拉伸，边缘破碎，水印文字，裸露生殖器，外露乳头"
)

new_flux2_neg = (
    "改动人物动作，改变面部表情，修改肢体姿态，构图变形；"
    "肤色偏差，皮肤质感丢失，磨皮过度，五官变形，五官错位，脸部扭曲，满脸麻子，密集雀斑，痤疮红疹，皮肤斑驳溃烂；"
    "多手指，六指，手指扭曲，关节反向，手掌融合，手部变形，手指残缺；"
    "多余肢体，多臂，多余手臂，三头六臂，手臂残影，肢体残缺，肢体穿模，四肢扭曲；"
    "服装纹理模糊，面料材质错误，褶皱崩坏，衣物穿模；"
    "发丝缺失，头发扁平无质感，发丝结块糊化；"
    "背景发红，红色色偏，暖色溢色，色彩失真，色温偏移，色调跑偏，色彩偏移，皮肤泛红发紫，荧光溢色，"
    "光影混乱，多光源冲突，风格冲突；"
    "整体模糊，大量噪点，低分辨率，像素马赛克，细节崩坏，画面扁平，液化拉伸，边缘破碎，水印文字，裸露生殖器，外露乳头"
)

flux2_neg_fixed = False
for n in nodes:
    if n.get('id') == 84 and n.get('type') == 'CLIPTextEncode':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv and isinstance(wv[0], str):
            if wv[0] == old_flux2_neg:
                wv[0] = new_flux2_neg
                flux2_neg_fixed = True
                print(f'  NID=84 Flux2负向: 已优化 ({len(new_flux2_neg)}字符)')
                break
if not flux2_neg_fixed:
    print(f'  NID=84 Flux2负向: 未找到匹配（可能已被修改）')

# ============================================================
# 5. 适当提高画面质量：采样步数 6→8
# ============================================================
print('\n=== 5. 提高采样步数 6→8 ===')

# KSamplerAdvanced: HIGH (end_at_step 2→3) 和 LOW (start_at_step 2→3)
ksampler_fixes = 0
for n in nodes:
    if n.get('type') == 'KSamplerAdvanced':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and len(wv) >= 9:
            old_steps = wv[3]
            if old_steps == 6:
                wv[3] = 8  # steps: 6→8
                if 'HIGH' in title:
                    old_end = wv[8]
                    wv[8] = 3  # end_at_step: 2→3 (做第0-2步，3步)
                    print(f'  NID={nid} HIGH: steps={old_steps}→8, end_at_step={old_end}→3')
                    ksampler_fixes += 1
                elif 'LOW' in title:
                    old_start = wv[7]
                    wv[7] = 3  # start_at_step: 2→3 (做第3-7步，5步)
                    print(f'  NID={nid} LOW: steps={old_steps}→8, start_at_step={old_start}→3')
                    ksampler_fixes += 1

print(f'  共修复 {ksampler_fixes} 个KSamplerAdvanced节点')

# Flux2Scheduler: steps 6→8
flux2_sched_fixes = 0
for n in nodes:
    if n.get('type') == 'Flux2Scheduler':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            old_steps = wv[0]
            if old_steps == 6:
                wv[0] = 8
                print(f'  NID={nid} Flux2Scheduler: steps={old_steps}→8')
                flux2_sched_fixes += 1
print(f'  共修复 {flux2_sched_fixes} 个Flux2Scheduler节点')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

# 验证
print('\n=== 验证 ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)
nodes = wf.get('nodes', [])

for n in nodes:
    nid = n.get('id')
    ntype = n.get('type', '')
    title = n.get('title', '')
    wv = n.get('widgets_values', [])

    if ntype == 'CLIPTextEncode' and isinstance(wv, list) and wv and isinstance(wv[0], str):
        if len(wv[0]) > 30:
            print(f'\nNID={nid} {title}:')
            print(f'  {wv[0][:120]}...' if len(wv[0]) > 120 else f'  {wv[0]}')

    if ntype == 'KSamplerAdvanced' and wv:
        print(f'NID={nid} {title}: steps={wv[3]}, start={wv[7]}, end={wv[8]}')

    if ntype == 'Flux2Scheduler' and wv:
        print(f'NID={nid} Flux2Scheduler: steps={wv[0]}')
