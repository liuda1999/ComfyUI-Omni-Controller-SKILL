#!/usr/bin/env python3
"""
修改LoadImage节点指向2.png, 通过 /prompt API 提交工作流并监控执行
使用 /api/workflow 转换 UI 格式为 API 格式
"""
import json
import urllib.request
import urllib.error
import time
import sys
import os

WORKFLOW_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
HOST = '127.0.0.1'
PORT = 3198
BASE_URL = f'http://{HOST}:{PORT}'

# 1. 加载工作流
with open(WORKFLOW_PATH, 'r', encoding='utf-8') as f:
    workflow = json.load(f)

# 2. 修改两个LoadImage节点指向2.png
for n in workflow['nodes']:
    if n.get('type') == 'LoadImage':
        n['widgets_values'][0] = '2.png'
        print(f'  NID={n["id"]}: image → 2.png')

# 3. 保存临时副本
temp_path = r'e:\comfyui-cli\temp\long_video_submit.json'
with open(temp_path, 'w', encoding='utf-8') as f:
    json.dump(workflow, f, ensure_ascii=False)

print(f'\n工作流已保存到: {temp_path}')
print(f'节点数: {len(workflow["nodes"])}')
print(f'连接数: {len(workflow["links"])}')

# 4. 通过 /api/workflow 端点转换为API格式
print('\n=== 转换为API格式 ===')
convert_url = f'{BASE_URL}/api/workflow'
convert_data = json.dumps({'workflow': workflow}).encode('utf-8')
req = urllib.request.Request(convert_url, data=convert_data, headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        api_workflow = json.loads(resp.read().decode('utf-8'))
    print(f'  ✓ 转换成功, API节点数: {len(api_workflow)}')
except urllib.error.HTTPError as e:
    print(f'  ❌ 转换失败: HTTP {e.code}')
    print(f'  错误: {e.read().decode("utf-8")[:500]}')
    sys.exit(1)
except Exception as e:
    print(f'  ❌ 转换异常: {e}')
    sys.exit(1)

# 5. 提交工作流到 /prompt
print('\n=== 提交工作流 ===')
prompt_url = f'{BASE_URL}/prompt'
prompt_data = json.dumps({'prompt': api_workflow}).encode('utf-8')
req = urllib.request.Request(prompt_url, data=prompt_data, headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    prompt_id = result.get('prompt_id')
    print(f'  ✓ 提交成功, prompt_id: {prompt_id}')
except urllib.error.HTTPError as e:
    print(f'  ❌ 提交失败: HTTP {e.code}')
    err_body = e.read().decode('utf-8')
    print(f'  错误: {err_body[:1000]}')
    sys.exit(1)

# 6. 保存prompt_id供监控脚本使用
with open(r'e:\comfyui-cli\temp\current_prompt_id.txt', 'w') as f:
    f.write(prompt_id)

print(f'\n工作流已提交, prompt_id已保存')
print(f'prompt_id: {prompt_id}')
