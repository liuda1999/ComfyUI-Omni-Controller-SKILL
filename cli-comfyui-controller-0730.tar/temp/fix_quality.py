#!/usr/bin/env python3
"""修复工作流质量问题：
   1. LoadImage 指向正确的 2.png（原指向不存在的文件）
   2. 视频采样步数 3→6（HIGH 2步 + LOW 4步）
   3. Flux2 修正步数 2→6
   4. Flux2 LoRA 强度提升：0.05/0.05/0 → 0.3/0.3/0.2
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
fixes = []

for n in nodes:
    nid = n.get('id')
    ntype = n.get('type', '')
    wv = n.get('widgets_values', [])

    # 1. 修复 LoadImage 指向 2.png
    if ntype == 'LoadImage':
        if isinstance(wv, list) and len(wv) >= 1:
            old_img = wv[0]
            if old_img != '2.png':
                wv[0] = '2.png'
                fixes.append(f'NID={nid} LoadImage: {old_img} -> 2.png')

    # 2. 修复 KSamplerAdvanced 步数 3→6
    if ntype == 'KSamplerAdvanced':
        if isinstance(wv, list) and len(wv) >= 9:
            old_steps = wv[3]
            if old_steps == 3:
                wv[3] = 6  # steps: 3→6
                title = n.get('title', '')
                if 'HIGH' in title:
                    # HIGH: end_at_step 1→2 (做第0-1步，2步)
                    old_end = wv[8]
                    wv[8] = 2
                    fixes.append(f'NID={nid} HIGH: steps={old_steps}→6, end_at_step={old_end}→2')
                elif 'LOW' in title:
                    # LOW: start_at_step 1→2 (做第2-5步，4步)
                    old_start = wv[7]
                    wv[7] = 2
                    fixes.append(f'NID={nid} LOW: steps={old_steps}→6, start_at_step={old_start}→2')

    # 3. 修复 Flux2Scheduler 步数 2→6
    if ntype == 'Flux2Scheduler':
        if isinstance(wv, list) and len(wv) >= 1:
            old_steps = wv[0]
            if old_steps == 2:
                wv[0] = 6
                fixes.append(f'NID={nid} Flux2Scheduler: steps={old_steps}→6')

    # 4. 修复 Flux2 LoRA 强度
    if ntype == 'LoraLoaderModelOnly':
        if isinstance(wv, list) and len(wv) >= 2:
            title = n.get('title', '')
            old_str = wv[1]
            # Flux2 LoRA (不是SVI Pro LoRA)
            if 'Flux2' in title or 'F2K' in str(wv[0]):
                if '质量' in title or 'quality' in str(wv[0]).lower():
                    if old_str < 0.3:
                        wv[1] = 0.3
                        fixes.append(f'NID={nid} LoRA质量: {old_str}→0.3')
                elif '皮肤' in title or 'skin' in str(wv[0]).lower():
                    if old_str < 0.3:
                        wv[1] = 0.3
                        fixes.append(f'NID={nid} LoRA皮肤: {old_str}→0.3')
                elif '背光' in title or 'front' in str(wv[0]).lower():
                    if old_str < 0.2:
                        wv[1] = 0.2
                        fixes.append(f'NID={nid} LoRA背光正光: {old_str}→0.2')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

print(f'Applied {len(fixes)} fixes:')
for fix in fixes:
    print(f'  {fix}')

# 验证修复
print('\n=== Verification ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

for n in wf.get('nodes', []):
    nid = n.get('id')
    ntype = n.get('type', '')
    wv = n.get('widgets_values', [])
    title = n.get('title', '')

    if ntype == 'LoadImage':
        print(f'NID={nid} LoadImage: {wv[0] if wv else "?"}')
    elif ntype == 'KSamplerAdvanced' and wv:
        print(f'NID={nid} {title}: steps={wv[3]}, cfg={wv[4]}, start={wv[7]}, end={wv[8]}')
    elif ntype == 'Flux2Scheduler' and wv:
        print(f'NID={nid} Flux2Scheduler: steps={wv[0]}, {wv[1]}x{wv[2]}')
    elif ntype == 'LoraLoaderModelOnly' and 'Flux2' in title:
        print(f'NID={nid} {title}: strength={wv[1] if len(wv)>1 else "?"}')
