#!/usr/bin/env python3
"""修正Flux2换皮策略：
   1. 撤销混合策略：删除ImageBlend节点，A图恢复为SVI末帧（纯动作来源）
   2. 提高denoise: 0.5→0.75（让Flux2更强力地换皮，但保留动作构图）
   3. 优化提示词：明确"只换皮不改动作"
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

# ============================================================
# 1. 撤销混合策略：A图恢复为SVI末帧
# ============================================================
print('=== 1. 撤销混合策略，A图恢复为SVI末帧 ===')

# 需要恢复的A图缩放节点和对应的SVI末帧SaveImage节点
# 段2→3: NID=100 ← 应该恢复为 NID=204 (SaveImage c8_2to3_last)
# 段3→4: NID=107 ← 应该恢复为 NID=208 (SaveImage c8_3to4_last)
# 段4→5: NID=114 ← 应该恢复为 NID=212 (SaveImage c8_4to5_last)

# SVI末帧的SaveImage节点输入来自ImageFromBatch
# 段2→3: SaveImage NID=204 ← ImageFromBatch NID=258
# 段3→4: SaveImage NID=208 ← ImageFromBatch NID=280
# 段4→5: SaveImage NID=212 ← ImageFromBatch NID=302

# 找到ImageBlend的输出link，修改A图缩放节点的输入指向SVI末帧
revert_map = [
    {'a_img_nid': 100, 'blend_nid': 366, 'svi_save_nid': 204, 'name': '段2→3'},
    {'a_img_nid': 107, 'blend_nid': 367, 'svi_save_nid': 208, 'name': '段3→4'},
    {'a_img_nid': 114, 'blend_nid': 368, 'svi_save_nid': 212, 'name': '段4→5'},
]

for rev in revert_map:
    a_nid = rev['a_img_nid']
    blend_nid = rev['blend_nid']
    svi_nid = rev['svi_save_nid']
    name = rev['name']

    a_node = nodes_by_id.get(a_nid, {})
    blend_node = nodes_by_id.get(blend_nid, {})

    print(f'\n  {name}: NID={a_nid} <- NID={blend_nid}(ImageBlend) 改为 <- NID={svi_nid}(SVI末帧)')

    # 获取A图缩放节点当前的image输入link
    a_input = a_node.get('inputs', [{}])[0]
    old_link_id = a_input.get('link')

    if old_link_id and old_link_id in link_map:
        old_link = link_map[old_link_id]
        old_src = old_link[1]

        # 从旧源(ImageBlend)的outputs中移除该link
        blend_out = blend_node.get('outputs', [{}])[0]
        if 'links' in blend_out and isinstance(blend_out['links'], list):
            if old_link_id in blend_out['links']:
                blend_out['links'].remove(old_link_id)

        # 修改link的源节点为SVI末帧SaveImage
        old_link[1] = svi_nid  # source_node
        old_link[2] = 0  # source_slot (SaveImage不输出，需要找ImageFromBatch)

        # 实际上SaveImage不输出IMAGE，需要找到SVI末帧的实际IMAGE来源
        # SVI末帧: ImageFromBatch -> SaveImage
        # A图应该直接连接ImageFromBatch的输出，而不是SaveImage
        # 让我找ImageFromBatch节点
        svi_save_node = nodes_by_id.get(svi_nid, {})
        for inp in svi_save_node.get('inputs', []):
            if inp.get('name') == 'images':
                save_link_id = inp.get('link')
                if save_link_id and save_link_id in link_map:
                    actual_src = link_map[save_link_id][1]  # ImageFromBatch NID
                    old_link[1] = actual_src
                    old_link[2] = 0
                    # 添加到新源的outputs
                    actual_src_node = nodes_by_id.get(actual_src, {})
                    for out in actual_src_node.get('outputs', []):
                        if 'links' not in out or out['links'] is None:
                            out['links'] = []
                        if old_link_id not in out['links']:
                            out['links'].append(old_link_id)
                        break
                    actual_src_type = actual_src_node.get('type', '?')
                    print(f'    实际源: NID={actual_src} ({actual_src_type})')
                    break

        print(f'    link_id={old_link_id} 已修改')

# 2. 删除ImageBlend节点和参考图缩放节点(NID=365,366,367,368)
print(f'\n  删除节点: NID=365(参考图缩放), NID=366/367/368(ImageBlend)')
nodes_to_remove = {365, 366, 367, 368}
nodes[:] = [n for n in nodes if n.get('id') not in nodes_to_remove]

# 3. 清理与这些节点相关的links
print(f'\n  清理相关links...')
links_to_remove = set()
for link in links:
    if isinstance(link, list) and len(link) >= 5:
        src_node = link[1]
        tgt_node = link[3]
        if src_node in nodes_to_remove or tgt_node in nodes_to_remove:
            links_to_remove.add(link[0])

links[:] = [link for link in links if not (isinstance(link, list) and len(link) >= 1 and link[0] in links_to_remove)]
print(f'    删除了 {len(links_to_remove)} 个links')

# ============================================================
# 4. 提高Flux2 denoise: 0.5→0.75
# ============================================================
print('\n=== 2. 提高Flux2 denoise: 0.5→0.75 ===')
nodes_by_id = {n.get('id'): n for n in nodes}
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            old_val = wv[0]
            wv[0] = 0.75
            print(f'  NID={nid} denoise: {old_val}→0.75')

# ============================================================
# 5. 优化Flux2提示词：明确"只换皮不改动作"
# ============================================================
print('\n=== 3. 优化Flux2提示词 ===')

# 正向提示词 NID=83
new_flux2_pos = (
    "以参考图B为唯一外貌基准，1:1还原人物面部五官、眉毛、肤色、肤质肌理、毛孔、"
    "头发发丝质感光泽层次、服装材质款式颜色配饰、背景环境场景陈设、整体色调色温光影；"
    "严格保留输入帧中人物的动作姿态、手势、肢体位置、面部表情、构图与人物位置，绝不改变动作；"
    "将输入帧中人物的外貌服装背景完全替换为参考图B的外貌服装背景；"
    "修复手部结构确保十指完整分明关节自然，确保仅有两臂两腿无多余肢体；"
    "消除红色色偏禁止背景发红，色彩饱和度严格参照B图；"
    "极致细节，锐度自然，高质量画面"
)

# 负向提示词 NID=84
new_flux2_neg = (
    "改变动作姿态，改变面部表情，改变肢体位置，改变构图；"
    "外貌偏离参考图，五官不一致，肤色偏差，肤质丢失，发色发质不符，服装款式颜色不符，背景场景不符；"
    "多手指，六指，手指扭曲，关节反向，手掌融合，手部变形，手指残缺；"
    "多余肢体，多臂，多余手臂，三头六臂，手臂残影，肢体残缺，肢体穿模，四肢扭曲；"
    "背景发红，红色色偏，暖色溢色，色彩失真，色温偏移，色调跑偏，色彩偏移，皮肤泛红发紫，荧光溢色；"
    "磨皮过度，五官变形，五官错位，脸部扭曲，满脸麻子，密集雀斑，痤疮红疹；"
    "服装纹理模糊，面料材质错误，褶皱崩坏，衣物穿模；"
    "发丝缺失，头发扁平无质感，发丝结块糊化；"
    "光影混乱，多光源冲突，风格冲突；"
    "整体模糊，大量噪点，低分辨率，像素马赛克，细节崩坏，画面扁平，液化拉伸，边缘破碎，水印文字，裸露生殖器，外露乳头"
)

for n in nodes:
    if n.get('id') == 83 and n.get('type') == 'CLIPTextEncode':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            wv[0] = new_flux2_pos
            print(f'  NID=83 Flux2正向: 已更新 ({len(new_flux2_pos)}字符)')
    elif n.get('id') == 84 and n.get('type') == 'CLIPTextEncode':
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            wv[0] = new_flux2_neg
            print(f'  NID=84 Flux2负向: 已更新 ({len(new_flux2_neg)}字符)')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

# 验证
print('\n=== 验证 ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)
nodes = wf.get('nodes', [])
links = wf.get('links', [])
link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

print(f'总节点数: {len(nodes)} (应删除4个)')
print(f'总link数: {len(links)}')

# 验证ImageBlend已删除
blend_count = sum(1 for n in nodes if n.get('type') == 'ImageBlend')
print(f'ImageBlend节点数: {blend_count} (应为0)')

# 验证A图输入
for rev in revert_map:
    a_nid = rev['a_img_nid']
    a_node = nodes_by_id.get(a_nid, {})
    a_input = a_node.get('inputs', [{}])[0]
    link_id = a_input.get('link')
    if link_id and link_id in link_map:
        src_node = link_map[link_id][1]
        src_obj = nodes_by_id.get(src_node, {})
        print(f'NID={a_nid} ({rev["name"]} A图) <- NID={src_node} ({src_obj.get("type","?")}, {src_obj.get("title","")})')

# 验证denoise
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        print(f'NID={n.get("id")} denoise={n.get("widgets_values",[None])[0]}')
