#!/usr/bin/env python3
"""收集Flux2完整提示词和调度器细节"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']

# Flux2完整提示词
print('=== Flux2 完整提示词 ===')
for n in nodes:
    if n.get('type') == 'CLIPTextEncode' and n['id'] in [83, 84]:
        nid = n['id']
        title = n.get('title', '')
        text = n.get('widgets_values', [''])[0]
        print(f'\nNID={nid} ({title}):')
        print(text)

# Flux2Scheduler完整参数
print('\n\n=== Flux2Scheduler 完整参数 ===')
for n in nodes:
    if n.get('type') == 'Flux2Scheduler':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        inputs = n.get('inputs', [])
        print(f'NID={nid} ({title})')
        print(f'  widgets: {wv}')
        print(f'  inputs:')
        for inp in inputs:
            print(f'    {inp.get("name")}: link={inp.get("link")}')

# SVI Pro节点完整输入
print('\n\n=== SVI Pro 节点完整输入 ===')
for n in nodes:
    if 'SVI' in n.get('type', ''):
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        inputs = n.get('inputs', [])
        print(f'\nNID={nid} ({title})')
        print(f'  widgets: {wv}')
        print(f'  inputs:')
        for inp in inputs:
            print(f'    {inp.get("name")}: link={inp.get("link")}')

# VHS_VideoCombine完整参数
print('\n\n=== VHS_VideoCombine 完整参数 ===')
for n in nodes:
    if n.get('type') == 'VHS_VideoCombine':
        nid = n['id']
        wv = n.get('widgets_values', [])
        print(f'NID={nid}')
        print(f'  widgets: {json.dumps(wv, indent=2, ensure_ascii=False)}')

# WanVideoBlockSwap
print('\n\n=== WanVideoBlockSwap/相关VRAM管理节点 ===')
for n in nodes:
    t = n.get('type', '')
    if 'BlockSwap' in t or 'PurgeVRAM' in t or 'UnloadAllModels' in t or 'ModelPatchTorchSettings' in t:
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} {t} ({title}): {wv}')

# 原图输入和参考图配置
print('\n\n=== 参考图配置 ===')
for n in nodes:
    if n.get('type') == 'LoadImage':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} {title}: {wv}')

# ImageUpscaleWithModel
print('\n\n=== ImageUpscaleWithModel ===')
for n in nodes:
    if n.get('type') == 'ImageUpscaleWithModel':
        nid = n['id']
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} {title}: {wv}')
