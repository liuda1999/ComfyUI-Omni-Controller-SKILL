#!/usr/bin/env python3
"""检查新生成的输出文件"""
import os
import time
from datetime import datetime

OUTPUT_DIR = r'D:\2026-ComfyUI-V8.3\output'
now = time.time()
recent_files = []

if os.path.isdir(OUTPUT_DIR):
    for f in os.listdir(OUTPUT_DIR):
        fp = os.path.join(OUTPUT_DIR, f)
        if os.path.isfile(fp):
            mtime = os.path.getmtime(fp)
            if mtime > now - 600:  # 最近10分钟
                size = os.path.getsize(fp)
                recent_files.append((f, size, mtime))

recent_files.sort(key=lambda x: -x[2])
print(f'Recent files (last 10 min): {len(recent_files)}')
for f, size, mtime in recent_files[:20]:
    dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
    size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
    print(f'  {dt} {size_str:>10} {f}')
