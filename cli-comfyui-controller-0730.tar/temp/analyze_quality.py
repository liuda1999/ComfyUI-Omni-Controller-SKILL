#!/usr/bin/env python3
"""分析工作流中的关键质量问题：
   1. 视频生成参数 (SVI Pro + KSampler)
   2. Flux2 修正参数
   3. LoRA 强度
   4. 分辨率链
   5. 提示词内容
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])

print('='*60)
print('视频生成质量分析报告')
print('='*60)

# 1. SVI Pro 节点
print('\n=== 1. WanImageToVideoSVIPro 节点（视频主生成） ===')
for n in nodes:
    if n.get('type') == 'WanImageToVideoSVIPro':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 2. KSamplerAdvanced 节点（视频采样器）
print('\n=== 2. KSamplerAdvanced 节点（视频采样器） ===')
for n in nodes:
    if n.get('type') == 'KSamplerAdvanced':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 3. SamplerCustomAdvanced 节点（Flux2修正）
print('\n=== 3. SamplerCustomAdvanced 节点（Flux2修正） ===')
for n in nodes:
    if n.get('type') == 'SamplerCustomAdvanced':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 4. Flux2Scheduler 节点
print('\n=== 4. Flux2Scheduler 节点 ===')
for n in nodes:
    if n.get('type') == 'Flux2Scheduler':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        print(f'NID={nid}')
        print(f'  widgets_values: {wv}')

# 5. LoRA 节点
print('\n=== 5. LoraLoaderModelOnly 节点 ===')
for n in nodes:
    if n.get('type') == 'LoraLoaderModelOnly':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 6. 分辨率相关节点
print('\n=== 6. 分辨率相关节点 ===')
for n in nodes:
    ntype = n.get('type', '')
    if 'ImageScale' in ntype or 'ImageResize' in ntype:
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} type={ntype} title={title}')
        print(f'  widgets_values: {wv}')

# 7. 提示词节点
print('\n=== 7. CLIPTextEncode 节点（提示词） ===')
for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        if isinstance(wv, list) and len(wv) > 0:
            text = wv[0] if isinstance(wv[0], str) else str(wv[0])
            if len(text) > 50:  # 只显示长提示词
                print(f'NID={nid} title={title}')
                print(f'  text: {text[:300]}...' if len(text) > 300 else f'  text: {text}')

# 8. 模型加载节点
print('\n=== 8. UNETLoader 节点（模型加载） ===')
for n in nodes:
    if n.get('type') == 'UNETLoader':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 9. LoadImage 节点
print('\n=== 9. LoadImage 节点 ===')
for n in nodes:
    if n.get('type') == 'LoadImage':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 10. ImageUpscaleWithModel 节点
print('\n=== 10. ImageUpscaleWithModel 节点 ===')
for n in nodes:
    if n.get('type') == 'ImageUpscaleWithModel':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 11. UpscaleModelLoader
print('\n=== 11. UpscaleModelLoader 节点 ===')
for n in nodes:
    if n.get('type') == 'UpscaleModelLoader':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')
