#!/usr/bin/env python3
"""查看工作流中所有提示词的完整内容"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])

print('='*70)
print('=== 所有CLIPTextEncode提示词节点 ===')
print('='*70)

for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            text = wv[0] if isinstance(wv[0], str) else str(wv[0])
            if len(text) > 10:
                print(f'\n--- NID={nid} title={title} ---')
                print(f'完整文本:')
                print(text)
                print(f'(长度: {len(text)} 字符)')

# 查看SVI Pro的负向提示词
print('\n' + '='*70)
print('=== SVI Pro节点参数 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'WanImageToVideoSVIPro':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} title={title}')
        print(f'  widgets_values: {wv}')
