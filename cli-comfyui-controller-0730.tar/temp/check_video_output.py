#!/usr/bin/env python3
"""检查视频输出详情"""
import json
import urllib.request
import os
from datetime import datetime

BASE = 'http://127.0.0.1:3198'
PID = '53b7d2ad-7d52-487e-af20-390cad58ec35'

with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

data = h[PID]
outputs = data.get('outputs', {})

print('=== Video Output ===')
for nid, out in outputs.items():
    if 'gifs' in out or 'videos' in out:
        print(f'NID={nid}:')
        for k in ('gifs', 'videos'):
            if k in out:
                for item in out[k]:
                    print(f'  {k}:')
                    print(f'    filename: {item.get("filename")}')
                    print(f'    subfolder: {item.get("subfolder")}')
                    print(f'    type: {item.get("type")}')
                    # 检查文件是否存在
                    fp = os.path.join(r'D:\2026-ComfyUI-V8.3\output', item.get('subfolder', ''), item.get('filename', ''))
                    if os.path.isfile(fp):
                        size = os.path.getsize(fp)
                        mtime = os.path.getmtime(fp)
                        dt = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
                        size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
                        print(f'    file exists: YES')
                        print(f'    size: {size_str}')
                        print(f'    modified: {dt}')
                    else:
                        print(f'    file exists: NO ({fp})')

# 执行时间
status = data.get('status', {})
messages = status.get('messages', [])
start_ts = None
end_ts = None
for msg_type, msg_data in messages:
    if msg_type == 'execution_start':
        start_ts = msg_data.get('timestamp')
    elif msg_type == 'execution_success':
        end_ts = msg_data.get('timestamp')
    elif msg_type == 'execution_cached':
        cached = msg_data.get('nodes', [])
        print(f'\nCached nodes: {len(cached)}')

if start_ts and end_ts:
    dur = (end_ts - start_ts) / 1000
    print(f'\nExecution time: {dur:.1f}s')

# 列出所有最近的输出文件
print('\n=== Recent output files ===')
output_dir = r'D:\2026-ComfyUI-V8.3\output'
import time
now = time.time()
files = []
for f in os.listdir(output_dir):
    fp = os.path.join(output_dir, f)
    if os.path.isfile(fp):
        mtime = os.path.getmtime(fp)
        if mtime > now - 3600:
            files.append((f, os.path.getsize(fp), mtime))
files.sort(key=lambda x: -x[2])
for f, size, mtime in files[:15]:
    dt = datetime.fromtimestamp(mtime).strftime('%H:%M:%S')
    size_str = f'{size/1024:.0f}KB' if size < 1024*1024 else f'{size/1024/1024:.1f}MB'
    print(f'  {dt} {size_str:>10} {f}')
