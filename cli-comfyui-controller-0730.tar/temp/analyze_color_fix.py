#!/usr/bin/env python3
"""分析工作流结构以确定ColorMatch插入位置"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

# 建立节点索引
node_by_id = {n.get('id'): n for n in nodes}

# 找关键节点类型
print('=== 关键节点 ===')
keywords = ['LoadImage', 'Flux2', 'VAEDecode', 'VAEEncode', 'WanVideo', 'SVI', 'ImageBatch', 'ImageConcat', 'SaveImage', 'VHS_VideoCombine']
for n in nodes:
    t = n.get('type', '')
    title = n.get('title', '')
    nid = n.get('id')
    if any(k in t or k in title for k in keywords):
        # 获取输入连接
        inputs = n.get('inputs', [])
        in_links = []
        for inp in inputs:
            link = inp.get('link')
            if link is not None:
                in_links.append(f"{inp.get('name')}={link}")
        print(f'NID={nid:3d} type={t:30s} title={title[:40]:40s} in:[{", ".join(in_links)}]')

# 找参考图B的LoadImage
print('\n=== 所有LoadImage节点 ===')
for n in nodes:
    if n.get('type') == 'LoadImage':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        title = n.get('title', '')
        print(f'NID={nid} title={title} widgets={wv}')
