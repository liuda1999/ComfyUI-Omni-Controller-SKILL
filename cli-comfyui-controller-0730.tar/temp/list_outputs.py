#!/usr/bin/env python3
"""列出输出目录中今天的视频文件"""
import os
import time
from datetime import datetime, timedelta

dirs = [r'D:\2026-ComfyUI-V8.3\output', r'E:\comfyui-cli\output']
now = time.time()
yesterday = now - 86400  # 24h ago

for d in dirs:
    print(f'\n=== {d} ===')
    if not os.path.isdir(d):
        print('NOT EXIST')
        continue
    files = []
    for f in os.listdir(d):
        fp = os.path.join(d, f)
        if os.path.isfile(fp):
            mtime = os.path.getmtime(fp)
            if mtime > yesterday:
                size = os.path.getsize(fp)
                files.append((f, size, mtime))
    files.sort(key=lambda x: -x[2])
    print(f'Recent files (last 24h): {len(files)}')
    for f, size, mtime in files[:20]:
        dt = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
        print(f'  {dt} {size:>10} {f}')

# 检查 temp 目录中的 latent 文件
print('\n=== Latent files in temp ===')
temp_dir = r'E:\comfyui-cli\temp'
if os.path.isdir(temp_dir):
    for f in os.listdir(temp_dir):
        if f.endswith('.latent'):
            fp = os.path.join(temp_dir, f)
            mtime = os.path.getmtime(fp)
            dt = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
            size = os.path.getsize(fp)
            print(f'  {dt} {size:>10} {f}')
