#!/usr/bin/env python3
"""修复循环依赖：
   错误：段N的A图 <- 段N的Flux2修正 (循环)
   正确：段N的A图 <- 段N-1的Flux2修正 (链式传递)

   段2→3的A图 <- 段1→2的Flux2修正(NID=98)
   段3→4的A图 <- 段2→3的Flux2修正(NID=105)
   段4→5的A图 <- 段3→4的Flux2修正(NID=112)
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

nodes_by_id = {n.get('id'): n for n in nodes}
link_map = {link[0]: link for link in links if isinstance(link, list) and len(link) >= 5}

# 修复映射：
# NID=366(段2→3 blend) 应该 <- NID=98(段1→2 Flux2修正) 而非 NID=105
# NID=367(段3→4 blend) 应该 <- NID=105(段2→3 Flux2修正) 而非 NID=112
# NID=368(段4→5 blend) 应该 <- NID=112(段3→4 Flux2修正) 而非 NID=119

fixes = [
    {'blend_nid': 366, 'old_src': 105, 'new_src': 98, 'name': '段2→3'},
    {'blend_nid': 367, 'old_src': 112, 'new_src': 105, 'name': '段3→4'},
    {'blend_nid': 368, 'old_src': 119, 'new_src': 112, 'name': '段4→5'},
]

for fix in fixes:
    blend_nid = fix['blend_nid']
    old_src = fix['old_src']
    new_src = fix['new_src']
    name = fix['name']

    blend_node = nodes_by_id.get(blend_nid, {})
    print(f'\n=== 修复 {name} (NID={blend_nid}) ===')
    print(f'  旧源: NID={old_src}')
    print(f'  新源: NID={new_src} (前一段Flux2修正)')

    # 找到 image1 输入的 link
    image1_input = blend_node.get('inputs', [{}])[0]
    old_link_id = image1_input.get('link')

    if old_link_id and old_link_id in link_map:
        old_link = link_map[old_link_id]
        print(f'  旧link: link_id={old_link_id}, src={old_link[1]}')

        # 从旧源节点的outputs.links中移除
        src_slot = old_link[2]
        src_node = nodes_by_id.get(old_src, {})
        for out in src_node.get('outputs', []):
            if 'links' in out and isinstance(out['links'], list):
                if old_link_id in out['links']:
                    out['links'].remove(old_link_id)
                    print(f'  从NID={old_src} outputs移除link_id={old_link_id}')

        # 修改link的源节点
        old_link[1] = new_src  # 修改source_node
        # slot保持0（ImageResizeKJv2的输出slot 0）
        old_link[2] = 0

        # 更新新源节点的outputs.links
        new_src_node = nodes_by_id.get(new_src, {})
        for out in new_src_node.get('outputs', []):
            if 'links' not in out or out['links'] is None:
                out['links'] = []
            out['links'].append(old_link_id)
            print(f'  添加到NID={new_src} outputs: link_id={old_link_id}')
            break  # 只处理第一个output

        print(f'  新link: link_id={old_link_id}, src=NID={new_src}')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

# 验证
print('\n=== 验证 ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)
nodes = wf.get('nodes', [])
links = wf.get('links', [])
link_map = {link[0]: (link[1], link[2], link[3], link[4]) for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

for fix in fixes:
    blend_nid = fix['blend_nid']
    blend_node = nodes_by_id.get(blend_nid, {})
    image1_link = blend_node.get('inputs', [{}])[0].get('link')
    if image1_link and image1_link in link_map:
        src_nid, src_slot, _, _ = link_map[image1_link]
        src_node = nodes_by_id.get(src_nid, {})
        print(f'NID={blend_nid}({fix["name"]} blend) image1 <- NID={src_nid} ({src_node.get("type","?")}, {src_node.get("title","")})')
