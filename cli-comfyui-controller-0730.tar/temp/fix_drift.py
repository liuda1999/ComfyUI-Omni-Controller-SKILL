#!/usr/bin/env python3
"""混合策略修复角色外貌漂移：
   1. 段间传递改为Flux2修正帧（链式累积修正效果）
   2. 每段A图混合50%末帧+50%参考图（强制参考图约束）
   3. denoise 0.3→0.5（增强参考图引导强度）

   修改要点：
   - 段2→3的A图来源：从 SVI末帧(NID=204) 改为 Flux2修正帧(NID=202) + 参考图混合
   - 段3→4的A图来源：从 SVI末帧(NID=208) 改为 Flux2修正帧(NID=210) + 参考图混合
   - 段4→5的A图来源：从 SVI末帧(NID=212) 改为 Flux2修正帧(NID=214) + 参考图混合
   - SplitSigmasDenoise: denoise 0.3→0.5
   - 新增 ImageBlend 节点用于混合末帧和参考图
"""
import json
import copy

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

# 找到最大节点ID和最大link ID
max_nid = max(n.get('id', 0) for n in nodes)
max_link_id = max((link[0] for link in links if isinstance(link, list) and len(link) >= 1), default=0)

print(f'当前: nodes={len(nodes)}, max_nid={max_nid}, max_link_id={max_link_id}')

# 节点查找字典
nodes_by_id = {n.get('id'): n for n in nodes}

# ============================================================
# 修复1: SplitSigmasDenoise denoise 0.3→0.5
# ============================================================
print('\n=== 修复1: SplitSigmasDenoise denoise 0.3→0.5 ===')
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        nid = n.get('id')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            old_val = wv[0]
            if old_val == 0.3:
                wv[0] = 0.5
                print(f'  NID={nid} denoise: {old_val}→0.5')

# ============================================================
# 修复2: 为段2→3, 3→4, 4→5 创建混合A图（50%Flux2修正帧 + 50%参考图）
# ============================================================
# 当前A图来源（SVI末帧）:
#   段2→3: NID=100 ← NID=204(SaveImage c8_2to3_last) ← NID=258(ImageFromBatch)
#   段3→4: NID=107 ← NID=208(SaveImage c8_3to4_last) ← NID=280(ImageFromBatch)
#   段4→5: NID=114 ← NID=212(SaveImage c8_4to5_last) ← NID=302(ImageFromBatch)
#
# Flux2修正帧输出:
#   段1→2: NID=202(SaveImage c8_flux2_1to2_out) ← NID=98(ImageResizeKJv2)
#   段2→3: NID=206(SaveImage c8_flux2_2to3_out) ← NID=105(ImageResizeKJv2)
#   段3→4: NID=210(SaveImage c8_flux2_3to4_out) ← NID=112(ImageResizeKJv2)
#   段4→5: NID=214(SaveImage c8_flux2_4to5_out) ← NID=119(ImageResizeKJv2)
#
# 参考图: NID=75 (LoadImage 2.png) → NID=76 (ImageScaleToTotalPixels ~1MP)
#
# 修改方案：
#   1. 新增3个 ImageBlend 节点（NID=max+1, max+2, max+3）
#   2. 每个ImageBlend混合 Flux2修正帧 + 参考图缩放
#   3. 修改 NID=100/107/107 的image输入link指向ImageBlend输出
#   4. 参考图需要先经过 ImageScaleToTotalPixels(0.5MP) 匹配A图尺寸

# 参考图缩放节点 (复用NID=76的输出，但那是1MP，A图是0.5MP)
# 需要新增一个0.5MP的参考图缩放节点
ref_scale_nid = max_nid + 1
ref_scale_node = {
    'id': ref_scale_nid,
    'type': 'ImageScaleToTotalPixels',
    'pos': [1200, -2400],
    'size': {'width': 315, 'height': 170},
    'flags': {},
    'order': 50,
    'mode': 0,
    'inputs': [
        {'name': 'image', 'type': 'IMAGE', 'link': None}
    ],
    'outputs': [
        {'name': 'IMAGE', 'type': 'IMAGE', 'links': None, 'slot_index': 0}
    ],
    'properties': {'Node name for S&R': 'ImageScaleToTotalPixels'},
    'widgets_values': ['lanczos', 0.5, 1],
    'title': 'Flux2 参考图缩放(0.5MP)用于混合'
}
nodes.append(ref_scale_node)
print(f'\n新增 NID={ref_scale_nid} ImageScaleToTotalPixels (参考图0.5MP)')

# 连接 NID=75(LoadImage) → NID=ref_scale_nid
new_link_id_1 = max_link_id + 1
links.append([new_link_id_1, 75, 0, ref_scale_nid, 0, 'IMAGE'])
ref_scale_node['inputs'][0]['link'] = new_link_id_1
ref_scale_node['outputs'][0]['links'] = []
print(f'  连接: NID=75 → NID={ref_scale_nid} (link_id={new_link_id_1})')

# 段2→3, 3→4, 4→5 的混合节点
segments = [
    {
        'name': '段2→3',
        'a_img_nid': 100,  # ImageScaleToTotalPixels (A图缩放)
        'flux2_resize_nid': 105,  # Flux2修正后的ImageResizeKJv2输出
        'flux2_save_nid': 206,  # SaveImage
    },
    {
        'name': '段3→4',
        'a_img_nid': 107,
        'flux2_resize_nid': 112,
        'flux2_save_nid': 210,
    },
    {
        'name': '段4→5',
        'a_img_nid': 114,
        'flux2_resize_nid': 119,
        'flux2_save_nid': 214,
    }
]

current_link_id = new_link_id_1
current_nid = ref_scale_nid

for seg in segments:
    current_nid += 1
    blend_nid = current_nid
    a_img_nid = seg['a_img_nid']
    flux2_resize_nid = seg['flux2_resize_nid']

    # 创建 ImageBlend 节点
    blend_node = {
        'id': blend_nid,
        'type': 'ImageBlend',
        'pos': [1800, -2400 + (blend_nid - ref_scale_nid) * 120],
        'size': {'width': 315, 'height': 170},
        'flags': {},
        'order': 55,
        'mode': 0,
        'inputs': [
            {'name': 'image1', 'type': 'IMAGE', 'link': None},
            {'name': 'image2', 'type': 'IMAGE', 'link': None}
        ],
        'outputs': [
            {'name': 'IMAGE', 'type': 'IMAGE', 'links': None, 'slot_index': 0}
        ],
        'properties': {'Node name for S&R': 'ImageBlend'},
        'widgets_values': ['normal', 0.5, 1],
        'title': f'Flux2 混合A图 {seg["name"]} (50%末帧+50%参考图)'
    }
    nodes.append(blend_node)
    print(f'\n新增 NID={blend_nid} ImageBlend ({seg["name"]})')

    # 连接 Flux2修正帧 → ImageBlend image1
    current_link_id += 1
    link_flux2 = current_link_id
    links.append([link_flux2, flux2_resize_nid, 0, blend_nid, 0, 'IMAGE'])
    blend_node['inputs'][0]['link'] = link_flux2
    print(f'  连接: NID={flux2_resize_nid}(Flux2修正) → NID={blend_nid}.image1 (link_id={link_flux2})')

    # 连接 参考图缩放 → ImageBlend image2
    current_link_id += 1
    link_ref = current_link_id
    links.append([link_ref, ref_scale_nid, 0, blend_nid, 1, 'IMAGE'])
    blend_node['inputs'][1]['link'] = link_ref
    # 更新参考图缩放节点的输出links
    ref_scale_node['outputs'][0]['links'].append(link_ref)
    print(f'  连接: NID={ref_scale_nid}(参考图) → NID={blend_nid}.image2 (link_id={link_ref})')

    # 修改 A图缩放节点(NID=100/107/114)的image输入link
    # 原来指向SVI末帧，现在改为指向ImageBlend输出
    a_img_node = nodes_by_id[a_img_nid]
    old_link_id = a_img_node['inputs'][0]['link']

    # 找到旧link并删除
    old_link_idx = None
    for i, link in enumerate(links):
        if isinstance(link, list) and len(link) >= 5 and link[0] == old_link_id:
            old_link_idx = i
            break

    # 创建新link: ImageBlend → A图缩放
    current_link_id += 1
    new_link = current_link_id
    links.append([new_link, blend_nid, 0, a_img_nid, 0, 'IMAGE'])
    a_img_node['inputs'][0]['link'] = new_link
    blend_node['outputs'][0]['links'] = [new_link]
    print(f'  修改: NID={a_img_nid}(A图缩放) image输入 link_id={old_link_id}→{new_link}')

    # 删除旧link
    if old_link_idx is not None:
        old_link = links[old_link_idx]
        # 从源节点的outputs.links中移除
        src_nid = old_link[1]
        src_slot = old_link[2]
        src_node = nodes_by_id.get(src_nid, {})
        for out in src_node.get('outputs', []):
            if out.get('slot_index', -1) == src_slot or src_slot == 0:
                if 'links' in out and isinstance(out['links'], list):
                    if old_link_id in out['links']:
                        out['links'].remove(old_link_id)
                        break
        links.pop(old_link_idx)
        print(f'  删除旧link: link_id={old_link_id} (NID={src_nid}→NID={a_img_nid})')

# 保存
with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

print(f'\n=== 修复完成 ===')
print(f'总节点数: {len(nodes)} (新增4个)')
print(f'总link数: {len(links)}')

# 验证
print('\n=== 验证 ===')
with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)
nodes = wf.get('nodes', [])
links = wf.get('links', [])
link_map = {link[0]: (link[1], link[2], link[3], link[4]) for link in links if isinstance(link, list) and len(link) >= 5}
nodes_by_id = {n.get('id'): n for n in nodes}

# 验证A图缩放节点的输入
for seg in segments:
    a_img_nid = seg['a_img_nid']
    a_img_node = nodes_by_id.get(a_img_nid, {})
    link_id = a_img_node.get('inputs', [{}])[0].get('link')
    if link_id and link_id in link_map:
        src_nid, src_slot, _, _ = link_map[link_id]
        src_node = nodes_by_id.get(src_nid, {})
        print(f'NID={a_img_nid}({seg["name"]} A图缩放) <- NID={src_nid}({src_node.get("type","?")}, {src_node.get("title","")})')

# 验证SplitSigmasDenoise
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        print(f'NID={n.get("id")} SplitSigmasDenoise denoise={n.get("widgets_values",[None])[0]}')

# 验证新增节点
for n in nodes:
    if n.get('id', 0) > max_nid:
        print(f'NID={n.get("id")} {n.get("type")} title={n.get("title","")}')
