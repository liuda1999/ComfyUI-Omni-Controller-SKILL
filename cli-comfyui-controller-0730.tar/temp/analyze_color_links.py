#!/usr/bin/env python3
"""分析Flux2和SVI的link链路，确定ColorMatch插入点"""
import json

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

# 建立 link_id -> (src_node, src_slot, dst_node, dst_slot, type)
link_map = {}
for L in links:
    if len(L) >= 5:
        lid, src_node, src_slot, dst_node, dst_slot = L[:5]
        link_map[lid] = (src_node, src_slot, dst_node, dst_slot)

# 找出关键输出link
def get_node_output_links(nid):
    """获取节点输出的所有link"""
    n = next((x for x in nodes if x.get('id') == nid), None)
    if not n:
        return []
    out_links = []
    for out in n.get('outputs', []):
        ls = out.get('links')
        if ls:
            out_links.extend(ls)
    return out_links

def get_node_input_link(nid, input_idx):
    """获取节点第N个输入的link"""
    n = next((x for x in nodes if x.get('id') == nid), None)
    if not n:
        return None
    inputs = n.get('inputs', [])
    if input_idx >= len(inputs):
        return None
    return inputs[input_idx].get('link')

# SVI Pro 5段的VAEDecode输出
print('=== SVI Pro 段VAEDecode输出链路 ===')
svi_vae_decodes = [232, 254, 276, 298, 320]
for nid in svi_vae_decodes:
    n = next((x for x in nodes if x.get('id') == nid), None)
    title = n.get('title', '') if n else ''
    out_links = get_node_output_links(nid)
    print(f'\nNID={nid} ({title})')
    print(f'  output links: {out_links}')
    for lid in out_links:
        if lid in link_map:
            src, src_slot, dst, dst_slot = link_map[lid]
            dst_node = next((x for x in nodes if x.get('id') == dst), None)
            dst_title = dst_node.get('title', '') if dst_node else ''
            dst_type = dst_node.get('type', '') if dst_node else ''
            print(f'  link {lid} -> NID={dst} type={dst_type} title={dst_title} (slot={dst_slot})')

# Flux2 4段输出 (ImageResizeKJv2)
print('\n\n=== Flux2 段输出链路 (ImageResizeKJv2) ===')
flux2_outs = [98, 105, 112, 119]
for nid in flux2_outs:
    n = next((x for x in nodes if x.get('id') == nid), None)
    title = n.get('title', '') if n else ''
    out_links = get_node_output_links(nid)
    print(f'\nNID={nid} ({title})')
    print(f'  output links: {out_links}')
    for lid in out_links:
        if lid in link_map:
            src, src_slot, dst, dst_slot = link_map[lid]
            dst_node = next((x for x in nodes if x.get('id') == dst), None)
            dst_title = dst_node.get('title', '') if dst_node else ''
            dst_type = dst_node.get('type', '') if dst_node else ''
            print(f'  link {lid} -> NID={dst} type={dst_type} title={dst_title} (slot={dst_slot})')

# Flux2 A图输入 (ImageScaleToTotalPixels的输入)
print('\n\n=== Flux2 A图输入链路 ===')
flux2_a_scales = [93, 100, 107, 114]
for nid in flux2_a_scales:
    n = next((x for x in nodes if x.get('id') == nid), None)
    title = n.get('title', '') if n else ''
    in_link = get_node_input_link(nid, 0)
    print(f'NID={nid} ({title}) input link={in_link}')
    if in_link and in_link in link_map:
        src, src_slot, dst, dst_slot = link_map[in_link]
        src_node = next((x for x in nodes if x.get('id') == src), None)
        src_title = src_node.get('title', '') if src_node else ''
        src_type = src_node.get('type', '') if src_node else ''
        print(f'  <- NID={src} type={src_type} title={src_title}')

# 参考图B的输出
print('\n\n=== 参考图B (NID=75) 输出链路 ===')
out_links = get_node_output_links(75)
print(f'NID=75 output links: {out_links}')
for lid in out_links:
    if lid in link_map:
        src, src_slot, dst, dst_slot = link_map[lid]
        dst_node = next((x for x in nodes if x.get('id') == dst), None)
        dst_title = dst_node.get('title', '') if dst_node else ''
        dst_type = dst_node.get('type', '') if dst_node else ''
        print(f'  link {lid} -> NID={dst} type={dst_type} title={dst_title} (slot={dst_slot})')

# 最大节点ID和link ID
max_nid = max(n.get('id', 0) for n in nodes)
max_lid = max((L[0] for L in links if L), default=0)
print(f'\n\n最大NID: {max_nid}, 最大LinkID: {max_lid}')
