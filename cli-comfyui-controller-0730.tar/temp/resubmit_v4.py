#!/usr/bin/env python3
"""重新转换工作流（提示词优化+8步采样）并提交"""
import json
import sys
import urllib.request

BASE = 'http://127.0.0.1:3198'
INPUT_WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUTPUT_API = r'e:\comfyui-cli\temp\long_video_api_v4.json'

sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import convert_web_to_api, get_object_info

# 1. Free memory
print('=== 1. Freeing memory ===')
try:
    req = urllib.request.Request(f'{BASE}/free', data=json.dumps({'unload_models': True, 'free_memory': True}).encode(), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=30) as resp:
        print(f'Free memory: {resp.status}')
except Exception as e:
    print(f'Free memory error: {e}')

# 2. Read workflow
print('\n=== 2. Reading workflow ===')
with open(INPUT_WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)
print(f'Nodes: {len(wf.get("nodes", []))}')

# 3. Get object_info
print('\n=== 3. Getting object_info ===')
object_info = get_object_info('127.0.0.1', '3198')
print(f'object_info nodes: {len(object_info)}')

# 4. Convert
print('\n=== 4. Converting ===')
api = convert_web_to_api(wf, object_info)
print(f'API nodes: {len(api)}')

# 5. Verify key parameters
print('\n=== 5. Verifying parameters ===')

# Check prompts
for nid in ['83', '84', '221', '240']:
    if nid in api:
        node = api[nid]
        inputs = node.get('inputs', {})
        text = inputs.get('text', '')
        if isinstance(text, str) and len(text) > 30:
            has_hand = '手' in text or '指' in text
            has_limb = '肢' in text or '臂' in text
            has_red = '红' in text or '色偏' in text
            print(f'NID={nid}: len={len(text)} 手部约束={has_hand} 肢体约束={has_limb} 色偏约束={has_red}')

# Check sampler steps
for nid, node in api.items():
    if node.get('class_type') == 'KSamplerAdvanced':
        inputs = node.get('inputs', {})
        steps = inputs.get('steps')
        start = inputs.get('start_at_step')
        end = inputs.get('end_at_step')
        print(f'NID={nid} KSampler: steps={steps}, start={start}, end={end}')

# Check Flux2Scheduler
for nid, node in api.items():
    if node.get('class_type') == 'Flux2Scheduler':
        inputs = node.get('inputs', {})
        print(f'NID={nid} Flux2Scheduler: {inputs}')

# 6. Add enable_fp16_accumulation
print('\n=== 6. Adding enable_fp16_accumulation ===')
torch_fixes = 0
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_fixes += 1
print(f'Fixed {torch_fixes} ModelPatchTorchSettings nodes')

# 7. Save
print('\n=== 7. Saving ===')
with open(OUTPUT_API, 'w', encoding='utf-8') as f:
    json.dump(api, f, indent=2, ensure_ascii=False)
print(f'Saved to: {OUTPUT_API}')

# 8. Submit
print('\n=== 8. Submitting ===')
payload = {
    'prompt': api,
    'client_id': 'comfyui-cli-monitor'
}
req = urllib.request.Request(
    f'{BASE}/prompt',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    print(f'Result: {json.dumps(result, ensure_ascii=False)}')
    prompt_id = result.get('prompt_id')
    if prompt_id:
        print(f'\nPrompt ID: {prompt_id}')
except urllib.error.HTTPError as e:
    print(f'HTTP Error: {e.code}')
    err_body = e.read().decode('utf-8')
    print(err_body[:3000])
except Exception as e:
    print(f'Error: {e}')
