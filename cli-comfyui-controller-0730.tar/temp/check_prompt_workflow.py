#!/usr/bin/env python3
"""检查实际提交的 prompt 工作流节点"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'

with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

data = h[PID]
prompt = data.get('prompt', [])
workflow = prompt[2] if isinstance(prompt, list) and len(prompt) >= 3 else {}

print(f'Workflow nodes: {len(workflow)}')

# 统计所有 class_type
class_counts = {}
for nid, node in workflow.items():
    ct = node.get('class_type', 'unknown')
    class_counts[ct] = class_counts.get(ct, 0) + 1

print('\n=== Class type counts ===')
for ct, cnt in sorted(class_counts.items(), key=lambda x: -x[1]):
    print(f'  {ct}: {cnt}')

# 查找 VHS/VideoCombine
print('\n=== VHS/VideoCombine nodes ===')
for nid, node in workflow.items():
    ct = node.get('class_type', '')
    if 'VHS' in ct or 'VideoCombine' in ct:
        print(f'NID={nid} {ct}')
        print(f'  inputs: {json.dumps(node.get("inputs", {}), ensure_ascii=False)[:500]}')

# 查找 SVI Pro 节点
print('\n=== SVI Pro nodes ===')
for nid, node in workflow.items():
    ct = node.get('class_type', '')
    if 'SVI' in ct:
        print(f'NID={nid} {ct}')
        inputs = node.get('inputs', {})
        for k in ['motion_latent_count', 'total_frames', 'frames', 'positive', 'negative', 'vae', 'model']:
            if k in inputs:
                v = inputs[k]
                if isinstance(v, list):
                    print(f'  {k}: -> {v}')
                else:
                    print(f'  {k}: {v}')

# 查找 KSampler 节点
print('\n=== Sampler nodes ===')
for nid, node in workflow.items():
    ct = node.get('class_type', '')
    if 'Sampler' in ct or 'KSampler' in ct:
        print(f'NID={nid} {ct}')
        inputs = node.get('inputs', {})
        for k in ['steps', 'cfg', 'sampler_name', 'scheduler', 'denoise', 'start_at_step', 'end_at_step', 'return_with_leftover_noise']:
            if k in inputs:
                print(f'  {k}: {inputs[k]}')

# 查找 NID=355 是否在 workflow
print(f'\n=== NID=355 in workflow: {"355" in workflow} ===')
print(f'=== NID=348 in workflow: {"348" in workflow} ===')
print(f'=== NID=229 in workflow: {"229" in workflow} ===')

# 查看 SaveImage 节点的输入连接
print('\n=== SaveImage nodes inputs ===')
for nid, node in workflow.items():
    ct = node.get('class_type', '')
    if ct == 'SaveImage':
        inputs = node.get('inputs', {})
        images_input = inputs.get('images')
        print(f'NID={nid} images <- {images_input}')

# 列出所有 NID
print(f'\n=== All NIDs ===')
nids = sorted([int(nid) for nid in workflow.keys()])
print(f'Range: {min(nids)}-{max(nids)}')
print(f'Count: {len(nids)}')
print(f'NIDs: {nids[:50]}...')
