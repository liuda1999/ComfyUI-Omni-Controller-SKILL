#!/usr/bin/env python3
"""检查实际提交的 prompt 格式"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'

with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

data = h[PID]
prompt = data.get('prompt', [])
print(f'prompt type: {type(prompt).__name__}')
print(f'prompt length: {len(prompt) if hasattr(prompt, "__len__") else "N/A"}')

if isinstance(prompt, list):
    for i, item in enumerate(prompt):
        print(f'\n[{i}] type={type(item).__name__}')
        if isinstance(item, dict):
            print(f'  keys: {list(item.keys())[:20]}')
            if 'output' in item or 'class_type' in item:
                # This is the workflow
                print(f'  WORKFLOW FOUND with {len(item)} nodes')
                # 检查 VHS
                for nid, node in item.items():
                    ct = node.get('class_type', '') if isinstance(node, dict) else ''
                    if 'VHS' in ct or 'VideoCombine' in ct or 'SaveImage' in ct:
                        print(f'  NID={nid} {ct}')
        elif isinstance(item, (int, float, str)):
            print(f'  value: {item}')
        elif isinstance(item, list):
            print(f'  list len: {len(item)}')
            if len(item) > 0:
                print(f'  first item type: {type(item[0]).__name__}')

# 计算执行时间
status = data.get('status', {})
messages = status.get('messages', [])
start_ts = None
end_ts = None
for msg_type, msg_data in messages:
    if msg_type == 'execution_start':
        start_ts = msg_data.get('timestamp')
    elif msg_type == 'execution_success':
        end_ts = msg_data.get('timestamp')

if start_ts and end_ts:
    duration_ms = end_ts - start_ts
    duration_sec = duration_ms / 1000
    duration_min = duration_sec / 60
    print(f'\n=== Execution Time ===')
    print(f'Start: {start_ts}')
    print(f'End: {end_ts}')
    print(f'Duration: {duration_ms} ms = {duration_sec:.1f}s = {duration_min:.2f} min')
