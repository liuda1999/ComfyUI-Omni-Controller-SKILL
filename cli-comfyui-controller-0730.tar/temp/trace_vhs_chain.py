#!/usr/bin/env python3
"""检查 NID=348 (ImageBatchExtendWithOverlap) 的上游链是否正常
   并验证 NID=355 (VHS_VideoCombine) 的输入"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'

with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

data = h[PID]
prompt = data.get('prompt', [])
workflow = prompt[2] if isinstance(prompt, list) and len(prompt) >= 3 else {}

# 检查 NID=348 的完整输入
print('=== NID=348 ImageBatchExtendWithOverlap ===')
node = workflow.get('348', {})
print(f'class_type: {node.get("class_type")}')
print(f'inputs: {json.dumps(node.get("inputs", {}), ensure_ascii=False, indent=2)}')

# 检查整条 ImageBatchExtendWithOverlap 链
print('\n=== ImageBatchExtendWithOverlap chain ===')
chain_nids = ['345', '346', '347', '348']
for nid in chain_nids:
    node = workflow.get(nid, {})
    print(f'\nNID={nid} {node.get("class_type")}')
    inputs = node.get('inputs', {})
    for k in ['overlap', 'overlap_side', 'overlap_mode', 'source_images', 'new_images']:
        if k in inputs:
            print(f'  {k}: {inputs[k]}')

# 检查上游 ImageUpscaleWithModel 节点
print('\n=== ImageUpscaleWithModel nodes feeding the chain ===')
upscale_nids = ['363', '360', '358', '356', '343']
for nid in upscale_nids:
    node = workflow.get(nid, {})
    print(f'\nNID={nid} {node.get("class_type")}')
    inputs = node.get('inputs', {})
    for k in ['upscale_model', 'image']:
        if k in inputs:
            print(f'  {k}: {inputs[k]}')

# 追溯 NID=343 的 image 输入源
print('\n=== Tracing NID=343 image source ===')
def trace_input(nid, slot, depth=0):
    indent = '  ' * depth
    node = workflow.get(str(nid), {})
    ct = node.get('class_type', '?')
    print(f'{indent}NID={nid} type={ct}')
    if depth > 10:
        return
    inputs = node.get('inputs', {})
    # 找到 image 或 images 输入
    for k in ['image', 'images', 'source_images', 'new_images']:
        if k in inputs:
            v = inputs[k]
            if isinstance(v, list) and len(v) >= 2:
                src_nid = v[0]
                src_slot = v[1]
                print(f'{indent}  {k} <- NID={src_nid} slot={src_slot}')
                trace_input(src_nid, src_slot, depth+1)

trace_input('343', 0)

# 检查 NID=229 SVI Pro 的输入
print('\n=== NID=229 SVI Pro inputs ===')
node = workflow.get('229', {})
print(f'class_type: {node.get("class_type")}')
inputs = node.get('inputs', {})
for k, v in inputs.items():
    print(f'  {k}: {v}')

# 检查 SVI Pro 的 motion_latent_count
print('\n=== SVI Pro motion_latent_count ===')
for nid in ['229', '251', '273', '295', '317']:
    node = workflow.get(nid, {})
    mlc = node.get('inputs', {}).get('motion_latent_count', 'NOT SET')
    print(f'  NID={nid}: motion_latent_count={mlc}')

# 检查 ComfyUI 系统统计
print('\n=== System Stats ===')
try:
    with urllib.request.urlopen(f'{BASE}/system_stats', timeout=5) as resp:
        stats = json.loads(resp.read())
    print(json.dumps(stats, ensure_ascii=False, indent=2)[:1000])
except Exception as e:
    print(f'Error: {e}')
