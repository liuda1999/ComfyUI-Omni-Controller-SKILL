#!/usr/bin/env python3
"""重新转换工作流并提交（v6: denoise=0.6 + 暖色调约束 + cut拼接）"""
import json
import sys
import urllib.request

BASE = 'http://127.0.0.1:3198'
INPUT_WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUTPUT_API = r'e:\comfyui-cli\temp\long_video_api_v6.json'

sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import convert_web_to_api, get_object_info

# 1. Free memory
print('=== 1. Freeing memory ===')
try:
    req = urllib.request.Request(f'{BASE}/free', data=json.dumps({'unload_models': True, 'free_memory': True}).encode(), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=30) as resp:
        print(f'Free memory: {resp.status}')
except Exception as e:
    print(f'Free memory error: {e}')

# 2. Read workflow
print('\n=== 2. Reading workflow ===')
with open(INPUT_WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)
print(f'Nodes: {len(wf.get("nodes", []))}')

# 3. Get object_info
print('\n=== 3. Getting object_info ===')
object_info = get_object_info('127.0.0.1', '3198')
print(f'object_info nodes: {len(object_info)}')

# 4. Convert
print('\n=== 4. Converting ===')
api = convert_web_to_api(wf, object_info)
print(f'API nodes: {len(api)}')

# 5. Verify fixes
print('\n=== 5. Verifying fixes ===')

# Fix 1: Flux2 denoise=0.6
print('\n[Fix 1] Flux2 denoise (target=0.6):')
for nid, node in api.items():
    if node.get('class_type') == 'SplitSigmasDenoise':
        denoise = node.get('inputs', {}).get('denoise')
        status = 'OK' if denoise == 0.6 else 'FAIL'
        print(f'  [{status}] NID={nid} denoise={denoise}')

# Fix 2: 暖色调约束
print('\n[Fix 2] Warm tone constraint in SVI prompts:')
warm_count = 0
for nid, node in api.items():
    if node.get('class_type') == 'CLIPTextEncode':
        text = node.get('inputs', {}).get('text', '')
        if isinstance(text, str) and '保持暖色调' in text:
            warm_count += 1
print(f'  [{"OK" if warm_count >= 5 else "FAIL"}] prompts with warm tone: {warm_count} (target>=5)')

# Fix 3: ImageBatchExtendWithOverlap cut模式
print('\n[Fix 3] ImageBatchExtendWithOverlap (target: overlap=1, mode=cut):')
cut_count = 0
for nid, node in api.items():
    if node.get('class_type') == 'ImageBatchExtendWithOverlap':
        inputs = node.get('inputs', {})
        overlap = inputs.get('overlap')
        mode = inputs.get('overlap_mode')
        ok = (overlap == 1 and mode == 'cut')
        if ok:
            cut_count += 1
        status = 'OK' if ok else 'FAIL'
        print(f'  [{status}] NID={nid} overlap={overlap} mode={mode}')
print(f'  Total cut nodes: {cut_count} (target=4)')

# 6. Add enable_fp16_accumulation
print('\n=== 6. Adding enable_fp16_accumulation ===')
torch_fixes = 0
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_fixes += 1
print(f'Fixed {torch_fixes} ModelPatchTorchSettings nodes')

# 7. Save
print('\n=== 7. Saving ===')
with open(OUTPUT_API, 'w', encoding='utf-8') as f:
    json.dump(api, f, indent=2, ensure_ascii=False)
print(f'Saved to: {OUTPUT_API}')

# 8. Submit
print('\n=== 8. Submitting ===')
payload = {
    'prompt': api,
    'client_id': 'comfyui-cli-monitor-v6'
}
req = urllib.request.Request(
    f'{BASE}/prompt',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    print(f'Result: {json.dumps(result, ensure_ascii=False)}')
    prompt_id = result.get('prompt_id')
    if prompt_id:
        print(f'\nPrompt ID: {prompt_id}')
        # 保存prompt_id供监控使用
        with open(r'e:\comfyui-cli\temp\last_prompt_id_v8.txt', 'w') as f:
            f.write(prompt_id)
except urllib.error.HTTPError as e:
    print(f'HTTP Error: {e.code}')
    err_body = e.read().decode('utf-8')
    print(err_body[:3000])
except Exception as e:
    print(f'Error: {e}')
