#!/usr/bin/env python3
"""检查ReferenceLatent节点和A图来源"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

link_map = {}
for link in links:
    if isinstance(link, list) and len(link) >= 5:
        link_map[link[0]] = (link[1], link[2], link[3], link[4])

nodes_by_id = {n.get('id'): n for n in nodes}

# ReferenceLatent 节点
print('='*70)
print('=== ReferenceLatent 节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'ReferenceLatent':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'    {name} <- NID={src_node} (type={src_type}, title={src_title})')

# CFGGuider 节点
print('\n' + '='*70)
print('=== CFGGuider 节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'CFGGuider':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'    {name} <- NID={src_node} (type={src_type}, title={src_title})')

# 追溯 A图来源（NID=93 是段1→2的A图缩放）
print('\n' + '='*70)
print('=== A图来源追溯（NID=93 段1→2） ===')
print('='*70)

def trace_back(nid, depth=0, visited=None):
    if visited is None:
        visited = set()
    if nid in visited or depth > 10:
        return
    visited.add(nid)
    indent = '  ' * depth
    node = nodes_by_id.get(nid, {})
    ct = node.get('type', '?')
    title = node.get('title', '')
    wv = node.get('widgets_values', [])
    print(f'{indent}NID={nid} type={ct} title={title} wv={wv}')
    for inp in node.get('inputs', []):
        name = inp.get('name')
        link_id = inp.get('link')
        if link_id is not None and link_id in link_map:
            src_node, src_slot, _, _ = link_map[link_id]
            print(f'{indent}  IN {name} <- NID={src_node}')
            trace_back(src_node, depth+1, visited)

trace_back(93)

# 追溯所有 ImageScaleToTotalPixels 的输入
print('\n' + '='*70)
print('=== 所有 Flux2 A图缩放节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'ImageScaleToTotalPixels':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} title={title} wv={wv}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'  {name} <- NID={src_node} (type={src_type}, title={src_title})')

# 追溯所有 SaveImage 节点的输入来源
print('\n' + '='*70)
print('=== SaveImage 节点输入来源 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'SaveImage':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'\nNID={nid} title={title} wv={wv}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'  {name} <- NID={src_node} (type={src_type}, title={src_title})')

# 检查 Flux2 B图来源（NID=76）
print('\n' + '='*70)
print('=== Flux2 B图来源（参考图） ===')
print('='*70)
trace_back(76)

# 检查所有 VAEDecode 节点
print('\n' + '='*70)
print('=== VAEDecode 节点（Flux2修正后解码） ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'VAEDecode':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'\nNID={nid} title={title}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'  {name} <- NID={src_node} (type={src_type}, title={src_title})')

# 检查段间传递：前一段的Flux2修正输出是否作为下一段的A图输入
print('\n' + '='*70)
print('=== 段间Flux2输出传递分析 ===')
print('='*70)

# 找出所有 Flux2 VAEDecode 输出
flux2_vae_decodes = []
for n in nodes:
    if n.get('type') == 'VAEDecode':
        nid = n.get('id')
        title = n.get('title', '')
        if 'flux' in title.lower() or 'c8' in title.lower():
            flux2_vae_decodes.append(nid)

print(f'Flux2 VAEDecode nodes: {flux2_vae_decodes}')

# 检查每个 Flux2 VAEDecode 的输出连接到哪些节点
for nid in flux2_vae_decodes:
    print(f'\nNID={nid} outputs:')
    for idx, out in enumerate(nodes_by_id.get(nid, {}).get('outputs', [])):
        for link in links:
            if isinstance(link, list) and len(link) >= 5:
                if link[1] == nid and link[2] == idx:
                    tgt_node = link[3]
                    tgt_node_obj = nodes_by_id.get(tgt_node, {})
                    tgt_type = tgt_node_obj.get('type', '?')
                    tgt_title = tgt_node_obj.get('title', '')
                    print(f'  OUT slot{idx} -> NID={tgt_node} (type={tgt_type}, title={tgt_title})')
