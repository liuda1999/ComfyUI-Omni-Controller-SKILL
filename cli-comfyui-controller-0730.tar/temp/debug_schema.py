#!/usr/bin/env python3
"""检查ImageScaleToTotalPixels和VHS_VideoCombine的object_info"""
import json
import urllib.request

BASE_URL = 'http://127.0.0.1:3198'
with urllib.request.urlopen(f'{BASE_URL}/object_info', timeout=15) as resp:
    object_info = json.loads(resp.read())

for nt in ['ImageScaleToTotalPixels', 'VHS_VideoCombine', 'KSamplerSelect']:
    print(f'\n=== {nt} ===')
    info = object_info.get(nt, {})
    for section in ('required', 'optional'):
        si = info.get('input', {}).get(section, {})
        if si:
            print(f'  {section}:')
            for name, type_info in si.items():
                if isinstance(type_info, list) and len(type_info) > 0:
                    t = type_info[0]
                    if isinstance(t, list):
                        print(f'    {name}: COMBO (options={len(t)})')
                    else:
                        print(f'    {name}: {t}')
                else:
                    print(f'    {name}: {type_info}')
