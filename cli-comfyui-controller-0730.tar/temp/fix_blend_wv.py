#!/usr/bin/env python3
"""修复ImageBlend节点的widgets_values顺序
   Required inputs: ['image1', 'image2', 'blend_factor', 'blend_mode']
   widgets_values应为: [blend_factor, blend_mode]
"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])

# 获取ImageBlend的schema
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:3198/object_info/ImageBlend', timeout=10) as resp:
    data = json.loads(resp.read())

blend_info = data['ImageBlend']
required = blend_info.get('input', {}).get('required', {})
print('ImageBlend required inputs:')
for name, type_info in required.items():
    print(f'  {name}: {type_info}')

# 修复新增的ImageBlend节点
for n in nodes:
    if n.get('type') == 'ImageBlend' and n.get('id', 0) >= 366:
        nid = n.get('id')
        title = n.get('title', '')
        old_wv = n.get('widgets_values', [])
        print(f'\nNID={nid} {title}')
        print(f'  old widgets_values: {old_wv}')

        # 正确的widgets_values: [blend_factor, blend_mode]
        # blend_factor=0.5, blend_mode='normal'
        new_wv = [0.5, 'normal']
        n['widgets_values'] = new_wv
        print(f'  new widgets_values: {new_wv}')

with open(WF_PATH, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)

print('\n修复完成')
