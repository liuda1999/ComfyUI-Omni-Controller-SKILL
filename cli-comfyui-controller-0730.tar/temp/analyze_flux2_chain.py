#!/usr/bin/env python3
"""深度分析Flux2修正节点链和角色外貌漂移问题"""
import json

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
links = wf.get('links', [])

# 构建 link_id -> (源节点, 源slot, 目标节点, 目标slot)
link_map = {}
for link in links:
    if isinstance(link, list) and len(link) >= 5:
        link_map[link[0]] = (link[1], link[2], link[3], link[4])

# 节点查找字典
nodes_by_id = {n.get('id'): n for n in nodes}

def trace_input(nid, slot, depth=0, visited=None):
    """递归追溯输入链"""
    if visited is None:
        visited = set()
    if nid in visited or depth > 8:
        return
    visited.add(nid)
    indent = '  ' * depth
    node = nodes_by_id.get(nid, {})
    ct = node.get('type', '?')
    title = node.get('title', '')
    print(f'{indent}NID={nid} type={ct} title={title}')
    if depth > 8:
        return
    inputs = node.get('inputs', [])
    for inp in inputs:
        name = inp.get('name')
        link_id = inp.get('link')
        if link_id is not None and link_id in link_map:
            src_node, src_slot, _, _ = link_map[link_id]
            print(f'{indent}  IN {name} <- NID={src_node} slot={src_slot}')
            if name in ('image', 'images', 'latent', 'model', 'positive', 'negative', 'noise', 'guider'):
                trace_input(src_node, src_slot, depth+1, visited)

# 找出所有 Flux2 修正相关的 SamplerCustomAdvanced 节点
print('='*70)
print('=== Flux2 修正节点链分析 ===')
print('='*70)

flux2_samplers = []
for n in nodes:
    if n.get('type') == 'SamplerCustomAdvanced':
        nid = n.get('id')
        title = n.get('title', '')
        if 'flux' in title.lower() or 'Flux2' in title or 'c8' in title.lower():
            flux2_samplers.append(nid)
            print(f'\n--- NID={nid} {title} ---')
            wv = n.get('widgets_values', [])
            print(f'widgets_values: {wv}')
            print(f'inputs:')
            for inp in n.get('inputs', []):
                name = inp.get('name')
                link_id = inp.get('link')
                if link_id is not None and link_id in link_map:
                    src_node, src_slot, _, _ = link_map[link_id]
                    src_node_obj = nodes_by_id.get(src_node, {})
                    src_type = src_node_obj.get('type', '?')
                    print(f'  {name} <- NID={src_node} (type={src_type}, slot={src_slot})')

# 追溯第一个 Flux2 修正的 latent 输入
if flux2_samplers:
    first_nid = flux2_samplers[0]
    print(f'\n=== 追溯 NID={first_nid} latent 输入链 ===')
    node = nodes_by_id.get(first_nid, {})
    for inp in node.get('inputs', []):
        if inp.get('name') == 'latent':
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                trace_input(src_node, src_slot)

# 检查所有 VAEEncode 节点
print('\n' + '='*70)
print('=== VAEEncode 节点（参考图编码） ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'VAEEncode':
        nid = n.get('id')
        title = n.get('title', '')
        print(f'\nNID={nid} title={title}')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'  {name} <- NID={src_node} (type={src_type}, title={src_title})')

# 检查提示词节点
print('\n' + '='*70)
print('=== CLIPTextEncode 提示词节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'CLIPTextEncode':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        if isinstance(wv, list) and wv:
            text = wv[0] if isinstance(wv[0], str) else str(wv[0])
            if len(text) > 30:
                print(f'\nNID={nid} title={title}')
                print(f'  text (前200字): {text[:200]}')
                # 检查是否连接到 Flux2 的 positive/negative
                for inp in n.get('inputs', []):
                    pass
                # 检查输出连接
                for idx, out in enumerate(n.get('outputs', [])):
                    for link in links:
                        if isinstance(link, list) and len(link) >= 5:
                            if link[1] == nid and link[2] == idx:
                                tgt_node = link[3]
                                tgt_node_obj = nodes_by_id.get(tgt_node, {})
                                tgt_type = tgt_node_obj.get('type', '?')
                                tgt_title = tgt_node_obj.get('title', '')
                                print(f'  OUT slot{idx} -> NID={tgt_node} (type={tgt_type}, title={tgt_title})')

# 检查 Flux2 模型加载
print('\n' + '='*70)
print('=== Flux2 模型加载节点 ===')
print('='*70)
for n in nodes:
    ntype = n.get('type', '')
    if ntype in ('UNETLoader', 'UNETLoaderGGUF', 'CheckpointLoaderSimple'):
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} type={ntype} title={title}')
        print(f'  widgets_values: {wv}')
        # 检查输出连接
        for idx, out in enumerate(n.get('outputs', [])):
            for link in links:
                if isinstance(link, list) and len(link) >= 5:
                    if link[1] == nid and link[2] == idx:
                        tgt_node = link[3]
                        tgt_node_obj = nodes_by_id.get(tgt_node, {})
                        tgt_type = tgt_node_obj.get('type', '?')
                        tgt_title = tgt_node_obj.get('title', '')
                        print(f'  OUT slot{idx} -> NID={tgt_node} (type={tgt_type}, title={tgt_title})')

# 检查 denoise 和 SplitSigmasDenoise
print('\n' + '='*70)
print('=== SplitSigmasDenoise 节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'SplitSigmasDenoise':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')

# 检查 Flux2Scheduler 的配置
print('\n' + '='*70)
print('=== Flux2Scheduler 节点 ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'Flux2Scheduler':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                print(f'    {name} <- NID={src_node} (type={src_type})')

# 检查段间传递（ImageBatchExtendWithOverlap）
print('\n' + '='*70)
print('=== 段间传递: ImageBatchExtendWithOverlap ===')
print('='*70)
for n in nodes:
    if n.get('type') == 'ImageBatchExtendWithOverlap':
        nid = n.get('id')
        title = n.get('title', '')
        wv = n.get('widgets_values', [])
        print(f'NID={nid} title={title}')
        print(f'  widgets_values: {wv}')
        print(f'  inputs:')
        for inp in n.get('inputs', []):
            name = inp.get('name')
            link_id = inp.get('link')
            if link_id is not None and link_id in link_map:
                src_node, src_slot, _, _ = link_map[link_id]
                src_node_obj = nodes_by_id.get(src_node, {})
                src_type = src_node_obj.get('type', '?')
                src_title = src_node_obj.get('title', '')
                print(f'    {name} <- NID={src_node} (type={src_type}, title={src_title})')
