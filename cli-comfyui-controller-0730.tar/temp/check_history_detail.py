#!/usr/bin/env python3
"""详细查看历史记录中的执行情况"""
import json
import urllib.request

BASE = 'http://127.0.0.1:3198'
PID = 'a47a7258-9877-45ec-bb51-dd93fd327e82'

# 获取完整历史记录
with urllib.request.urlopen(f'{BASE}/history/{PID}', timeout=10) as resp:
    h = json.loads(resp.read())

if PID not in h:
    print(f'Prompt {PID} not found in history')
    exit()

data = h[PID]
print(f'Status: {data.get("status", {}).get("status_str")}')
print(f'Completed: {data.get("status", {}).get("completed")}')

# 查看所有消息
print('\n=== Messages ===')
messages = data.get('status', {}).get('messages', [])
for msg_type, msg_data in messages:
    print(f'{msg_type}: {json.dumps(msg_data, ensure_ascii=False)[:200]}')

# 查看 prompt
prompt = data.get('prompt', [])
if isinstance(prompt, list) and len(prompt) >= 4:
    # prompt 是 [number, prompt_workflow, ...]
    workflow = prompt[1] if isinstance(prompt[1], dict) else {}
    print(f'\n=== Submitted Prompt Workflow ===')
    print(f'Nodes: {len(workflow)}')
    # 查找 VHS
    for nid, node in workflow.items():
        ct = node.get('class_type', '')
        if 'VHS' in ct or 'VideoCombine' in ct:
            print(f'NID={nid} {ct}')
            print(f'  inputs: {json.dumps(node.get("inputs", {}), ensure_ascii=False)[:500]}')
    # 查找 NID 348, 345, 346, 347
    print('\n=== Image Batch Chain ===')
    for nid in ['363', '345', '346', '347', '348', '355']:
        if nid in workflow:
            node = workflow[nid]
            ct = node.get('class_type', '')
            inputs = node.get('inputs', {})
            print(f'NID={nid} {ct}')
            for k in ['images', 'extended_images', 'new_images', 'source_images', 'image', 'upscale_model']:
                if k in inputs:
                    print(f'  {k}: {inputs[k]}')

# 检查所有输出
print('\n=== All Outputs ===')
outputs = data.get('outputs', {})
for nid, out in outputs.items():
    print(f'NID={nid}: {list(out.keys())}')
    for k, v in out.items():
        print(f'  {k}: {json.dumps(v, ensure_ascii=False)[:200]}')
