#!/usr/bin/env python3
"""
插入9个ColorMatch节点修复色调问题：
- 5个SVI VAEDecode输出后插入ColorMatch，锚定到参考图B(NID=75)
- 4个Flux2输出后插入ColorMatch，还原色调到参考图B(NID=75)

策略：
- SVI: 在VAEDecode输出分叉前插入ColorMatch，确保末帧和视频帧都经过颜色锚定
- Flux2: 在ImageResizeKJv2输出后插入ColorMatch，还原换皮导致的颜色加深
- method="reinhard"（平滑过渡，适合视频）
- strength=0.85（足够锚定色调，保留少量自然变化）
"""
import json
import copy

WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUT = WF  # 原地修改

with open(WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf['nodes']
links = wf['links']

# 建立索引
node_by_id = {n['id']: n for n in nodes}
link_by_id = {L[0]: L for L in links}

max_nid = max(n['id'] for n in nodes)
max_lid = max(L[0] for L in links if L)

# 参考图B LoadImage (NID=75)
REF_NID = 75

# SVI VAEDecode 节点列表: (vae_decode_nid, segment_label)
svi_decodes = [
    (232, 'SVI1'),
    (254, 'SVI2'),
    (276, 'SVI3'),
    (298, 'SVI4'),
    (320, 'SVI5'),
]

# Flux2 ImageResizeKJv2 输出节点列表: (resize_nid, segment_label)
flux2_outs = [
    (98, 'Flux2_1to2'),
    (105, 'Flux2_2to3'),
    (112, 'Flux2_3to4'),
    (119, 'Flux2_4to5'),
]

next_nid = max_nid + 1  # 365
next_lid = max_lid + 1  # 543

new_nodes = []
new_links = []

def make_colormatch_node(nid, title, pos_x, pos_y):
    """创建ColorMatch节点"""
    return {
        "id": nid,
        "type": "ColorMatch",
        "pos": [pos_x, pos_y],
        "size": [280, 150],
        "flags": {},
        "order": 0,  # 会在后面重新排序
        "mode": 0,
        "inputs": [
            {
                "label": "image_ref",
                "name": "image_ref",
                "type": "IMAGE",
                "link": None
            },
            {
                "label": "image_target",
                "name": "image_target",
                "type": "IMAGE",
                "link": None
            },
            {
                "label": "method",
                "name": "method",
                "type": "COMBO",
                "widget": {"name": "method"},
                "link": None
            },
            {
                "label": "strength",
                "name": "strength",
                "type": "FLOAT",
                "widget": {"name": "strength"},
                "link": None
            }
        ],
        "outputs": [
            {
                "label": "image",
                "name": "image",
                "type": "IMAGE",
                "links": []
            }
        ],
        "title": title,
        "properties": {
            "Node name for S&R": "ColorMatch"
        },
        "widgets_values": ["reinhard", 0.85]
    }

def insert_colormatch_after(src_nid, ref_nid, label, pos_x, pos_y):
    """
    在src_nid的输出后插入ColorMatch节点
    - src_nid 的所有输出 link 重定向到 ColorMatch 的输出
    - src_nid 输出 → ColorMatch image_target
    - ref_nid 输出 → ColorMatch image_ref
    - ColorMatch 输出 → 原src_nid的所有下游
    """
    global next_nid, next_lid

    cm_nid = next_nid
    next_nid += 1

    cm_node = make_colormatch_node(cm_nid, f"ColorMatch {label}", pos_x, pos_y)

    src_node = node_by_id[src_nid]
    ref_node = node_by_id[ref_nid]

    # 1. src_nid 输出 slot 0 → ColorMatch image_target (input slot 1)
    target_link_id = next_lid
    next_lid += 1
    new_links.append([target_link_id, src_nid, 0, cm_nid, 1, "IMAGE"])
    cm_node["inputs"][1]["link"] = target_link_id  # image_target

    # 2. ref_nid 输出 slot 0 → ColorMatch image_ref (input slot 0)
    ref_link_id = next_lid
    next_lid += 1
    new_links.append([ref_link_id, ref_nid, 0, cm_nid, 0, "IMAGE"])
    cm_node["inputs"][0]["link"] = ref_link_id  # image_ref

    # 3. ColorMatch 输出 → 原src_nid的所有下游
    # 收集src_nid output slot 0 的所有link
    src_output = src_node["outputs"][0]
    original_links = list(src_output.get("links", []))

    # 这些link原本是 [lid, src_nid, 0, dst_nid, dst_slot, "IMAGE"]
    # 需要改为 [lid, cm_nid, 0, dst_nid, dst_slot, "IMAGE"]
    # 同时 dst_nid 的对应 input 的 link 不变（link ID不变，只是源头变了）

    # 重定向这些link的源为cm_nid
    for lid in original_links:
        # 找到link并修改源
        for L in links:
            if L[0] == lid:
                # 修改 src_node 为 cm_nid
                L[1] = cm_nid
                L[2] = 0  # src_slot = 0 (ColorMatch output)
                break

    # src_nid 的输出 links 现在只有连到 ColorMatch 的那条
    src_output["links"] = [target_link_id]

    # ColorMatch 输出 links 继承原来的所有下游
    cm_node["outputs"][0]["links"] = original_links

    # ref_nid 的输出 links 添加 ref_link_id
    ref_output = ref_node["outputs"][0]
    if ref_link_id not in ref_output.get("links", []):
        ref_output["links"].append(ref_link_id)

    print(f'  插入 ColorMatch NID={cm_nid} ({label}): {src_nid} -> CM -> {len(original_links)}下游, ref={ref_nid}')
    return cm_nid

# === 插入5个SVI ColorMatch ===
print('=== 插入SVI ColorMatch节点 ===')
svi_cm_nids = []
for i, (vae_nid, label) in enumerate(svi_decodes):
    # 位置参考SVI VAEDecode的位置
    vae_node = node_by_id[vae_nid]
    pos_x = vae_node["pos"][0] + 350
    pos_y = vae_node["pos"][1]
    cm_nid = insert_colormatch_after(vae_nid, REF_NID, label, pos_x, pos_y)
    svi_cm_nids.append(cm_nid)

# === 插入4个Flux2 ColorMatch ===
print('\n=== 插入Flux2 ColorMatch节点 ===')
flux2_cm_nids = []
for i, (resize_nid, label) in enumerate(flux2_outs):
    resize_node = node_by_id[resize_nid]
    pos_x = resize_node["pos"][0] + 350
    pos_y = resize_node["pos"][1]
    cm_nid = insert_colormatch_after(resize_nid, REF_NID, label, pos_x, pos_y)
    flux2_cm_nids.append(cm_nid)

# 添加新节点到工作流
nodes.extend(new_nodes)
links.extend(new_links)

print(f'\n新增节点: {len(new_nodes)} 个 ColorMatch')
print(f'新增链接: {len(new_links)} 条')
print(f'SVI ColorMatch NIDs: {svi_cm_nids}')
print(f'Flux2 ColorMatch NIDs: {flux2_cm_nids}')

# 保存
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(wf, f, indent=2, ensure_ascii=False)
print(f'\n已保存到: {OUT}')
