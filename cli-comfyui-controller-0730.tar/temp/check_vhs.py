#!/usr/bin/env python3
"""检查工作流中的 VHS_VideoCombine 节点状态"""
import json
import os

WF_PATH = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'

with open(WF_PATH, 'r', encoding='utf-8') as f:
    wf = json.load(f)

nodes = wf.get('nodes', [])
print(f'Total nodes: {len(nodes)}')

vhs_nodes = []
for n in nodes:
    ntype = n.get('type', '')
    if 'VHS' in ntype or 'VideoCombine' in ntype or 'Video' in ntype:
        vhs_nodes.append(n)

print(f'VHS/Video nodes: {len(vhs_nodes)}')
for n in vhs_nodes:
    nid = n.get('id')
    ntype = n.get('type')
    mode = n.get('mode', 0)
    title = n.get('title', '')
    wv = n.get('widgets_values', [])
    print(f'  NID={nid} type={ntype} mode={mode} title={title}')
    if isinstance(wv, dict):
        for k, v in wv.items():
            print(f'    {k}: {v}')
    else:
        print(f'    widgets_values: {wv}')

# 检查输出节点（SaveImage 等）
print('\nOutput nodes (SaveImage/SaveAnimatedPNG/etc):')
for n in nodes:
    ntype = n.get('type', '')
    if 'Save' in ntype or 'Output' in ntype:
        nid = n.get('id')
        mode = n.get('mode', 0)
        print(f'  NID={nid} type={ntype} mode={mode}')

# 检查 mode != 0 (被绕过/禁用) 的节点
print('\nBypassed/Muted nodes (mode != 0):')
bypassed = [n for n in nodes if n.get('mode', 0) != 0]
for n in bypassed:
    print(f'  NID={n.get("id")} type={n.get("type")} mode={n.get("mode")} title={n.get("title","")}')
print(f'Total bypassed: {len(bypassed)}')
