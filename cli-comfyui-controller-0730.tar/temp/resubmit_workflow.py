#!/usr/bin/env python3
"""重新转换工作流为 API 格式并提交执行
   - 使用修复后的 workflow_converter.py
   - 设置 LoadImage 为 2.png
   - 添加 ModelPatchTorchSettings 的 enable_fp16_accumulation
   - 提交到 ComfyUI 执行
"""
import json
import os
import sys
import urllib.request

BASE = 'http://127.0.0.1:3198'
INPUT_WF = r'e:\comfyui-cli\comfyui-controller\assets\long_video_svi_pro_wan22_v1.0.0.json'
OUTPUT_API = r'e:\comfyui-cli\temp\long_video_api_fixed.json'

# 导入转换器
sys.path.insert(0, r'e:\comfyui-cli\comfyui-controller\scripts')
from workflow_converter import convert_web_to_api, get_object_info

# 1. 读取 UI 工作流
print('=== 1. Reading UI workflow ===')
with open(INPUT_WF, 'r', encoding='utf-8') as f:
    wf = json.load(f)
print(f'Nodes: {len(wf.get("nodes", []))}')

# 2. 获取 object_info
print('\n=== 2. Getting object_info ===')
object_info = get_object_info('127.0.0.1', '3198')
print(f'object_info nodes: {len(object_info)}')

# 3. 转换为 API 格式
print('\n=== 3. Converting to API format ===')
api = convert_web_to_api(wf, object_info)
print(f'API nodes: {len(api)}')

# 4. 验证修复的关键节点
print('\n=== 4. Verifying key fixes ===')

# 检查 overlap_side
for nid in ['345', '346', '347', '348']:
    if nid in api:
        node = api[nid]
        os_val = node.get('inputs', {}).get('overlap_side')
        print(f'NID={nid} overlap_side: {os_val} (type={type(os_val).__name__})')

# 检查 motion_latent_count
for nid in ['229', '251', '273', '295', '317']:
    if nid in api:
        node = api[nid]
        mlc = node.get('inputs', {}).get('motion_latent_count')
        print(f'NID={nid} motion_latent_count: {mlc}')

# 检查 VHS_VideoCombine
for nid, node in api.items():
    if node.get('class_type') == 'VHS_VideoCombine':
        print(f'NID={nid} VHS_VideoCombine images: {node.get("inputs", {}).get("images")}')

# 5. 修复 LoadImage 为 2.png
print('\n=== 5. Setting LoadImage to 2.png ===')
for nid, node in api.items():
    if node.get('class_type') == 'LoadImage':
        old_img = node.get('inputs', {}).get('image', '?')
        node['inputs']['image'] = '2.png'
        print(f'NID={nid} (LoadImage): {old_img} -> 2.png')

# 6. 添加 ModelPatchTorchSettings 的 enable_fp16_accumulation
print('\n=== 6. Adding enable_fp16_accumulation ===')
torch_fixes = 0
for nid, node in api.items():
    if node.get('class_type') == 'ModelPatchTorchSettings':
        inputs = node.get('inputs', {})
        if 'enable_fp16_accumulation' not in inputs:
            inputs['enable_fp16_accumulation'] = True
            torch_fixes += 1
print(f'Fixed {torch_fixes} ModelPatchTorchSettings nodes')

# 7. 保存 API 工作流
print('\n=== 7. Saving API workflow ===')
with open(OUTPUT_API, 'w', encoding='utf-8') as f:
    json.dump(api, f, indent=2, ensure_ascii=False)
print(f'Saved to: {OUTPUT_API}')

# 8. 提交到 ComfyUI
print('\n=== 8. Submitting to ComfyUI ===')
payload = {
    'prompt': api,
    'client_id': 'comfyui-cli-monitor'
}
req = urllib.request.Request(
    f'{BASE}/prompt',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'},
    method='POST'
)
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read())
    print(f'Result: {json.dumps(result, ensure_ascii=False)}')
    prompt_id = result.get('prompt_id')
    if prompt_id:
        print(f'\nPrompt ID: {prompt_id}')
        print(f'Monitor with: python -c "import urllib.request,json; r=urllib.request.urlopen(\'{BASE}/history/{prompt_id}\', timeout=5); print(json.loads(r.read()).get(\'{prompt_id}\',{{}}).get(\'status\',{{}}).get(\'status_str\'))"')
except urllib.error.HTTPError as e:
    print(f'HTTP Error: {e.code}')
    print(e.read().decode('utf-8'))
except Exception as e:
    print(f'Error: {e}')
